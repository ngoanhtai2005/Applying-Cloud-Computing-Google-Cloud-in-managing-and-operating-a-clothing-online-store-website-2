<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Bắt buộc đăng nhập
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = getCurrentUserId();
$conn   = getDBConnection();

/*
|------------------------------------------------------------
| LẤY DANH SÁCH ĐỊA CHỈ CỦA USER
|------------------------------------------------------------
*/
$sql = "
    SELECT 
        id,
        full_name,
        phone,
        address_line,
        city,
        district,
        is_default,
        created_at
    FROM addresses
    WHERE user_id = ?
    ORDER BY is_default DESC, created_at DESC
";

$stmt = $conn->prepare($sql);
if ($stmt === false) {
    die('SQL Prepare Error: ' . $conn->error);
}

$stmt->bind_param("i", $userId);
$stmt->execute();

$result    = $stmt->get_result();
$addresses = $result->fetch_all(MYSQLI_ASSOC);

$stmt->close();
$conn->close();

$pageTitle = "My Addresses";
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row">

            <!-- SIDEBAR -->
            <div class="col-lg-3 mb-4">
                <div class="list-group">
                    <a href="account.php" class="list-group-item list-group-item-action">
                        Account Overview
                    </a>
                    <a href="orders.php" class="list-group-item list-group-item-action">
                        My Orders
                    </a>
                    <a href="account-addresses.php" class="list-group-item list-group-item-action active">
                        Address Book
                    </a>
                    <a href="account-settings.php" class="list-group-item list-group-item-action">
                        Account Settings
                    </a>
                    <a href="logout.php" class="list-group-item list-group-item-action text-danger">
                        Logout
                    </a>
                </div>
            </div>

            <!-- CONTENT -->
            <div class="col-lg-9">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="fw-light">MY ADDRESSES</h3>
                    <a href="add-address.php" class="btn btn-dark rounded-0">
                        + Add New Address
                    </a>
                </div>

                <?php if (empty($addresses)): ?>
                    <div class="border p-5 text-center text-muted">
                        You haven't added any address yet.
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($addresses as $address): ?>
                            <div class="col-md-6">
                                <div class="border p-4 h-100">
                                    
                                    <?php if ($address['is_default']): ?>
                                        <span class="badge bg-dark mb-2">Default</span>
                                    <?php endif; ?>

                                    <h6 class="fw-bold mb-1">
                                        <?php echo htmlspecialchars($address['full_name']); ?>
                                    </h6>

                                    <p class="mb-1">
                                        <?php echo htmlspecialchars($address['phone']); ?>
                                    </p>

                                    <p class="mb-3 text-muted">
                                        <?php
                                            echo htmlspecialchars(
                                                $address['address_line'] . ', ' .
                                                $address['district'] . ', ' .
                                                $address['city']
                                            );
                                        ?>
                                    </p>

                                    <div class="d-flex gap-3">
                                        <a href="edit-address.php?id=<?php echo $address['id']; ?>" 
                                           class="text-dark text-decoration-none">
                                            Edit
                                        </a>
                                        <a href="delete-address.php?id=<?php echo $address['id']; ?>" 
                                           class="text-danger text-decoration-none"
                                           onclick="return confirm('Delete this address?')">
                                            Delete
                                        </a>
                                    </div>

                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
