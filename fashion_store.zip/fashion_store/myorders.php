<?php
require_once 'config/functions.php';
require_once 'config/database.php';

/* =========================
   AUTH CHECK
========================= */
if (!isLoggedIn()) {
    $_SESSION['redirect'] = 'myorders.php';
    header('Location: login.php?redirect=myorders.php');
    exit;
}

$pageTitle = "My Orders";

/* =========================
   USER INFO
========================= */
$user_id = $_SESSION['user_id'];

/* =========================
   DATABASE (SAFE MODE)
========================= */
$orders = [];
$conn = getDBConnection();

/*
  SAFE QUERY:
  - Nếu bảng orders chưa tồn tại → không chết
*/
$sql = "
    SELECT id, created_at, status, total_amount
    FROM orders
    WHERE user_id = ?
    ORDER BY created_at DESC
";

$stmt = $conn->prepare($sql);

if ($stmt) {
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $orders = $result->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
}

$conn->close();
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<div class="container py-5">
    <h2 class="mb-4">My Orders</h2>

    <?php if (empty($orders)) : ?>
        <div class="alert alert-info">
            You have no orders yet.
        </div>
    <?php else : ?>
        <table class="table table-bordered align-middle">
            <thead class="table-light">
                <tr>
                    <th>#Order ID</th>
                    <th>Date</th>
                    <th>Status</th>
                    <th>Total</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($orders as $order) : ?>
                    <tr>
                        <td>#<?= htmlspecialchars($order['id']) ?></td>
                        <td><?= htmlspecialchars($order['created_at']) ?></td>
                        <td><?= htmlspecialchars(ucfirst($order['status'])) ?></td>
                        <td>$<?= number_format($order['total_amount'], 2) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>

