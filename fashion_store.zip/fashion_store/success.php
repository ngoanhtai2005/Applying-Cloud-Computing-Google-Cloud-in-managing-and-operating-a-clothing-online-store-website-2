<?php
include 'includes/header.php';
include 'includes/navbar.php';
$orderId = $_GET['order_id'] ?? '';
?>

<div class="container py-5 text-center" style="min-height: 50vh;">
    <div class="py-5">
        <i class="bi bi-check-circle text-success" style="font-size: 5rem;"></i>
        <h1 class="fw-light mt-4">CẢM ƠN BẠN ĐÃ ĐẶT HÀNG!</h1>
        <p class="lead text-muted">Mã đơn hàng của bạn là: <strong>#<?php echo htmlspecialchars($orderId); ?></strong></p>
        <p>Chúng tôi sẽ liên hệ với bạn sớm nhất để xác nhận đơn hàng.</p>
        <div class="mt-5">
            <a href="index.php" class="btn btn-dark rounded-0 px-5 py-3">TIẾP TỤC MUA SẮM</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>