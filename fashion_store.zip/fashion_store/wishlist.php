<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    $_SESSION['redirect'] = 'wishlist.php';
    header('Location: login.php?redirect=wishlist.php');
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();

// Get wishlist items
$stmt = $conn->prepare("SELECT w.*, p.*, c.name as category_name,
                       (SELECT image_url FROM product_images WHERE product_id = p.id AND is_main = 1 LIMIT 1) as main_image
                       FROM wishlist w
                       LEFT JOIN products p ON w.product_id = p.id
                       LEFT JOIN categories c ON p.category_id = c.id
                       WHERE w.user_id = ?
                       ORDER BY w.created_at DESC");
$stmt->bind_param("i", $userId);
$stmt->execute();
$wishlistItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();

$pageTitle = "My Wishlist";
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <h1 class="fw-light mb-5">MY WISHLIST</h1>
        
        <?php if (empty($wishlistItems)): ?>
            <div class="text-center py-5">
                <i class="bi bi-heart fs-1 text-muted mb-3"></i>
                <h4 class="text-muted mb-3">Your wishlist is empty</h4>
                <p class="text-muted mb-4">Add items you love to your wishlist</p>
                <a href="category.php?category=new" class="btn btn-dark rounded-0 px-5">START SHOPPING</a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-12 mb-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <p class="mb-0"><?php echo count($wishlistItems); ?> items in wishlist</p>
                        <button class="btn btn-outline-dark rounded-0 btn-sm" onclick="clearWishlist()">
                            CLEAR WISHLIST
                        </button>
                    </div>
                </div>
                
                <!-- Wishlist Items -->
                <div class="col-12">
                    <div class="row g-4">
                        <?php foreach ($wishlistItems as $item): ?>
                            <div class="col-md-3 col-sm-6">
                                <div class="wishlist-item position-relative">
                                    <div class="card border-0 rounded-0 h-100">
                                        <!-- Product Image -->
                                        <div class="product-image position-relative overflow-hidden">
                                            <img src="<?php echo $item['main_image']; ?>" 
                                                 class="card-img-top rounded-0" 
                                                 alt="<?php echo htmlspecialchars($item['name']); ?>"
                                                 style="height: 300px; object-fit: cover;">
                                            
                                            <!-- Remove Button -->
                                            <button class="btn btn-link text-dark position-absolute top-0 end-0 m-2 p-0"
                                                    onclick="removeFromWishlist(<?php echo $item['id']; ?>)">
                                                <i class="bi bi-x-circle fs-4"></i>
                                            </button>
                                            
                                            <!-- Sale Badge -->
                                            <?php if ($item['sale_price']): ?>
                                                <div class="position-absolute top-0 start-0 m-2">
                                                    <?php
                                                    $discount = getDiscountPercentage($item['price'], $item['sale_price']);
                                                    if ($discount): ?>
                                                        <span class="badge bg-danger rounded-0"><?php echo $discount; ?> OFF</span>
                                                    <?php endif; ?>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Product Info -->
                                        <div class="card-body px-0 pt-3">
                                            <h6 class="card-title mb-1 fw-normal">
                                                <a href="product.php?slug=<?php echo $item['slug']; ?>" 
                                                   class="text-dark text-decoration-none">
                                                    <?php echo htmlspecialchars($item['name']); ?>
                                                </a>
                                            </h6>
                                            <p class="card-text mb-2 text-muted small"><?php echo htmlspecialchars($item['category_name']); ?></p>
                                            <div class="d-flex align-items-center mb-3">
                                                <?php if ($item['sale_price']): ?>
                                                    <span class="text-dark fw-bold me-2"><?php echo formatPrice($item['sale_price']); ?></span>
                                                    <span class="text-muted text-decoration-line-through small"><?php echo formatPrice($item['price']); ?></span>
                                                <?php else: ?>
                                                    <span class="text-dark fw-bold"><?php echo formatPrice($item['price']); ?></span>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <!-- Stock Status -->
                                            <?php if ($item['stock'] > 0): ?>
                                                <p class="text-success small mb-2">
                                                    <i class="bi bi-check-circle"></i> In Stock
                                                </p>
                                            <?php else: ?>
                                                <p class="text-danger small mb-2">
                                                    <i class="bi bi-x-circle"></i> Out of Stock
                                                </p>
                                            <?php endif; ?>
                                            
                                            <!-- Action Buttons -->
                                            <div class="d-flex gap-2">
                                                <button class="btn btn-dark rounded-0 btn-sm flex-grow-1"
                                                        onclick="addToCartFromWishlist(<?php echo $item['id']; ?>)"
                                                        <?php echo $item['stock'] <= 0 ? 'disabled' : ''; ?>>
                                                    ADD TO CART
                                                </button>
                                                <button class="btn btn-outline-dark rounded-0 btn-sm"
                                                        onclick="removeFromWishlist(<?php echo $item['id']; ?>)">
                                                    <i class="bi bi-trash"></i>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<script>
function removeFromWishlist(productId) {
    if (confirm('Remove from wishlist?')) {
        fetch('ajax/remove_from_wishlist.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ product_id: productId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        });
    }
}

function clearWishlist() {
    if (confirm('Clear all items from wishlist?')) {
        fetch('ajax/clear_wishlist.php')
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                location.reload();
            }
        });
    }
}

function addToCartFromWishlist(productId) {
    fetch('ajax/add_to_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            product_id: productId,
            quantity: 1
        })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Product added to cart!');
        }
    });
}
</script>