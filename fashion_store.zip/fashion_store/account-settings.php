<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Chưa đăng nhập → đá về login
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();

$successMsg = '';
$errorMsg   = '';

// Lấy thông tin user
$stmt = $conn->prepare("SELECT name, email, password FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    die("User not found.");
}

// XỬ LÝ FORM
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // === UPDATE PROFILE ===
    if (isset($_POST['update_profile'])) {
        $name  = trim($_POST['name']);
        $email = trim($_POST['email']);

        if ($name === '' || $email === '') {
            $errorMsg = 'Name and email are required.';
        } else {
            $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
            $stmt->bind_param("ssi", $name, $email, $userId);
            $stmt->execute();
            $stmt->close();

            $successMsg = 'Profile updated successfully.';
            $user['name']  = $name;
            $user['email'] = $email;
        }
    }

    // === CHANGE PASSWORD ===
    if (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'];
        $newPassword     = $_POST['new_password'];
        $confirmPassword = $_POST['confirm_password'];

        if (!password_verify($currentPassword, $user['password'])) {
            $errorMsg = 'Current password is incorrect.';
        } elseif (strlen($newPassword) < 6) {
            $errorMsg = 'New password must be at least 6 characters.';
        } elseif ($newPassword !== $confirmPassword) {
            $errorMsg = 'Password confirmation does not match.';
        } else {
            $newHash = password_hash($newPassword, PASSWORD_DEFAULT);

            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $newHash, $userId);
            $stmt->execute();
            $stmt->close();

            $successMsg = 'Password changed successfully.';
        }
    }
}

$conn->close();

$pageTitle = "Account Settings";
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row">

            <!-- SIDEBAR -->
            <div class="col-lg-3 mb-5">
                <div class="account-sidebar">
                    <div class="user-info text-center mb-4 p-4 border">
                        <div class="avatar-circle bg-dark text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                             style="width:80px;height:80px;">
                            <span class="fs-4"><?php echo strtoupper(substr($user['name'], 0, 1)); ?></span>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['name']); ?></h5>
                        <p class="text-muted small mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>

                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="account.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-person me-2"></i> Account Overview
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="orders.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-bag me-2"></i> My Orders
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="wishlist.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-heart me-2"></i> My Wishlist
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="account-addresses.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-geo-alt me-2"></i> Address Book
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="account-settings.php" class="d-block p-3 border bg-dark text-white text-decoration-none">
                                <i class="bi bi-gear me-2"></i> Account Settings
                            </a>
                        </li>
                        <li>
                            <a href="logout.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-box-arrow-right me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- CONTENT -->
            <div class="col-lg-9">
                <h1 class="fw-light mb-4">ACCOUNT SETTINGS</h1>

                <?php if ($successMsg): ?>
                    <div class="alert alert-success rounded-0"><?php echo $successMsg; ?></div>
                <?php endif; ?>

                <?php if ($errorMsg): ?>
                    <div class="alert alert-danger rounded-0"><?php echo $errorMsg; ?></div>
                <?php endif; ?>

                <!-- PROFILE -->
                <div class="border p-4 mb-5">
                    <h5 class="fw-bold mb-4">Profile Information</h5>

                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control rounded-0"
                                   value="<?php echo htmlspecialchars($user['name']); ?>" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control rounded-0"
                                   value="<?php echo htmlspecialchars($user['email']); ?>" required>
                        </div>

                        <button type="submit" name="update_profile" class="btn btn-dark rounded-0">
                            Save Changes
                        </button>
                    </form>
                </div>

                <!-- PASSWORD -->
                <div class="border p-4">
                    <h5 class="fw-bold mb-4">Change Password</h5>

                    <form method="post">
                        <div class="mb-3">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control rounded-0" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control rounded-0" required>
                        </div>

                        <div class="mb-4">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control rounded-0" required>
                        </div>

                        <button type="submit" name="change_password" class="btn btn-dark rounded-0">
                            Update Password
                        </button>
                    </form>
                </div>

            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
