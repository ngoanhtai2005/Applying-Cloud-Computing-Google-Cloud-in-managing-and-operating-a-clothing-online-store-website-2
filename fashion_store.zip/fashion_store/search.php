<?php
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'includes/product-card.php';

$searchQuery = $_GET['q'] ?? '';
$page = $_GET['page'] ?? 1;
$limit = 12;
$offset = ($page - 1) * $limit;

$conn = getDBConnection();

// Get search results
if (!empty($searchQuery)) {
    $searchTerm = "%" . $searchQuery . "%";
    
    // Count total results
    $stmt = $conn->prepare("SELECT COUNT(*) as total FROM products p 
                           WHERE (p.name LIKE ? OR p.description LIKE ?) AND p.stock > 0");
    $stmt->bind_param("ss", $searchTerm, $searchTerm);
    $stmt->execute();
    $totalResult = $stmt->get_result()->fetch_assoc();
    $totalProducts = $totalResult['total'];
    $stmt->close();
    
    // Get products
    $stmt = $conn->prepare("SELECT p.*, c.name as category_name,
                           (SELECT image_url FROM product_images WHERE product_id = p.id AND is_main = 1 LIMIT 1) as main_image
                           FROM products p
                           LEFT JOIN categories c ON p.category_id = c.id
                           WHERE (p.name LIKE ? OR p.description LIKE ?) AND p.stock > 0
                           ORDER BY p.created_at DESC
                           LIMIT ? OFFSET ?");
    $stmt->bind_param("ssii", $searchTerm, $searchTerm, $limit, $offset);
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();
} else {
    $products = [];
    $totalProducts = 0;
}

$conn->close();

// Calculate total pages
$totalPages = ceil($totalProducts / $limit);

$pageTitle = "Search Results for: " . htmlspecialchars($searchQuery);
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <!-- Search Header -->
        <div class="search-header mb-5">
            <h1 class="fw-light mb-3">SEARCH RESULTS</h1>
            
            <?php if (!empty($searchQuery)): ?>
                <p class="text-muted">
                    Found <?php echo $totalProducts; ?> results for 
                    "<strong><?php echo htmlspecialchars($searchQuery); ?></strong>"
                </p>
            <?php else: ?>
                <p class="text-muted">Please enter a search term</p>
            <?php endif; ?>
            
            <!-- Search Box -->
            <div class="search-box mb-5">
                <form action="search.php" method="GET" class="d-flex">
                    <input type="text" class="form-control rounded-0 py-3" 
                           name="q" 
                           value="<?php echo htmlspecialchars($searchQuery); ?>"
                           placeholder="Search for products..." 
                           required>
                    <button type="submit" class="btn btn-dark rounded-0 px-4">
                        <i class="bi bi-search"></i>
                    </button>
                </form>
            </div>
        </div>
        
        <!-- Search Results -->
        <?php if (empty($searchQuery)): ?>
            <div class="text-center py-5">
                <i class="bi bi-search fs-1 text-muted mb-3"></i>
                <h4 class="text-muted mb-3">What are you looking for?</h4>
                <p class="text-muted mb-4">Try searching for products, categories, or brands</p>
            </div>
        <?php elseif (empty($products)): ?>
            <div class="text-center py-5">
                <i class="bi bi-search fs-1 text-muted mb-3"></i>
                <h4 class="text-muted mb-3">No products found</h4>
                <p class="text-muted mb-4">Try different keywords or browse our categories</p>
                <a href="category.php?category=women" class="btn btn-dark rounded-0 px-5">BROWSE WOMEN</a>
                <a href="category.php?category=men" class="btn btn-outline-dark rounded-0 px-5 ms-2">BROWSE MEN</a>
            </div>
        <?php else: ?>
            <!-- Products Grid -->
            <div class="row g-4">
                <?php foreach ($products as $product): ?>
                    <div class="col-md-3 col-sm-6">
                        <?php renderProductCard($product); ?>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <!-- Pagination -->
            <?php if ($totalPages > 1): ?>
                <nav class="mt-5">
                    <ul class="pagination justify-content-center">
                        <?php if ($page > 1): ?>
                            <li class="page-item">
                                <a class="page-link rounded-0 border-0 text-dark" 
                                   href="?q=<?php echo urlencode($searchQuery); ?>&page=<?php echo $page - 1; ?>">
                                    <i class="bi bi-chevron-left"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                            <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                <a class="page-link rounded-0 border-0 text-dark" 
                                   href="?q=<?php echo urlencode($searchQuery); ?>&page=<?php echo $i; ?>">
                                    <?php echo $i; ?>
                                </a>
                            </li>
                        <?php endfor; ?>
                        
                        <?php if ($page < $totalPages): ?>
                            <li class="page-item">
                                <a class="page-link rounded-0 border-0 text-dark" 
                                   href="?q=<?php echo urlencode($searchQuery); ?>&page=<?php echo $page + 1; ?>">
                                    <i class="bi bi-chevron-right"></i>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </nav>
            <?php endif; ?>
        <?php endif; ?>
        
        <!-- Search Suggestions -->
        <div class="search-suggestions mt-5 pt-5 border-top">
            <h4 class="fw-bold mb-4">POPULAR SEARCHES</h4>
            <div class="d-flex flex-wrap gap-2">
                <a href="search.php?q=shirt" class="btn btn-outline-dark rounded-0">Shirts</a>
                <a href="search.php?q=dress" class="btn btn-outline-dark rounded-0">Dresses</a>
                <a href="search.php?q=jacket" class="btn btn-outline-dark rounded-0">Jackets</a>
                <a href="search.php?q=winter" class="btn btn-outline-dark rounded-0">Winter Wear</a>
                <a href="search.php?q=casual" class="btn btn-outline-dark rounded-0">Casual</a>
                <a href="search.php?q=formal" class="btn btn-outline-dark rounded-0">Formal</a>
                <a href="search.php?q=sale" class="btn btn-outline-dark rounded-0">Sale</a>
                <a href="search.php?q=new" class="btn btn-outline-dark rounded-0">New Arrivals</a>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>