<?php
// --- PHẦN 1: CẤU HÌNH PHP (PHẢI Ở TRÊN CÙNG) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include 'config/database.php';
$conn = getDBConnection();
include 'includes/header.php'; // Gọi giao diện web (CSS/Menu)

// --- PHẦN 2: LOGIC GỬI SMS ---
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $phone = $_POST['phone'];
    
    // Kiểm tra kết nối DB
    if (!$conn) {
        die("Lỗi kết nối CSDL: " . mysqli_connect_error());
    }

    // Kiểm tra SĐT có tồn tại không
    $sql = "SELECT id FROM users WHERE phone = ?";
    $stmt = $conn->prepare($sql);
    
    if (!$stmt) {
        die("Lỗi SQL Prepare: " . $conn->error);
    }
    
    $stmt->bind_param("s", $phone);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        // Tạo mã OTP ngẫu nhiên
        $otp = rand(100000, 999999);
        $_SESSION['otp'] = $otp;
        $_SESSION['reset_phone'] = $phone;
        
        // --- GIẢ LẬP GỬI SMS (Hiện thông báo lên màn hình) ---
        echo "<script>
                alert('Mã OTP của bạn là: $otp');
                window.location.href = 'verify_otp.php';
              </script>";
        exit();
    } else {
        echo "<script>alert('Số điện thoại này chưa đăng ký!');</script>";
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h3 class="text-center mb-3">QUÊN MẬT KHẨU</h3>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Nhập số điện thoại đăng ký</label>
                            <input type="text" name="phone" class="form-control" required placeholder="09xxx...">
                        </div>
                        <button type="submit" class="btn btn-dark w-100">LẤY MÃ XÁC NHẬN</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
