<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Redirect if already logged in
if (isLoggedIn()) {
    header('Location: account.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT id, name, email, password FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    $conn->close();
    
    if ($user && password_verify($password, $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email'] = $user['email'];
        
        // Redirect to previous page or account
        $redirect = $_GET['redirect'] ?? 'account.php';
        header('Location: ' . $redirect);
        exit;
    } else {
        $error = 'Invalid email or password';
    }
}

$pageTitle = "Login";
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-5">
                <div class="auth-card border p-5">
                    <h2 class="fw-light mb-4 text-center">LOGIN</h2>
                    
                    <?php if ($error): ?>
                        <div class="alert alert-danger rounded-0"><?php echo $error; ?></div>
                    <?php endif; ?>
                    
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control rounded-0" name="email" required>
                        </div>
                        
                        <div class="mb-4">
                            <label class="form-label">Password</label>
                            <input type="password" class="form-control rounded-0" name="password" required>
                        </div>
                        
                        <button type="submit" class="btn btn-dark rounded-0 w-100 py-3">LOGIN</button>
                    </form>
                    
                    <div class="text-center mt-4">
                        <a href="forgot_password.php">Forgot password ?</a>
                        <p class="text-muted mt-2 mb-0">Don't have an account?</p>
                        <a href="register.php" class="text-dark fw-bold">CREATE ACCOUNT</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
