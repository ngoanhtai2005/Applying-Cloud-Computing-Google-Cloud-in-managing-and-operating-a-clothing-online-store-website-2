CREATE DATABASE IF NOT EXISTS fashion_store;
USE fashion_store;

-- ================================
-- USERS
-- ================================
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    city VARCHAR(100),
    state VARCHAR(100),
    zip_code VARCHAR(20),
    status ENUM('active','inactive') DEFAULT 'active',
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at DATETIME
);

-- ================================
-- CATEGORIES
-- ================================
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    parent_id INT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ================================
-- PRODUCTS
-- ================================
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    slug VARCHAR(200) UNIQUE NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    sale_price DECIMAL(10,2),
    category_id INT NOT NULL,
    featured BOOLEAN DEFAULT FALSE,
    best_seller BOOLEAN DEFAULT FALSE,
    stock INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- PRODUCT IMAGES
-- ================================
CREATE TABLE product_images (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    image_url VARCHAR(255) NOT NULL,
    is_main BOOLEAN DEFAULT FALSE
);

-- ================================
-- PRODUCT ATTRIBUTES
-- ================================
CREATE TABLE product_attributes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    size VARCHAR(20),
    color VARCHAR(50),
    stock INT DEFAULT 0
);

-- ================================
-- ORDERS
-- ================================
-- ================================
-- ORDERS (Đã cập nhật thêm payment_status)
-- ================================
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    order_number VARCHAR(50) UNIQUE NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    payment_status ENUM('pending', 'paid', 'failed') DEFAULT 'pending', -- <--- DÒNG MỚI THÊM
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
-- ================================
-- PAYMENT TRANSACTIONS (Bảng mới để lưu lịch sử chuyển khoản)
-- ================================
CREATE TABLE payment_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_number VARCHAR(50) NOT NULL, -- Lưu mã đơn hàng (VD: ORD2026...)
    transaction_content TEXT,          -- Nội dung chuyển khoản
    amount DECIMAL(15,2),              -- Số tiền chuyển
    bank_code VARCHAR(20),             -- Mã ngân hàng (VD: VCB, MB)
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (order_number) REFERENCES orders(order_number) ON DELETE CASCADE
);
-- ================================
-- ORDER ITEMS
-- ================================
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    size VARCHAR(20),
    color VARCHAR(50)
);

-- ================================
-- REVIEWS
-- ================================
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    rating TINYINT NOT NULL,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- WISHLIST
-- ================================
CREATE TABLE wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    product_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_wishlist (user_id, product_id)
);

-- ================================
-- ADMIN USERS
-- ================================
CREATE TABLE admin_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100),
    role ENUM('super_admin','admin','editor') DEFAULT 'admin',
    status ENUM('active','inactive') DEFAULT 'active',
    last_login DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- SITE SETTINGS
-- ================================
CREATE TABLE site_settings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    setting_key VARCHAR(100) UNIQUE NOT NULL,
    setting_value TEXT,
    setting_type ENUM('text','textarea','number','email','url','boolean') DEFAULT 'text',
    setting_group VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ================================
-- BANNERS
-- ================================
CREATE TABLE banners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    subtitle VARCHAR(200),
    image_url VARCHAR(255) NOT NULL,
    button_text VARCHAR(50),
    button_url VARCHAR(255),
    position INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    start_date DATE,
    end_date DATE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- PROMOTIONS
-- ================================
CREATE TABLE promotions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    discount_type ENUM('percentage','fixed','free_shipping') DEFAULT 'percentage',
    discount_value DECIMAL(10,2),
    minimum_amount DECIMAL(10,2),
    promo_code VARCHAR(50) UNIQUE,
    start_date DATE,
    end_date DATE,
    usage_limit INT,
    times_used INT DEFAULT 0,
    status ENUM('active','inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- AUDIT LOGS
-- ================================
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    admin_id INT NULL,
    action VARCHAR(100) NOT NULL,
    resource_type VARCHAR(50),
    resource_id INT,
    details TEXT,
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ================================
-- FOREIGN KEYS
-- ================================
ALTER TABLE categories
ADD CONSTRAINT fk_category_parent
FOREIGN KEY (parent_id) REFERENCES categories(id)
ON DELETE SET NULL;

ALTER TABLE products
ADD CONSTRAINT fk_product_category
FOREIGN KEY (category_id) REFERENCES categories(id);

ALTER TABLE product_images
ADD CONSTRAINT fk_image_product
FOREIGN KEY (product_id) REFERENCES products(id)
ON DELETE CASCADE;

ALTER TABLE product_attributes
ADD CONSTRAINT fk_attr_product
FOREIGN KEY (product_id) REFERENCES products(id)
ON DELETE CASCADE;

ALTER TABLE orders
ADD COLUMN subtotal DECIMAL(10,2) NOT NULL AFTER order_number,
ADD COLUMN shipping_fee DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER subtotal,
ADD COLUMN tax DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER shipping_fee,
ADD COLUMN payment_method VARCHAR(50) NOT NULL AFTER tax,
ADD COLUMN shipping_name VARCHAR(255),
ADD COLUMN shipping_phone VARCHAR(20),
ADD COLUMN shipping_city VARCHAR(100),
ADD COLUMN shipping_state VARCHAR(100),
ADD COLUMN shipping_zip VARCHAR(20),
ADD COLUMN shipping_country VARCHAR(50);

ALTER TABLE orders
ADD CONSTRAINT fk_order_user
FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE order_items
ADD CONSTRAINT fk_item_order
FOREIGN KEY (order_id) REFERENCES orders(id)
ON DELETE CASCADE;

ALTER TABLE order_items
ADD CONSTRAINT fk_item_product
FOREIGN KEY (product_id) REFERENCES products(id);

ALTER TABLE reviews
ADD CONSTRAINT fk_review_product
FOREIGN KEY (product_id) REFERENCES products(id)
ON DELETE CASCADE;

ALTER TABLE reviews
ADD CONSTRAINT fk_review_user
FOREIGN KEY (user_id) REFERENCES users(id);

ALTER TABLE wishlist
ADD CONSTRAINT fk_wishlist_user
FOREIGN KEY (user_id) REFERENCES users(id)
ON DELETE CASCADE;

ALTER TABLE wishlist
ADD CONSTRAINT fk_wishlist_product
FOREIGN KEY (product_id) REFERENCES products(id)
ON DELETE CASCADE;

ALTER TABLE audit_logs
ADD CONSTRAINT fk_audit_admin
FOREIGN KEY (admin_id) REFERENCES admin_users(id)
ON DELETE SET NULL;

-- ================================
-- INDEXES
-- ================================
CREATE INDEX idx_admin_username ON admin_users(username);
CREATE INDEX idx_admin_email ON admin_users(email);
CREATE INDEX idx_banner_status ON banners(status);
CREATE INDEX idx_promo_code ON promotions(promo_code);

-- ================================
-- SAMPLE DATA
-- ================================
INSERT INTO users (name, email, password, phone, address, city)
VALUES
('Nguyễn Văn A', 'a@gmail.com', '$2y$10$hash1', '0901111111', '123 Lê Lợi', 'HCM'),
('Trần Thị B', 'b@gmail.com', '$2y$10$hash2', '0902222222', '456 Hai Bà Trưng', 'HCM'),
('Lê Văn C', 'c@gmail.com', '$2y$10$hash3', '0903333333', '789 Nguyễn Huệ', 'Hà Nội');

INSERT INTO admin_users (username, email, password, full_name, role)
VALUES
('admin', 'admin@store.com', '$2y$10$adminhash', 'Super Admin', 'super_admin'),
('editor', 'editor@store.com', '$2y$10$editorhash', 'Content Editor', 'editor');

INSERT INTO categories (name, slug, parent_id) VALUES
('Women', 'women', NULL),
('Men', 'men', NULL),
('Accessories', 'accessories', NULL),
('Shirts', 'shirts', 1),
('Pants', 'pants', 1),
('Dresses', 'dresses', 1),
('Jackets', 'jackets', 1);

INSERT INTO products
(name, slug, description, price, sale_price, category_id, featured, best_seller, stock)
VALUES
('WarmMax Thermal Shirt', 'warmmax-shirt', 'Áo giữ nhiệt cao cấp', 79.99, 69.99, 4, 1, 1, 50),
('Minimalist Wool Coat', 'wool-coat', 'Áo khoác len cao cấp', 299.99, NULL, 7, 1, 0, 20),
('Organic Cotton T-Shirt', 'cotton-shirt', 'Áo cotton hữu cơ', 34.99, 29.99, 4, 0, 1, 100),
('Sport Jacket', 'sport-jacket', 'Áo khoác thể thao', 159.99, NULL, 7, 1, 1, 30);

INSERT INTO product_images (product_id, image_url, is_main)
VALUES
(1, 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea', 1),
(1, 'https://images.unsplash.com/photo-1586790170083-2f9ceadc732d', 0),
(2, 'https://images.unsplash.com/photo-1551028719-00167b16eac5', 1),
(3, 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab', 1),
(4, 'https://images.unsplash.com/photo-1624378439575-d8705ad7ae80', 1);

INSERT INTO product_attributes (product_id, size, color, stock)
VALUES
(1, 'S', 'Black', 10),
(1, 'M', 'Black', 15),
(1, 'L', 'Black', 12),
(1, 'M', 'White', 10),
(2, 'M', 'Beige', 8),
(3, 'S', 'White', 20),
(3, 'M', 'White', 30),
(4, 'M', 'Black', 12),
(4, 'L', 'Black', 18);

INSERT INTO wishlist (user_id, product_id)
VALUES
(1, 1),
(1, 3),
(2, 2);

INSERT INTO reviews (product_id, user_id, rating, comment)
VALUES
(1, 1, 5, 'Áo rất ấm, chất lượng tốt'),
(1, 2, 4, 'Mặc thoải mái, hơi rộng'),
(3, 3, 5, 'Vải mềm, rất thích'),
(4, 1, 4, 'Áo đẹp, giao hàng nhanh');

INSERT INTO orders (
    user_id, order_number, subtotal, shipping_fee, tax, total_amount, 
    payment_method, shipping_name, shipping_phone, shipping_city, 
    shipping_state, shipping_zip, shipping_country, status, payment_status
) VALUES (
    1, 'ORD20260101', 129.98, 0, 10.40, 140.38, 
    'cod', 'Nguyễn Văn A', '0901111111', 'HCM', 
    'HCM', '700000', 'VN', 'pending', 'pending'
);
INSERT INTO order_items (order_id, product_id, quantity, price, size, color)
VALUES
(1, 1, 1, 69.99, 'M', 'Black'),
(1, 3, 2, 29.99, 'M', 'White'),
(1, 2, 1, 299.99, 'M', 'Beige');


INSERT INTO banners (title, subtitle, image_url, button_text, button_url, position)
VALUES
('New Collection', 'Xu hướng mới nhất', 'https://images.unsplash.com/photo-1445205170230-053b83016050', 'Shop Now', '/category/new', 1),
('Winter Sale', 'Giảm giá đến 50%', 'https://images.unsplash.com/photo-1539109136881-3be0616acf4b', 'View Sale', '/category/sale', 2);

INSERT INTO promotions
(title, description, discount_type, discount_value, minimum_amount, promo_code, start_date, end_date)
VALUES
('New Year Sale', 'Giảm 20% đơn hàng', 'percentage', 20, 100, 'NEWYEAR20', '2026-01-01', '2026-01-31'),
('Free Shipping', 'Miễn phí vận chuyển', 'free_shipping', NULL, 200, 'FREESHIP', '2026-01-01', '2026-02-01');

INSERT INTO site_settings (setting_key, setting_value, setting_group)
VALUES
('site_title', 'Fashion Store', 'general'),
('currency', 'VND', 'general'),
('shipping_cost', '30000', 'general'),
('facebook_url', 'https://facebook.com/fashion', 'social');
