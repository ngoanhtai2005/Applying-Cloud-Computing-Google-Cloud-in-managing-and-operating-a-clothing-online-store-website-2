<?php
// 1. Bật báo lỗi để nếu có gì sai nó hiện ra ngay
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// 2. KẾT NỐI DATABASE CHUẨN (Đã sửa đường dẫn)
include 'config/database.php'; 
$conn = getDBConnection();

include 'includes/header.php';

// Chặn truy cập nếu chưa xác nhận OTP
if (!isset($_SESSION['otp_verified'])) {
    echo "<script>window.location.href='forgot_password.php';</script>";
    exit();
}

$msg = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pass1 = $_POST['new_pass'];
    $pass2 = $_POST['confirm_pass'];
    $phone = $_SESSION['reset_phone'];
    
    if ($pass1 !== $pass2) {
        $msg = "<div class='alert alert-danger'>Mật khẩu xác nhận không khớp!</div>";
    } else {
        // Mã hóa mật khẩu
        $hashed_password = password_hash($pass1, PASSWORD_DEFAULT); 
        
        // Cập nhật vào DB
        $sql = "UPDATE users SET password = ? WHERE phone = ?";
        $stmt = $conn->prepare($sql);
        
        if (!$stmt) {
             die("Lỗi SQL: " . $conn->error);
        }

        $stmt->bind_param("ss", $hashed_password, $phone);
        
        if ($stmt->execute()) {
            // Xóa session
            session_destroy();
            
            // --- ĐIỀU HƯỚNG VỀ TRANG ĐĂNG NHẬP ---
            echo "<script>
                    alert('Đổi mật khẩu thành công! Hãy đăng nhập lại.');
                    window.location.href = 'login.php'; 
                  </script>";
            exit();
        } else {
            $msg = "<div class='alert alert-danger'>Lỗi: " . $stmt->error . "</div>";
        }
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h3 class="text-center mb-3">ĐẶT MẬT KHẨU MỚI</h3>
                    <?php echo $msg; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Mật khẩu mới</label>
                            <input type="password" name="new_pass" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nhập lại mật khẩu</label>
                            <input type="password" name="confirm_pass" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-dark w-100">CẬP NHẬT & ĐĂNG NHẬP</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
