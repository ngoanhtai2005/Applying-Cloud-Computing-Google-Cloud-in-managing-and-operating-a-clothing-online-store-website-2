<?php
// cancel_order.php
header('Content-Type: application/json');

// Kết nối CSDL (Sửa đường dẫn nếu cần thiết cho đúng với code của bạn)
if (file_exists('config/db.php')) include 'config/db.php';
elseif (file_exists('../config/db.php')) include '../config/db.php';
else include 'includes/db.php'; 

if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    
    // Cập nhật trạng thái thành 'cancelled'
    // Lưu ý: Dùng order_number hoặc id tùy theo cách bạn lưu trong bảng orders
    $sql = "UPDATE orders SET status = 'cancelled' WHERE order_number = '$order_id'";
    
    if (mysqli_query($conn, $sql)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
}
?>
