<?php
session_start();
header('Content-type: text/html; charset=utf-8');

function execPostRequest($url, $data) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data))
    );
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}

/* ============================================================
   LẤY DỮ LIỆU TỪ SESSION (Để hiển thị lên giao diện)
   ============================================================ */
$partnerCode = 'MOMOBKUN20180529';
$accessKey   = 'klm05TvNBzhg7h7j';
$secretKey   = 'at67qH6mk8w5Y1nAyMoYKMWACiEi2bsa';

// Dữ liệu mặc định lấy từ đơn hàng vừa tạo ở Checkout
$orderId     = $_SESSION['order_number'] ?? (time() . "");
$amount      = $_SESSION['total_momo'] ?? 0;
$orderInfo   = "Thanh toán đơn hàng #" . $orderId;
$extraData   = "";
$ipnUrl      = "http://35.220.163.38/fashion_store/order-confirmation.php";
$redirectUrl = "http://35.220.163.38/fashion_store/order-confirmation.php?order=" . $orderId;

/* ============================================================
   XỬ LÝ KHI NGƯỜI DÙNG NHẤN NÚT "START MOMO PAYMENT"
   ============================================================ */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Lấy dữ liệu từ Form (lúc này dùng $_POST là chính xác)
    $partnerCode = $_POST["partnerCode"];
    $accessKey   = $_POST["accessKey"];
    $secretKey   = $_POST["secretKey"]; // Đã sửa tên biến secretKey
    $orderId     = $_POST["orderId"];
    $orderInfo   = $_POST["orderInfo"];
    $amount      = $_POST["amount"];
    $ipnUrl      = $_POST["ipnUrl"];
    $redirectUrl = $_POST["redirectUrl"];
    $extraData   = $_POST["extraData"];

    $requestId   = time() . "";
    $requestType = "payWithATM"; // Cổng thanh toán ATM

    // Tạo chữ ký HMAC SHA256
    $rawHash = "accessKey=" . $accessKey . "&amount=" . $amount . "&extraData=" . $extraData . "&ipnUrl=" . $ipnUrl . "&orderId=" . $orderId . "&orderInfo=" . $orderInfo . "&partnerCode=" . $partnerCode . "&redirectUrl=" . $redirectUrl . "&requestId=" . $requestId . "&requestType=" . $requestType;
    $signature = hash_hmac("sha256", $rawHash, $secretKey);

    $data = array(
        'partnerCode' => $partnerCode,
        'partnerName' => "Fashion Store",
        "storeId"     => "MomoTestStore",
        'requestId'   => $requestId,
        'amount'      => $amount,
        'orderId'     => $orderId,
        'orderInfo'   => $orderInfo,
        'redirectUrl' => $redirectUrl,
        'ipnUrl'      => $ipnUrl,
        'lang'        => 'vi',
        'extraData'   => $extraData,
        'requestType' => $requestType,
        'signature'   => $signature
    );

    $result = execPostRequest("https://test-payment.momo.vn/v2/gateway/api/create", json_encode($data));
    $jsonResult = json_decode($result, true);

    if (isset($jsonResult['payUrl'])) {
        header('Location: ' . $jsonResult['payUrl']);
        exit;
    } else {
        echo "<script>alert('Lỗi: " . ($jsonResult['message'] ?? 'Không thể kết nối MoMo') . "');</script>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Xác nhận thanh toán MoMo</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.4.1/css/bootstrap.min.css"/>
    <style>
        body { background: #f8f9fa; padding-top: 50px; }
        .panel { border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }
        .panel-heading { background: #a50064 !important; color: white !important; border-radius: 10px 10px 0 0; }
        .btn-momo { background: #a50064; color: white; font-weight: bold; }
        .btn-momo:hover { background: #82004f; color: white; }
    </style>
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading text-center">
                    <h3 class="panel-title">THÔNG TIN THANH TOÁN MOMO (ATM)</h3>
                </div>
                <div class="panel-body">
                    <form method="POST" action="">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Mã Đơn Hàng (OrderId)</label>
                                    <input type="text" name="orderId" value="<?php echo $orderId; ?>" class="form-control" readonly/>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Số Tiền (VNĐ)</label>
                                    <input type="text" name="amount" value="<?php echo $amount; ?>" class="form-control" readonly/>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Nội dung thanh toán</label>
                            <input type="text" name="orderInfo" value="<?php echo $orderInfo; ?>" class="form-control"/>
                        </div>

                        <input type="hidden" name="partnerCode" value="<?php echo $partnerCode; ?>">
                        <input type="hidden" name="accessKey" value="<?php echo $accessKey; ?>">
                        <input type="hidden" name="secretKey" value="<?php echo $secretKey; ?>">
                        <input type="hidden" name="ipnUrl" value="<?php echo $ipnUrl; ?>">
                        <input type="hidden" name="redirectUrl" value="<?php echo $redirectUrl; ?>">
                        <input type="hidden" name="extraData" value="<?php echo $extraData; ?>">

                        <div class="well">
                            <p class="text-info small">* Bạn đang thực hiện giao dịch trong môi trường Test (Sandbox).</p>
                            <button type="submit" class="btn btn-momo btn-lg btn-block">TIẾP TỤC THANH TOÁN</button>
                            <a href="checkout.php" class="btn btn-default btn-block">Quay lại</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>
