<?php
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'includes/product-card.php';

$pageTitle = "Premium Fashion Store";
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<!-- Hero Carousel -->
<section class="hero-carousel">
    <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="0" class="active"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="1"></button>
            <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="https://images.unsplash.com/photo-1445205170230-053b83016050?w=1600" class="d-block w-100" alt="New Collection" style="height: 600px; object-fit: cover;">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-light mb-3">NEW COLLECTION</h2>
                    <p class="lead">Timeless pieces for modern living</p>
                    <a href="category.php?category=new" class="btn btn-outline-light rounded-0 px-4">SHOP NOW</a>
                </div>
            </div>

            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1539109136881-3be0616acf4b?w=1600" class="d-block w-100" alt="Winter Essentials" style="height: 600px; object-fit: cover;">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-light mb-3">WINTER ESSENTIALS</h2>
                    <p class="lead">Stay warm in style</p>
                    <a href="category.php?category=warmwear" class="btn btn-outline-light rounded-0 px-4">EXPLORE</a>
                </div>
            </div>

            <div class="carousel-item">
                <img src="https://images.unsplash.com/photo-1483985988355-763728e1935b?w=1600" class="d-block w-100" alt="Summer Vibes" style="height: 600px; object-fit: cover;">
                <div class="carousel-caption d-none d-md-block">
                    <h2 class="display-4 fw-light mb-3">SUMMER VIBES</h2>
                    <p class="lead">Fresh looks for the new season</p>
                    <a href="category.php?category=summer" class="btn btn-outline-light rounded-0 px-4">DISCOVER</a>
                </div>
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
            <span class="carousel-control-prev-icon"></span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
            <span class="carousel-control-next-icon"></span>
        </button>
    </div>
</section>

<!-- Featured Collections -->
<section class="py-5">
    <div class="container">
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h2 class="fw-light mb-3">FEATURED COLLECTIONS</h2>
                <p class="text-muted">Curated selections for every occasion</p>
            </div>
        </div>
        <div class="row g-4">
            <div class="col-md-4">
                <div class="collection-card position-relative overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?w=800" alt="Women's Wear" class="img-fluid" style="height: 400px; object-fit: cover;">
                    <div class="collection-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark bg-opacity-25 d-flex align-items-end">
                        <div class="p-4">
                            <h3 class="text-white mb-2">Women's Wear</h3>
                            <a href="category.php?category=women" class="btn btn-outline-light rounded-0">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection-card position-relative overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=800" alt="Men's Collection" class="img-fluid" style="height: 400px; object-fit: cover;">
                    <div class="collection-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark bg-opacity-25 d-flex align-items-end">
                        <div class="p-4">
                            <h3 class="text-white mb-2">Men's Collection</h3>
                            <a href="category.php?category=men" class="btn btn-outline-light rounded-0">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="collection-card position-relative overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1511556820780-d912e42b4980?w=800" alt="Accessories" class="img-fluid" style="height: 400px; object-fit: cover;">
                    <div class="collection-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark bg-opacity-25 d-flex align-items-end">
                        <div class="p-4">
                            <h3 class="text-white mb-2">Accessories</h3>
                            <a href="category.php?category=accessories" class="btn btn-outline-light rounded-0">SHOP NOW</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Best Sellers -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-5">
            <div class="col-12 text-center">
                <h2 class="fw-light mb-3">BEST SELLERS</h2>
                <p class="text-muted">Our most loved pieces</p>
            </div>
        </div>
        <div class="row g-4">
            <?php
            $conn = getDBConnection();
            $stmt = $conn->prepare("SELECT p.*, c.name as category_name, 
                                   (SELECT image_url FROM product_images WHERE product_id = p.id AND is_main = 1 LIMIT 1) as main_image
                                   FROM products p
                                   LEFT JOIN categories c ON p.category_id = c.id
                                   WHERE p.best_seller = 1 AND p.stock > 0
                                   LIMIT 4");
            $stmt->execute();
            $result = $stmt->get_result();
            $bestSellers = $result->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
            $conn->close();
            
            foreach ($bestSellers as $product) {
                echo '<div class="col-md-3">';
                renderProductCard($product);
                echo '</div>';
            }
            ?>
        </div>
        <div class="row mt-5">
            <div class="col-12 text-center">
                <a href="category.php?sort=best_seller" class="btn btn-outline-dark rounded-0 px-5">VIEW ALL</a>
            </div>
        </div>
    </div>
</section>

<!-- Promotional Banner -->
<section class="py-5">
    <div class="container">
        <div class="promotional-banner bg-dark text-white p-5 text-center">
            <h2 class="display-5 fw-light mb-3">SUSTAINABLE FASHION</h2>
            <p class="lead mb-4">Join us in making fashion better for the planet</p>
            <a href="#" class="btn btn-outline-light rounded-0 px-4">LEARN MORE</a>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
