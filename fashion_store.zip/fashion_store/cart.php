<?php
session_start();
require_once 'config/database.php';
require_once 'config/functions.php';

$pageTitle = "Shopping Cart";
include 'includes/header.php';
include 'includes/navbar.php';
?>

<section class="py-5">
<div class="container">
<h1 class="fw-light mb-5">SHOPPING CART</h1>

<?php if (empty($_SESSION['cart'])): ?>

    <div class="text-center py-5">
        <i class="bi bi-bag fs-1 text-muted mb-3"></i>
        <h4 class="text-muted">Your cart is empty</h4>
       <a href="index.php" class="btn btn-dark rounded-0 px-5 mt-3">
            SHOP NOW
        </a>
    </div>

<?php else: ?>

<div class="row">
<div class="col-lg-8">

<?php
$conn = getDBConnection();
$total = 0;

foreach ($_SESSION['cart'] as $key => $item):

    $stmt = $conn->prepare("
        SELECT p.id, p.name, p.price, p.sale_price,
        (SELECT image_url FROM product_images 
         WHERE product_id = p.id AND is_main = 1 LIMIT 1) AS main_image
        FROM products p
        WHERE p.id = ?
    ");
    $stmt->bind_param("i", $item['product_id']);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) continue;

    $price = $product['sale_price'] ?: $product['price'];
    $itemTotal = $price * $item['quantity'];
    $total += $itemTotal;
?>

<div class="border-bottom py-4">
<div class="row align-items-center">

<!-- IMAGE -->
<div class="col-md-2">
<img src="<?= $product['main_image'] ?: 'assets/no-image.jpg' ?>"
     class="img-fluid" style="height:90px;object-fit:cover">
</div>

<!-- INFO -->
<div class="col-md-4">
<h6><?= htmlspecialchars($product['name']) ?></h6>
<?php if (!empty($item['size'])): ?>
<p class="small text-muted">Size: <?= $item['size'] ?></p>
<?php endif; ?>
<?php if (!empty($item['color'])): ?>
<p class="small text-muted">Color: <?= $item['color'] ?></p>
<?php endif; ?>
</div>

<!-- PRICE -->
<div class="col-md-2 fw-bold">
<?= formatPrice($price) ?>
</div>

<!-- QTY -->
<div class="col-md-2">
<div class="input-group">
<button class="btn btn-outline-dark rounded-0"
onclick="updateQty('<?= $key ?>',-1)">-</button>
<input class="form-control text-center rounded-0" value="<?= $item['quantity'] ?>" readonly>
<button class="btn btn-outline-dark rounded-0"
onclick="updateQty('<?= $key ?>',1)">+</button>
</div>
</div>

<!-- TOTAL -->
<div class="col-md-2 text-end">
<strong><?= formatPrice($itemTotal) ?></strong><br>
<button class="btn btn-link text-danger p-0"
onclick="removeItem('<?= $key ?>')">REMOVE</button>
</div>

</div>
</div>

<?php endforeach; $conn->close(); ?>

<a href="category.php?category=women" class="text-dark">
← Continue shopping
</a>

</div>

<!-- SUMMARY -->
<div class="col-lg-4">
<div class="bg-light p-4">
<h5 class="fw-bold mb-4">ORDER SUMMARY</h5>

<div class="d-flex justify-content-between mb-2">
<span>Subtotal</span>
<strong><?= formatPrice($total) ?></strong>
</div>

<div class="d-flex justify-content-between mb-3">
<span>Shipping</span>
<strong><?= $total > 100 ? 'FREE' : formatPrice(9.99) ?></strong>
</div>

<hr>

<div class="d-flex justify-content-between mb-4">
<h5>Total</h5>
<h5>
<?= formatPrice($total + ($total > 100 ? 0 : 9.99)) ?>
</h5>
</div>

<a href="checkout.php" class="btn btn-dark w-100 rounded-0 py-3">
CHECKOUT
</a>

</div>
</div>

</div>
<?php endif; ?>
</div>
</section>

<?php include 'includes/footer.php'; ?>

<script>
function updateQty(key, change){
fetch('ajax/update_cart.php',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({key,change})
}).then(()=>location.reload());
}
function removeItem(key){
if(confirm('Remove item?')){
fetch('ajax/remove_from_cart.php',{
method:'POST',
headers:{'Content-Type':'application/json'},
body:JSON.stringify({key})
}).then(()=>location.reload());
}
}
</script>
