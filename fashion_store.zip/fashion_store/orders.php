<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();

// Lấy thông tin user
$stmt = $conn->prepare("SELECT name, email FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$user) {
    die("User not found.");
}

// Lấy danh sách đơn hàng
$stmt = $conn->prepare("
    SELECT *
    FROM orders
    WHERE user_id = ?
    ORDER BY created_at DESC
");
$stmt->bind_param("i", $userId);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$conn->close();

$pageTitle = "My Orders";
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- SIDEBAR -->
            <div class="col-lg-3 mb-5">
                <div class="account-sidebar">
                    <div class="user-info text-center mb-4 p-4 border">
                        <div class="avatar-circle bg-dark text-white rounded-circle d-inline-flex align-items-center justify-content-center mb-3"
                             style="width:80px;height:80px;">
                            <span class="fs-4">
                                <?php echo strtoupper(substr($user['name'], 0, 1)); ?>
                            </span>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['name']); ?></h5>
                        <p class="text-muted small mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>

                    <ul class="list-unstyled">
                        <li class="mb-2">
                            <a href="account.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-person me-2"></i> Account Overview
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="orders.php" class="d-block p-3 border bg-dark text-white text-decoration-none">
                                <i class="bi bi-bag me-2"></i> My Orders
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="wishlist.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-heart me-2"></i> My Wishlist
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="account-addresses.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-geo-alt me-2"></i> Address Book
                            </a>
                        </li>
                        <li class="mb-2">
                            <a href="account-settings.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-gear me-2"></i> Account Settings
                            </a>
                        </li>
                        <li>
                            <a href="logout.php" class="d-block p-3 border text-dark text-decoration-none">
                                <i class="bi bi-box-arrow-right me-2"></i> Logout
                            </a>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- CONTENT -->
            <div class="col-lg-9">
                <h1 class="fw-light mb-4">MY ORDERS</h1>

                <?php if (empty($orders)): ?>
                    <div class="text-center py-5 border">
                        <i class="bi bi-bag fs-1 text-muted mb-3"></i>
                        <h5 class="text-muted mb-3">You have no orders yet</h5>
                        <a href="category.php?category=all" class="btn btn-dark rounded-0">
                            START SHOPPING
                        </a>
                    </div>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle">
                            <thead>
                                <tr>
                                    <th>Order #</th>
                                    <th>Date</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($orders as $order): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                        <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                        <td><?php echo formatPrice($order['total_amount']); ?></td>
                                        <td>
                                            <span class="badge rounded-0
                                                <?php
                                                echo $order['status'] === 'delivered' ? 'bg-success' :
                                                    ($order['status'] === 'processing' ? 'bg-primary' :
                                                    ($order['status'] === 'shipped' ? 'bg-info' : 'bg-warning'));
                                                ?>">
                                                <?php echo ucfirst($order['status']); ?>
                                            </span>
                                        </td>
                                        <td>
                                            <a href="order-details.php?order=<?php echo $order['order_number']; ?>"
                                               class="text-dark text-decoration-none border-bottom">
                                                View
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
