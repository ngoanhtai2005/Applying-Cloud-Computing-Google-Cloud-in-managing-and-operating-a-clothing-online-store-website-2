<?php
require_once 'config/database.php';
require_once 'config/functions.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_SESSION['cart'])) {
    $conn = getDBConnection();
    $userId = getCurrentUserId();
    
    // 1. Lấy thông tin từ Form
    $fullName = $_POST['first_name'] . ' ' . $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'] . ', ' . $_POST['city'];
    $total = $_POST['total_amount']; // Bạn nên tính lại ở server để bảo mật

    // 2. Lưu vào bảng orders
    $stmt = $conn->prepare("INSERT INTO orders (user_id, full_name, email, phone, address, total_amount) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssd", $userId, $fullName, $email, $phone, $address, $total);
    
    if ($stmt->execute()) {
        $orderId = $conn->insert_id;

        // 3. Lưu chi tiết vào order_items
        foreach ($_SESSION['cart'] as $item) {
            $itemStmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price, size, color) VALUES (?, ?, ?, ?, ?, ?)");
            $itemStmt->bind_param("iiidss", $orderId, $item['product_id'], $item['quantity'], $item['price'], $item['size'], $item['color']);
            $itemStmt->execute();
        }

        // 4. Xóa giỏ hàng và chuyển hướng
        unset($_SESSION['cart']);
        header("Location: success.php?order_id=" . $orderId);
        exit;
    }
}
?>