// Main JavaScript for Fashion Store

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Add to cart animation
    const addToCartButtons = document.querySelectorAll('.btn-add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const cartBadge = document.querySelector('.cart-badge');
            
            // Animate button
            this.classList.add('btn-success');
            this.innerHTML = '<i class="bi bi-check"></i> Added';
            
            setTimeout(() => {
                this.classList.remove('btn-success');
                this.innerHTML = '<i class="bi bi-cart-plus"></i> Add to Cart';
            }, 2000);
        });
    });

    // Wishlist toggle
    const wishlistButtons = document.querySelectorAll('.btn-wishlist');
    wishlistButtons.forEach(button => {
        button.addEventListener('click', function() {
            this.classList.toggle('active');
            if (this.classList.contains('active')) {
                this.innerHTML = '<i class="bi bi-heart-fill text-danger"></i>';
            } else {
                this.innerHTML = '<i class="bi bi-heart"></i>';
            }
        });
    });

    // Image lazy loading
    const images = document.querySelectorAll('img[data-src]');
    const imageOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px 50px 0px'
    };

    const imageObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const img = entry.target;
                img.src = img.dataset.src;
                img.removeAttribute('data-src');
                observer.unobserve(img);
            }
        });
    }, imageOptions);

    images.forEach(img => imageObserver.observe(img));

    // Form validation
    const forms = document.querySelectorAll('.needs-validation');
    Array.from(forms).forEach(form => {
        form.addEventListener('submit', event => {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            form.classList.add('was-validated');
        }, false);
    });

    // Price range slider
    const priceRange = document.getElementById('priceRange');
    if (priceRange) {
        noUiSlider.create(priceRange, {
            start: [20, 200],
            connect: true,
            range: {
                'min': 0,
                'max': 500
            },
            step: 10
        });

        const minPrice = document.getElementById('minPrice');
        const maxPrice = document.getElementById('maxPrice');

        priceRange.noUiSlider.on('update', function(values) {
            minPrice.value = Math.round(values[0]);
            maxPrice.value = Math.round(values[1]);
        });
    }

    // Quick view modal
    const quickViewButtons = document.querySelectorAll('.btn-quick-view');
    quickViewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productSlug = this.dataset.slug;
            // Load product data via AJAX and show modal
            fetch(`ajax/quick_view.php?slug=${productSlug}`)
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        // Update modal content
                        document.getElementById('quickViewModal').innerHTML = data.html;
                        // Show modal
                        const modal = new bootstrap.Modal(document.getElementById('quickViewModal'));
                        modal.show();
                    }
                });
        });
    });

    // Newsletter subscription
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            
            fetch('ajax/subscribe.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email: email })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.innerHTML = '<div class="alert alert-success mb-0">Thank you for subscribing!</div>';
                }
            });
        });
    }

    // Mobile menu enhancements
    const navbarToggler = document.querySelector('.navbar-toggler');
    const navbarCollapse = document.querySelector('.navbar-collapse');
    
    if (navbarToggler) {
        navbarToggler.addEventListener('click', function() {
            navbarCollapse.classList.toggle('show');
        });
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add to cart with AJAX
    window.addToCartAjax = function(productId, quantity = 1) {
        fetch('ajax/add_to_cart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                product_id: productId,
                quantity: quantity
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                // Update cart count
                const cartBadge = document.querySelector('.cart-badge');
                if (cartBadge) {
                    cartBadge.textContent = data.cartCount;
                    cartBadge.classList.add('animate__animated', 'animate__bounce');
                    setTimeout(() => {
                        cartBadge.classList.remove('animate__animated', 'animate__bounce');
                    }, 1000);
                }
                
                // Show notification
                showNotification('Product added to cart!', 'success');
            }
        });
    };

    // Notification function
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `alert alert-${type} alert-dismissible fade show position-fixed`;
        notification.style.cssText = `
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
        `;
        notification.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.remove();
        }, 3000);
    }
});

// Add to wishlist function
function addToWishlist(productId) {
    fetch('ajax/add_to_wishlist.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ product_id: productId })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            showNotification('Added to wishlist!', 'success');
        }
    });
}

// Update quantity function
function updateQuantity(input, change) {
    const current = parseInt(input.value);
    const newValue = current + change;
    
    if (newValue >= 1 && newValue <= 10) {
        input.value = newValue;
    }
}

// Size selection
function selectSize(size, element) {
    document.querySelectorAll('.size-btn').forEach(btn => {
        btn.classList.remove('active', 'btn-dark');
        btn.classList.add('btn-outline-dark');
    });
    element.classList.remove('btn-outline-dark');
    element.classList.add('active', 'btn-dark');
}

// Color selection
function selectColor(color, element) {
    document.querySelectorAll('.color-btn').forEach(btn => {
        btn.classList.remove('active', 'btn-dark');
        btn.classList.add('btn-outline-dark');
    });
    element.classList.remove('btn-outline-dark');
    element.classList.add('active', 'btn-dark');
}

// Share product
function shareProduct(url, title) {
    if (navigator.share) {
        navigator.share({
            title: title,
            url: url
        });
    } else {
        // Fallback for browsers that don't support Web Share API
        const tempInput = document.createElement('input');
        tempInput.value = url;
        document.body.appendChild(tempInput);
        tempInput.select();
        document.execCommand('copy');
        document.body.removeChild(tempInput);
        showNotification('Link copied to clipboard!', 'info');
    }
}