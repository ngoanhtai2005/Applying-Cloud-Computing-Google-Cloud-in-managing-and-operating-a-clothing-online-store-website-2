<?php
session_start();
require_once 'config/database.php';
require_once 'config/functions.php';

// ====================================================
// 1. XỬ LÝ LOGIC: THÊM VÀO GIỎ HÀNG & MUA NGAY
// ====================================================
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $pId   = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;
    $qty   = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;
    $size  = isset($_POST['size']) ? $_POST['size'] : '';
    $color = isset($_POST['color']) ? $_POST['color'] : '';

    if ($pId > 0) {
        // Tạo khóa duy nhất: ID_SIZE_COLOR
        $key = $pId . '_' . $size . '_' . $color;

        if (!isset($_SESSION['cart'])) {
            $_SESSION['cart'] = [];
        }

        // Cộng dồn số lượng nếu đã có, hoặc tạo mới
        if (isset($_SESSION['cart'][$key])) {
            $_SESSION['cart'][$key]['quantity'] += $qty;
        } else {
            $_SESSION['cart'][$key] = [
                'product_id' => $pId,
                'quantity'   => $qty,
                'size'       => $size,
                'color'      => $color
            ];
        }

        // Điều hướng
        if (isset($_POST['buy_now'])) {
            header("Location: checkout.php"); 
            exit;
        } else {
            header("Location: " . $_SERVER['REQUEST_URI']); 
            exit;
        }
    }
}

// ====================================================
// 2. LẤY THÔNG TIN SẢN PHẨM TỪ DATABASE
// ====================================================
$slug = isset($_GET['slug']) ? $_GET['slug'] : '';
$conn = getDBConnection();

// Lấy thông tin sản phẩm
$stmt = $conn->prepare("SELECT * FROM products WHERE slug = ?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$product = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$product) {
    header("Location: index.php");
    exit;
}

// Lấy danh sách ảnh phụ
$stmt = $conn->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_main DESC");
$stmt->bind_param("i", $product['id']);
$stmt->execute();
$images = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Lấy thuộc tính (Size/Color)
$stmt = $conn->prepare("
    SELECT DISTINCT size, color 
    FROM product_attributes 
    WHERE product_id = ? AND stock > 0
");
$stmt->bind_param("i", $product['id']);
$stmt->execute();
$attrs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$sizes = [];
$colors = [];
foreach ($attrs as $a) {
    if (!empty($a['size']))  $sizes[]  = $a['size'];
    if (!empty($a['color'])) $colors[] = $a['color'];
}
$sizes  = array_unique($sizes);
$colors = array_unique($colors);

$pageTitle = $product['name'];
include 'includes/header.php';
include 'includes/navbar.php';
?>

<div class="container py-5">
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="border mb-3">
                <img id="mainImage" 
                     src="<?php echo !empty($images) ? $images[0]['image_url'] : 'assets/images/no-image.jpg'; ?>" 
                     class="img-fluid w-100" 
                     alt="<?php echo htmlspecialchars($product['name']); ?>"
                     style="object-fit: cover; min-height: 400px; max-height: 500px;">
            </div>
            
            <div class="d-flex gap-2 overflow-auto">
                <?php foreach ($images as $img): ?>
                <div class="border thumbnail-item" 
                     style="width: 80px; height: 80px; cursor: pointer; flex-shrink: 0;"
                     onclick="changeImage('<?php echo $img['image_url']; ?>')">
                    <img src="<?php echo $img['image_url']; ?>" class="w-100 h-100" style="object-fit: cover;">
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <div class="col-md-6">
            <h2 class="fw-light mb-3"><?php echo htmlspecialchars($product['name']); ?></h2>

            <div class="mb-3">
                <h4 class="fw-bold d-inline me-2">
                    <?php echo formatPrice($product['sale_price'] > 0 ? $product['sale_price'] : $product['price']); ?>
                </h4>
                <?php if ($product['sale_price'] > 0): ?>
                    <span class="text-muted text-decoration-line-through">
                        <?php echo formatPrice($product['price']); ?>
                    </span>
                <?php endif; ?>

                <div class="text-warning mt-2">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-half"></i>
                    <span class="text-muted ms-2 small">(12 đánh giá)</span>
                </div>
            </div>

            <p class="text-muted mb-4">
                <?php echo htmlspecialchars($product['description']); ?>
            </p>

            <form method="POST" action="">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                
                <?php if(!empty($colors)): ?>
                <div class="mb-4">
                    <label class="fw-bold d-block mb-2 text-uppercase small">Màu sắc:</label>
                    <?php foreach($colors as $index => $c): ?>
                        <input type="radio" class="btn-check" name="color" id="color_<?= $index ?>" value="<?= $c ?>" checked>
                        <label class="btn btn-outline-dark rounded-circle p-0 me-2 d-inline-block position-relative" 
                               for="color_<?= $index ?>" 
                               style="width: 30px; height: 30px; background-color: <?= $c ?>; border: 1px solid #ccc;"
                               title="<?= $c ?>">
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <?php if(!empty($sizes)): ?>
                <div class="mb-4">
                    <label class="fw-bold d-block mb-2 text-uppercase small">Kích cỡ:</label>
                    <?php foreach($sizes as $s): ?>
                        <input type="radio" class="btn-check" name="size" id="size_<?= $s ?>" value="<?= $s ?>" checked>
                        <label class="btn btn-outline-dark rounded-0 px-3 py-2 me-2" for="size_<?= $s ?>">
                            <?= $s ?>
                        </label>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <div class="mb-4">
                    <label class="fw-bold d-block mb-2 text-uppercase small">Số lượng:</label>
                    <div class="input-group" style="width: 140px;">
                        <button class="btn btn-outline-secondary rounded-0" type="button" onclick="updateQty(-1)">-</button>
                        <input type="number" name="quantity" id="qtyInput" class="form-control text-center border-secondary" value="1" min="1">
                        <button class="btn btn-outline-secondary rounded-0" type="button" onclick="updateQty(1)">+</button>
                    </div>
                </div>

                <div class="d-grid gap-2">
                    <button type="submit" name="add_to_cart" class="btn btn-dark rounded-0 py-3 text-uppercase fw-bold shadow-sm">
                        THÊM VÀO GIỎ HÀNG
                    </button>
                    <button type="submit" name="buy_now" class="btn btn-outline-dark rounded-0 py-3 text-uppercase fw-bold">
                        MUA NGAY
                    </button>
                </div>
            </form>
            
            <div class="mt-4 pt-3 border-top small text-muted">
                <p class="mb-1"><i class="bi bi-check-circle-fill text-success me-2"></i> Còn hàng (<?php echo isset($product['stock']) ? $product['stock'] : 'Sẵn có'; ?> sản phẩm)</p>
                <p class="mb-1"><i class="bi bi-truck me-2"></i> Miễn phí vận chuyển cho đơn hàng trên 1 triệu</p>
                <p class="mb-0"><i class="bi bi-arrow-return-left me-2"></i> Đổi trả trong vòng 30 ngày</p>
            </div>
        </div>
    </div>
</div>

<script>
// Hàm đổi ảnh chính khi click vào ảnh nhỏ
function changeImage(newSrc) {
    document.getElementById('mainImage').src = newSrc;
}

// Hàm tăng giảm số lượng
function updateQty(change) {
    var qtyInput = document.getElementById('qtyInput');
    var currentQty = parseInt(qtyInput.value);
    var newQty = currentQty + change;
    if (newQty >= 1) {
        qtyInput.value = newQty;
    }
}
</script>

<?php include 'includes/footer.php'; ?>
