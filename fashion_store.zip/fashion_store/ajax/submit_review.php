<?php
require_once '../config/database.php';
require_once '../config/functions.php';

header('Content-Type: application/json');

if (!isLoggedIn()) {
    echo json_encode([
        'success' => false,
        'message' => 'Please login to submit a review'
    ]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['product_id'] ?? null;
    $rating = $_POST['rating'] ?? null;
    $comment = $_POST['comment'] ?? '';
    $userId = getCurrentUserId();
    
    if (!$productId || !$rating) {
        echo json_encode([
            'success' => false,
            'message' => 'Product ID and rating are required'
        ]);
        exit;
    }
    
    $conn = getDBConnection();
    
    // Check if user has already reviewed this product
    $stmt = $conn->prepare("SELECT id FROM reviews WHERE user_id = ? AND product_id = ?");
    $stmt->bind_param("ii", $userId, $productId);
    $stmt->execute();
    $stmt->store_result();
    
    if ($stmt->num_rows > 0) {
        // Update existing review
        $stmt = $conn->prepare("UPDATE reviews SET rating = ?, comment = ?, created_at = NOW() 
                               WHERE user_id = ? AND product_id = ?");
        $stmt->bind_param("isii", $rating, $comment, $userId, $productId);
    } else {
        // Insert new review
        $stmt = $conn->prepare("INSERT INTO reviews (product_id, user_id, rating, comment) 
                               VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iiis", $productId, $userId, $rating, $comment);
    }
    
    if ($stmt->execute()) {
        echo json_encode([
            'success' => true,
            'message' => 'Review submitted successfully'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to submit review'
        ]);
    }
    
    $stmt->close();
    $conn->close();
}
?>