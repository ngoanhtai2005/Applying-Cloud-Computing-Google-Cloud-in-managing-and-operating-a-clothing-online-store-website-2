<?php
require_once __DIR__ . "/../config/database.php";
require_once __DIR__ . "/../config/functions.php";

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $productId = $data['product_id'] ?? null;
    $quantity = $data['quantity'] ?? 1;
    $size = $data['size'] ?? null;
    $color = $data['color'] ?? null;
    
    if ($productId) {
        addToCart($productId, $quantity, $size, $color);
        
        echo json_encode([
            'success' => true,
            'cartCount' => getCartCount(),
            'message' => 'Product added to cart'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Product ID is required'
        ]);
    }
}
?>