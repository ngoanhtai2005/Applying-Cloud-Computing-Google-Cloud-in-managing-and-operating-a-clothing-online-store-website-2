<?php
require_once '../config/database.php';
require_once '../config/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    
    $key = $data['key'] ?? null;
    
    if ($key && removeFromCart($key)) {
        echo json_encode([
            'success' => true,
            'cartCount' => getCartCount(),
            'message' => 'Item removed from cart'
        ]);
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Failed to remove item'
        ]);
    }
}
?>