<?php
require_once '../config/database.php';
require_once '../config/functions.php';

header('Content-Type: application/json');

$slug = $_GET['slug'] ?? '';
if (!$slug) {
    echo json_encode(['success' => false, 'message' => 'Product slug is required']);
    exit;
}

$conn = getDBConnection();

// Get product details
$stmt = $conn->prepare("SELECT p.*, c.name as category_name FROM products p
                       LEFT JOIN categories c ON p.category_id = c.id
                       WHERE p.slug = ?");
$stmt->bind_param("s", $slug);
$stmt->execute();
$result = $stmt->get_result();
$product = $result->fetch_assoc(); 
$stmt->close();

if (!$product) { 
    echo json_encode(['success' => false, 'message' => 'Product not found']);
    exit;
}

// Get product images
$stmt = $conn->prepare("SELECT * FROM product_images WHERE product_id = ? ORDER BY is_main DESC LIMIT 3");
$stmt->bind_param("i", $product['id']);
$stmt->execute();
$images = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get available sizes
$sizeStmt = $conn->prepare("SELECT DISTINCT size FROM product_attributes WHERE product_id = ? AND size IS NOT NULL AND stock > 0");
$sizeStmt->bind_param("i", $product['id']);
$sizeStmt->execute();
$sizes = $sizeStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$sizeStmt->close();

// Get available colors
$colorStmt = $conn->prepare("SELECT DISTINCT color FROM product_attributes WHERE product_id = ? AND color IS NOT NULL AND stock > 0");
$colorStmt->bind_param("i", $product['id']);
$colorStmt->execute();
$colors = $colorStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$colorStmt->close();

$conn->close();

// Generate HTML for modal
ob_start();
?>
<div class="modal-dialog modal-lg">
    <div class="modal-content rounded-0">
        <div class="modal-header border-0">
            <h5 class="modal-title">Quick View</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
            <div class="row">
                <!-- Product Images -->
                <div class="col-md-6">
                    <div class="quick-view-images">
                        <div class="main-image mb-3">
                            <img src="<?php echo $product['main_image'] ?: 'images/products/default.jpg'; ?>" 
                                 class="img-fluid" id="mainQuickViewImage" alt="...">
                                 alt="<?php echo htmlspecialchars($product['name']); ?>"
                                 style="height: 400px; object-fit: cover;">
                        </div>
                        <?php if (count($images) > 1): ?>
                            <div class="thumbnail-images">
                                <div class="row g-2">
                                    <?php foreach ($images as $img): ?>
                                        <img src="<?php echo $img['image_url']; ?>" 
                                            class="img-fluid thumbnail-sm cursor-pointer" 
                                            onclick="document.getElementById('mainQuickViewImage').src='<?php echo $img['image_url']; ?>'">
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <!-- Product Info -->
                <div class="col-md-6">
                    <h4 class="fw-light mb-3"><?php echo htmlspecialchars($product['name']); ?></h4>
                    
                    <div class="price mb-3">
                        <?php if ($product['sale_price']): ?>
                            <span class="h5 fw-bold text-dark me-2"><?php echo formatPrice($product['sale_price']); ?></span>
                            <span class="text-muted text-decoration-line-through"><?php echo formatPrice($product['price']); ?></span>
                            <span class="badge bg-danger ms-2"><?php echo getDiscountPercentage($product['price'], $product['sale_price']); ?> OFF</span>
                        <?php else: ?>
                            <span class="h5 fw-bold text-dark"><?php echo formatPrice($product['price']); ?></span>
                        <?php endif; ?>
                    </div>
                    
                    <p class="text-muted mb-4"><?php echo htmlspecialchars(substr($product['description'], 0, 150)); ?>...</p>
                    
                    <!-- Color Selection -->
                    <?php if (!empty($colors)): ?>
                        <div class="color-selection mb-4">
                            <h6 class="fw-bold mb-2">COLOR</h6>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($colors as $color): ?>
                                    <button type="button" class="btn btn-outline-dark rounded-0 color-btn btn-sm"
                                            data-color="<?php echo $color['color']; ?>">
                                        <div class="color-dot me-2" style="background-color: <?php echo strtolower($color['color']); ?>;"></div>
                                        <?php echo $color['color']; ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Size Selection -->
                    <?php if (!empty($sizes)): ?>
                        <div class="size-selection mb-4">
                            <h6 class="fw-bold mb-2">SIZE</h6>
                            <div class="d-flex flex-wrap gap-2">
                                <?php foreach ($sizes as $size): ?>
                                    <button type="button" class="btn btn-outline-dark rounded-0 size-btn btn-sm"
                                            data-size="<?php echo $size['size']; ?>">
                                        <?php echo $size['size']; ?>
                                    </button>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <!-- Quantity -->
                    <div class="quantity mb-4">
                        <h6 class="fw-bold mb-2">QUANTITY</h6>
                        <div class="input-group" style="width: 150px;">
                            <button class="btn btn-outline-dark rounded-0" type="button" onclick="this.nextElementSibling.stepDown()">-</button>
                            <input type="number" class="form-control rounded-0 text-center border-dark" 
                                   value="1" min="1" max="10" id="quickViewQuantity">
                            <button class="btn btn-outline-dark rounded-0" type="button" onclick="this.previousElementSibling.stepUp()">+</button>
                        </div>
                    </div>
                    
                    <!-- Action Buttons -->
                    <div class="action-buttons">
                        <button class="btn btn-dark rounded-0 w-100 mb-2"
                                onclick="addToCart(<?php echo $product['id']; ?>, document.getElementById('quickViewQuantity').value)">
                            ADD TO CART
                        </button>
                        <a href="product.php?slug=<?php echo $product['slug']; ?>" 
                           class="btn btn-outline-dark rounded-0 w-100">
                            VIEW FULL DETAILS
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
$html = ob_get_clean();

echo json_encode([
    'success' => true,
    'html' => $html
]);
?>