<?php
session_start();
require_once '../config/functions.php';
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$key = $data['key'] ?? null;
$change = $data['change'] ?? 0;

if ($key && isset($_SESSION['cart'][$key])) {
    $_SESSION['cart'][$key]['quantity'] += $change;
    if ($_SESSION['cart'][$key]['quantity'] < 1) $_SESSION['cart'][$key]['quantity'] = 1;
    
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>