<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once 'config/database.php';
require_once 'config/functions.php';
require_once 'includes/product-card.php';

// Get category from URL
$categorySlug = $_GET['category'] ?? 'women';
$page = $_GET['page'] ?? 1;
$limit = 12;
$offset = ($page - 1) * $limit;

// Get filters
$filters = [
    'size' => $_GET['size'] ?? '',
    'color' => $_GET['color'] ?? '',
    'min_price' => $_GET['min_price'] ?? '',
    'max_price' => $_GET['max_price'] ?? ''
];

// Get category ID
$conn = getDBConnection();
$stmt = $conn->prepare("SELECT id, name FROM categories WHERE slug = ?");
$stmt->bind_param("s", $categorySlug);
$stmt->execute();
$result = $stmt->get_result();
$category = $result->fetch_assoc();
$stmt->close();


if (!$category) {
    header('Location: index.php');
    exit;
}

$pageTitle = ucfirst($category['name']) . " - Fashion Store";

// Get products
$products = getProducts($category['id'], $limit, $offset, $filters);

// Get total count for pagination
$totalStmt = $conn->prepare("SELECT COUNT(DISTINCT p.id) as total FROM products p 
                            LEFT JOIN product_attributes pa ON p.id = pa.product_id
                            WHERE p.category_id = ? AND p.stock > 0");
$totalStmt->bind_param("i", $category['id']);
$totalStmt->execute();
$totalResult = $totalStmt->get_result();
$totalProducts = $totalResult->fetch_assoc()['total'];
$totalStmt->close();

// Get available sizes and colors
$sizeStmt = $conn->prepare("SELECT DISTINCT size FROM product_attributes WHERE size IS NOT NULL ORDER BY size");
$sizeStmt->execute();
$sizes = $sizeStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$sizeStmt->close();

$colorStmt = $conn->prepare("SELECT DISTINCT color FROM product_attributes WHERE color IS NOT NULL ORDER BY color");
$colorStmt->execute();
$colors = $colorStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$colorStmt->close();

$conn->close();

// Calculate total pages
$totalPages = ceil($totalProducts / $limit);
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<!-- Category Header -->
<section class="py-5 border-bottom">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h1 class="fw-light text-center mb-3"><?php echo strtoupper($category['name']); ?></h1>
                <p class="text-muted text-center">Showing <?php echo count($products); ?> of <?php echo $totalProducts; ?> products</p>
            </div>
        </div>
    </div>
</section>

<!-- Main Content -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <!-- Sidebar Filters -->
            <div class="col-lg-3 mb-5">
                <form id="filterForm" method="GET" action="category.php">
                    <input type="hidden" name="category" value="<?php echo $categorySlug; ?>">
                    
                    <!-- Category Filter -->
                    <div class="mb-4">
                        <h6 class="mb-3 fw-bold">CATEGORY</h6>
                        <?php
                       $catStmt = $conn->prepare("SELECT name, slug FROM categories WHERE parent_id = ?");
                       if (!$catStmt) {
                            die("SQL Error (subcategories query): " . $conn->error);
                         }
                        $catStmt->bind_param("i", $category['id']);
                        $catStmt->execute();
                        $subcategories = $catStmt->get_result()->fetch_all(MYSQLI_ASSOC);
                                $catStmt->close();

                        
                        foreach ($subcategories as $subcat) {
                            $active = ($_GET['subcategory'] ?? '') === $subcat['slug'] ? 'active' : '';
                            echo '<div class="form-check mb-2">';
                            echo '<input class="form-check-input" type="checkbox" name="subcategory" value="'.$subcat['slug'].'" id="subcat_'.$subcat['slug'].'" '.$active.'>';
                            echo '<label class="form-check-label text-muted" for="subcat_'.$subcat['slug'].'">';
                            echo $subcat['name'];
                            echo '</label>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                    
                    <!-- Size Filter -->
                    <div class="mb-4">
                        <h6 class="mb-3 fw-bold">SIZE</h6>
                        <div class="size-filter">
                            <?php foreach ($sizes as $size): ?>
                                <button type="button" class="btn btn-outline-dark rounded-0 size-btn <?php echo $filters['size'] === $size['size'] ? 'active' : ''; ?>"
                                        data-size="<?php echo $size['size']; ?>">
                                    <?php echo $size['size']; ?>
                                </button>
                            <?php endforeach; ?>
                            <input type="hidden" name="size" id="sizeInput" value="<?php echo $filters['size']; ?>">
                        </div>
                    </div>
                    
                    <!-- Color Filter -->
                    <div class="mb-4">
                        <h6 class="mb-3 fw-bold">COLOR</h6>
                        <div class="color-filter">
                            <?php foreach ($colors as $color): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="color" value="<?php echo $color['color']; ?>" 
                                           id="color_<?php echo strtolower($color['color']); ?>"
                                           <?php echo $filters['color'] === $color['color'] ? 'checked' : ''; ?>>
                                    <label class="form-check-label d-flex align-items-center" for="color_<?php echo strtolower($color['color']); ?>">
                                        <span class="color-dot me-2" style="background-color: <?php echo strtolower($color['color']); ?>;"></span>
                                        <?php echo ucfirst($color['color']); ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Price Filter -->
                    <div class="mb-4">
                        <h6 class="mb-3 fw-bold">PRICE RANGE</h6>
                        <div class="price-filter">
                            <div class="row">
                                <div class="col-6">
                                    <input type="number" class="form-control rounded-0" name="min_price" 
                                           placeholder="Min" value="<?php echo $filters['min_price']; ?>">
                                </div>
                                <div class="col-6">
                                    <input type="number" class="form-control rounded-0" name="max_price" 
                                           placeholder="Max" value="<?php echo $filters['max_price']; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Apply Filters Button -->
                    <button type="submit" class="btn btn-dark rounded-0 w-100">APPLY FILTERS</button>
                    <a href="category.php?category=<?php echo $categorySlug; ?>" class="btn btn-outline-dark rounded-0 w-100 mt-2">CLEAR ALL</a>
                </form>
            </div>
            
            <!-- Product Grid -->
            <div class="col-lg-9">
                <!-- Sorting and View Options -->
                <div class="row mb-4">
                    <div class="col-md-6">
                        <p class="mb-0"><?php echo $totalProducts; ?> products</p>
                    </div>
                    <div class="col-md-6 text-end">
                        <div class="dropdown d-inline-block">
                            <button class="btn btn-outline-dark rounded-0 dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                SORT BY: <?php echo isset($_GET['sort']) ? ucfirst(str_replace('_', ' ', $_GET['sort'])) : 'Newest'; ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><a class="dropdown-item" href="?category=<?php echo $categorySlug; ?>&sort=newest">Newest</a></li>
                                <li><a class="dropdown-item" href="?category=<?php echo $categorySlug; ?>&sort=price_low">Price: Low to High</a></li>
                                <li><a class="dropdown-item" href="?category=<?php echo $categorySlug; ?>&sort=price_high">Price: High to Low</a></li>
                                <li><a class="dropdown-item" href="?category=<?php echo $categorySlug; ?>&sort=best_seller">Best Seller</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                
                <!-- Products -->
                <?php if (empty($products)): ?>
                    <div class="text-center py-5">
                        <h4 class="text-muted">No products found</h4>
                        <p>Try adjusting your filters</p>
                    </div>
                <?php else: ?>
                    <div class="row g-4">
                        <?php foreach ($products as $product): ?>
                            <div class="col-md-4 col-sm-6">
                                <?php renderProductCard($product); ?>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
                
                <!-- Pagination -->
                <?php if ($totalPages > 1): ?>
                    <nav class="mt-5">
                        <ul class="pagination justify-content-center">
                            <?php if ($page > 1): ?>
                                <li class="page-item">
                                    <a class="page-link rounded-0 border-0 text-dark" 
                                       href="?category=<?php echo $categorySlug; ?>&page=<?php echo $page - 1; ?>">
                                        <i class="bi bi-chevron-left"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                                <li class="page-item <?php echo $i == $page ? 'active' : ''; ?>">
                                    <a class="page-link rounded-0 border-0 text-dark" 
                                       href="?category=<?php echo $categorySlug; ?>&page=<?php echo $i; ?>">
                                        <?php echo $i; ?>
                                    </a>
                                </li>
                            <?php endfor; ?>
                            
                            <?php if ($page < $totalPages): ?>
                                <li class="page-item">
                                    <a class="page-link rounded-0 border-0 text-dark" 
                                       href="?category=<?php echo $categorySlug; ?>&page=<?php echo $page + 1; ?>">
                                        <i class="bi bi-chevron-right"></i>
                                    </a>
                                </li>
                            <?php endif; ?>
                        </ul>
                    </nav>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
