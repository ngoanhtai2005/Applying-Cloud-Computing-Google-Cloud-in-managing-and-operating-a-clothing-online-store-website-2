<?php
// Application Constants
define('APP_NAME', 'FORMAT.STORE');
define('APP_VERSION', '1.0.0');
define('BASE_URL', 'http://localhost/fashion_store/');

// File Upload Settings
define('MAX_FILE_SIZE', 5 * 1024 * 1024); // 5MB
define('ALLOWED_IMAGE_TYPES', ['jpg', 'jpeg', 'png', 'gif', 'webp']);

// Email Settings
define('SMTP_HOST', 'smtp.gmail.com');
define('SMTP_PORT', 587);
define('SMTP_USER', 'noreply@yourdomain.com');
define('SMTP_PASS', 'yourpassword');
define('FROM_EMAIL', 'noreply@yourdomain.com');
define('FROM_NAME', 'FORMAT Store');

// Currency Settings
define('CURRENCY', 'USD');
define('CURRENCY_SYMBOL', '$');
define('TAX_RATE', 0.08); // 8%

// Shipping Settings
define('FREE_SHIPPING_THRESHOLD', 100);
define('STANDARD_SHIPPING_COST', 9.99);
define('EXPRESS_SHIPPING_COST', 19.99);

// Pagination Settings
define('ITEMS_PER_PAGE', 12);
define('ADMIN_ITEMS_PER_PAGE', 20);

// Timezone
date_default_timezone_set('America/New_York');
?>