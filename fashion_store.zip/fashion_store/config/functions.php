<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config/database.php';

// =======================
// 1. HÀM TIỆN ÍCH CƠ BẢN
// =======================

// Kiểm tra đăng nhập
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

// Lấy ID người dùng
function getCurrentUserId() {
    return $_SESSION['user_id'] ?? 0;
}

// Định dạng tiền tệ
function formatPrice($amount) {
    return number_format($amount, 0, ',', '.') . ' đ';
}

// Chuyển hướng trang
function redirect($url) {
    if (!headers_sent()) {
        header("Location: $url");
    } else {
        echo "<script>window.location.href='$url';</script>";
    }
    exit();
}

// Đếm số lượng sản phẩm trong giỏ
function getCartCount() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) return 0;
    $count = 0;
    foreach ($_SESSION['cart'] as $item) {
        $count += $item['quantity'] ?? 0;
    }
    return $count;
}

// Tính % giảm giá
function getDiscountPercentage($price, $salePrice) {
    if ($salePrice > 0 && $salePrice < $price) {
        $percent = round((($price - $salePrice) / $price) * 100);
        return '-' . $percent . '%';
    }
    return '';
}

// =======================
// 2. HÀM DỮ LIỆU SẢN PHẨM
// =======================

// Lấy danh sách sản phẩm theo category + filters + pagination
function getProducts($categoryId, $limit = 12, $offset = 0, $filters = []) {
    $conn = getDBConnection();

    $sql = "SELECT p.*, pi.image_url AS main_image
            FROM products p
            LEFT JOIN product_images pi ON p.id = pi.product_id AND pi.is_main = 1
            WHERE p.category_id = ? AND p.stock > 0";

    $params = [$categoryId];
    $types = "i";

    // Filter size
    if (!empty($filters['size'])) {
        $sql .= " AND EXISTS (SELECT 1 FROM product_attributes pa WHERE pa.product_id = p.id AND pa.size = ? AND pa.stock > 0)";
        $types .= "s";
        $params[] = $filters['size'];
    }

    // Filter color
    if (!empty($filters['color'])) {
        $sql .= " AND EXISTS (SELECT 1 FROM product_attributes pa WHERE pa.product_id = p.id AND pa.color = ? AND pa.stock > 0)";
        $types .= "s";
        $params[] = $filters['color'];
    }

    $sql .= " ORDER BY p.id DESC LIMIT ? OFFSET ?";
    $types .= "ii";
    $params[] = $limit;
    $params[] = $offset;

    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $products = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    $stmt->close();

    return $products;
}

// Lấy 1 sản phẩm theo slug (cho product.php)
function getProductBySlug($slug) {
    $conn = getDBConnection();
    $stmt = $conn->prepare("SELECT * FROM products WHERE slug = ? LIMIT 1");
    $stmt->bind_param("s", $slug);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $product;
}

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

// Debug
function dd($data) {
    echo "<pre style='background:#fff;padding:10px;z-index:9999;position:relative;'>";
    print_r($data);
    echo "</pre>";
    die();
}
?>
