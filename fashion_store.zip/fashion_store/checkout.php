<?php
session_start();
require_once 'config/database.php';
require_once 'config/functions.php';

/* =====================
   CART & LOGIN
===================== */

if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header('Location: cart.php');
    exit;
}
if (!isLoggedIn()) {
    $_SESSION['redirect'] = 'product.php';
    header('Location: login.php?redirect=product.php');
    exit;
}

$conn   = getDBConnection();
$userId = getCurrentUserId();
$error  = '';

/* =====================
   USER INFO
===================== */
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

/* =====================
   PROCESS ORDER
===================== */
/* =====================
   PROCESS ORDER
===================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $firstName = trim($_POST['first_name']);
    $lastName  = trim($_POST['last_name']);
    $email     = trim($_POST['email']);
    $phone     = trim($_POST['phone']);
    $address   = trim($_POST['address']);
    $city      = trim($_POST['city']);
    $state     = trim($_POST['state']);
    $zip       = trim($_POST['zip']);
    $country   = trim($_POST['country']);
    $payment   = $_POST['payment_method'];

    if (!$firstName || !$lastName || !$email || !$address || !$city || !$state || !$zip || !$country) {
        $error = 'Vui lòng nhập đầy đủ thông tin';
    } else {

        /* ===== CALCULATE TOTAL ===== */
        $subtotal = 0;
        foreach ($_SESSION['cart'] as $item) {
            $stmt = $conn->prepare("SELECT price, sale_price FROM products WHERE id = ?");
            $stmt->bind_param("i", $item['product_id']);
            $stmt->execute();
            $product = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            if (!$product) continue;

            $price = $product['sale_price'] ?: $product['price'];
            $subtotal += $price * $item['quantity'];
        }

        $shippingFee = $subtotal > 100 ? 0 : 9.99;
        $tax         = $subtotal * 0.08;
        $total       = $subtotal + $shippingFee + $tax;

        $orderNumber  = 'ORD' . date('YmdHis') . rand(100,999);
        $shippingName = $firstName . ' ' . $lastName;

        $conn->begin_transaction();

        try {
             /* ===== INSERT ORDER ===== */
            $stmt = $conn->prepare("
                INSERT INTO orders (
                    user_id, order_number,
                    subtotal, shipping_fee, tax, total_amount,
                    payment_method,
                    shipping_name, shipping_phone,
                    shipping_address, shipping_city,
                    shipping_state, shipping_zip, shipping_country
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->bind_param(
                "isddddssssssss",
                $userId,
                $orderNumber,
                $subtotal,
                $shippingFee,
                $tax,
                $total,
                $payment,
                $shippingName,
                $phone,
                $address,
                $city,
                $state,
                $zip,
                $country
            );

            $stmt->execute();
            $orderId = $conn->insert_id;
            $stmt->close();

            /* ===== INSERT ORDER ITEMS ===== */
            foreach ($_SESSION['cart'] as $item) {

                $stmt = $conn->prepare("SELECT price, sale_price FROM products WHERE id = ?");
                $stmt->bind_param("i", $item['product_id']);
                $stmt->execute();
                $product = $stmt->get_result()->fetch_assoc();
                $stmt->close();

                if (!$product) continue;

                $price = $product['sale_price'] ?: $product['price'];
                $size  = $item['size'] ?? null;
                $color = $item['color'] ?? null;
                 if (!$product) continue;

                $price = $product['sale_price'] ?: $product['price'];
                $size  = $item['size'] ?? null;
                $color = $item['color'] ?? null;

                $stmt = $conn->prepare("
                    INSERT INTO order_items
                    (order_id, product_id, quantity, price, size, color)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");
                $stmt->bind_param(
                    "iiidss",
                    $orderId,
                    $item['product_id'],
                    $item['quantity'],
                    $price,
                    $size,
                    $color
                );
                $stmt->execute();
                $stmt->close();

                // Update stock
                if ($size && $color) {
                    $stmt = $conn->prepare("UPDATE product_attributes SET stock = stock - ? WHERE product_id = ? AND size = ? AND color = ?");
                    $stmt->bind_param("iiss", $item['quantity'], $item['product_id'], $size, $color);
                } else {
                    $stmt = $conn->prepare("UPDATE products SET stock = stock - ? WHERE id = ?");
                    $stmt->bind_param("ii", $item['quantity'], $item['product_id']);
                }
                $stmt->execute();
                $stmt->close();
            }

            /* ===== XỬ LÝ THANH TOÁN (MOMO & THƯỜNG) ===== */
           $conn->commit();
            unset($_SESSION['cart']);

            // KHÔNG CẦN GỌI API MOMO NỮA
            // Chỉ cần chuyển hướng sang trang xác nhận đơn hàng
            header("Location: order-confirmation.php?order=$orderNumber");
            exit;

        } catch (Exception $e) {
            $conn->rollback();
            $error = 'Đặt hàng thất bại: ' . $e->getMessage();
        }
    }
}
// Sau khi đóng đủ 2 dấu ngoặc trên thì mới đến phần HTML hoặc hàm execPostRequest
$pageTitle = "Checkout";
include 'includes/header.php';
include 'includes/navbar.php';
?>

<section class="py-5">
<div class="container">
<div class="row">
<div class="col-lg-7">

<h4 class="fw-bold mb-4">Thông tin giao hàng</h4>

<?php if ($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">

<div class="row">
<div class="col-md-6 mb-3">
<input type="text" name="first_name" class="form-control" placeholder="Họ"
value="<?= htmlspecialchars($user['first_name'] ?? '') ?>">
</div>

<div class="col-md-6 mb-3">
<input type="text" name="last_name" class="form-control" placeholder="Tên"
value="<?= htmlspecialchars($user['last_name'] ?? '') ?>">
</div>
</div>

<input type="email" name="email" class="form-control mb-3"
value="<?= htmlspecialchars($user['email'] ?? '') ?>" placeholder="Email">

<input type="text" name="phone" class="form-control mb-3" placeholder="Số điện thoại">

<input type="text" name="address" class="form-control mb-3" placeholder="Địa chỉ">

<div class="row">
<div class="col-md-6 mb-3">
<input type="text" name="city" class="form-control" placeholder="Thành phố">
</div>
<div class="col-md-6 mb-3">
<input type="text" name="state" class="form-control" placeholder="Tỉnh / Bang">
</div>
</div>
<div class="row">
<div class="col-md-6 mb-3">
<input type="text" name="zip" class="form-control" placeholder="ZIP">
</div>
<div class="col-md-6 mb-3">
<input type="text" name="country" class="form-control" placeholder="Quốc gia" value="VN">
</div>
</div>

<h5 class="mt-4">Thanh toán</h5>
<select name="payment_method" class="form-select mb-4">
    <option value="cod">Thanh toán khi nhận hàng (COD)</option>
    
    <option value="momo">Chuyển khoản Ngân hàng / Quét mã QR MoMo</option> 
</select>

<button class="btn btn-dark w-100 py-3">ĐẶT HÀNG</button>
</form>

</div>

<div class="col-lg-5">
<h4 class="fw-bold mb-4">Đơn hàng</h4>
<?php
$subtotal = 0;
foreach ($_SESSION['cart'] as $item):
    $stmt = $conn->prepare("SELECT name, price, sale_price FROM products WHERE id = ?");
    $stmt->bind_param("i", $item['product_id']);
    $stmt->execute();
    $product = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$product) continue;

    $price = $product['sale_price'] ?: $product['price'];
    $itemTotal = $price * $item['quantity'];
    $subtotal += $itemTotal;
?>
<div class="d-flex justify-content-between mb-2">
    <span>
        <?= htmlspecialchars($product['name']) ?> x<?= $item['quantity'] ?>
        <?php if (!empty($item['size'])): ?> | Size: <?= $item['size'] ?><?php endif; ?>
        <?php if (!empty($item['color'])): ?> | Color: <?= $item['color'] ?><?php endif; ?>
    </span>
    <span><?= formatPrice($itemTotal) ?></span>
</div>
<?php endforeach; ?>

<hr>
<div class="d-flex justify-content-between">
<span class="text-muted">Subtotal</span>
<span><?= formatPrice($subtotal) ?></span>
</div>
<div class="d-flex justify-content-between">
<span class="text-muted">Shipping</span>
<span><?= $subtotal > 100 ? 'FREE' : formatPrice(9.99) ?></span>
</div>
<div class="d-flex justify-content-between">
<span class="text-muted">Tax</span>
<span><?= formatPrice($subtotal * 0.08) ?></span>
</div>
<div class="d-flex justify-content-between pt-3 border-top mt-3">
<strong>Total</strong>
<strong><?= formatPrice($subtotal + ($subtotal > 100 ? 0 : 9.99) + $subtotal * 0.08) ?></strong>
</div>

</div>
</div>
</div>
</section>

<?php include 'includes/footer.php'; ?>
<?php
function execPostRequest($url, $data) {
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'Content-Type: application/json',
            'Content-Length: ' . strlen($data))
    );
    curl_setopt($ch, CURLOPT_TIMEOUT, 5);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
} 
