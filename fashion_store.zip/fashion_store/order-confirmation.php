<?php
require_once 'config/database.php';
require_once 'config/functions.php';

/* ===============================
   1. KIỂM TRA ĐĂNG NHẬP
================================ */
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$orderNumber = $_GET['order'] ?? '';
if (!$orderNumber) {
    header('Location: index.php');
    exit;
}

$conn   = getDBConnection();
$userId = getCurrentUserId();

/* ===============================
   2. LẤY ĐƠN HÀNG + KIỂM TRA QUYỀN
================================ */
$stmt = $conn->prepare("
    SELECT *
    FROM orders
    WHERE order_number = ?
      AND user_id = ?
    LIMIT 1
");
$stmt->bind_param("si", $orderNumber, $userId);
$stmt->execute();
$order = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$order) {
    echo "Đơn hàng không tồn tại hoặc bạn không có quyền xem đơn hàng này.";
    exit;
}

/* ===============================
   3. FIX TOÀN BỘ WARNING & LOGIC QR
================================ */
$order = array_merge([
    'subtotal'          => 0,
    'shipping_fee'      => 0,
    'tax'               => 0,
    'total_amount'      => 0,
    'payment_method'    => 'cod',
    'shipping_name'     => '',
    'shipping_phone'    => '',
    'shipping_address'  => '',
    'shipping_city'     => '',
    'shipping_state'    => '',
    'shipping_zip'      => '',
    'shipping_country'  => '',
    'status'            => 'pending'
], $order);

// --- LOGIC KIỂM TRA THANH TOÁN MOMO/QR ---
$is_paid = false;
if (
    (isset($order['payment_status']) && $order['payment_status'] == 'paid') || 
    $order['status'] == 'processing' || 
    $order['status'] == 'completed' ||
    $order['status'] == 'shipped'
) {
    $is_paid = true;
}

// Chỉ hiện QR nếu: Chọn MoMo VÀ Chưa thanh toán VÀ Đơn chưa bị hủy
$show_qr = false;
if ($order['payment_method'] == 'momo' && !$is_paid && $order['status'] != 'cancelled') {
    $show_qr = true;
    
    // CẤU HÌNH VIETQR (SỬA THÔNG TIN CỦA BẠN TẠI ĐÂY)
    $amount   = intval($order['total_amount']);
    $content  = $order['order_number'];
    $nganHang = 'MB';          // Ví dụ: MB, VCB, ACB, TPB
    $stk      = '0865338143';  // Số tài khoản của bạn
    
    $qrSrc    = "https://img.vietqr.io/image/{$nganHang}-{$stk}-compact2.png?amount={$amount}&addInfo={$content}";
}

/* ===============================
   4. LẤY SẢN PHẨM TRONG ĐƠN
================================ */
$stmt = $conn->prepare("
    SELECT 
        oi.*, 
        p.name,
        p.slug,
        (
            SELECT image_url 
            FROM product_images 
            WHERE product_id = p.id 
              AND is_main = 1 
            LIMIT 1
        ) AS image
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = ?
");
$stmt->bind_param("i", $order['id']);
$stmt->execute();
$orderItems = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

$pageTitle = "Xác nhận đơn hàng #" . $orderNumber;
include 'includes/header.php';
include 'includes/navbar.php';
?>

<section class="py-5 bg-light">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-8">

                <?php if ($show_qr): ?>
                    <div class="card border-0 shadow-sm mb-4 border-warning">
                        <div class="card-header bg-warning text-dark fw-bold text-center">
                            <i class="bi bi-qr-code-scan"></i> QUÉT MÃ ĐỂ THANH TOÁN MOMO / NGÂN HÀNG
                        </div>
                        <div class="card-body text-center bg-white" id="qr_container">
                            <p class="mb-1 text-muted">Tổng tiền cần thanh toán:</p>
                            <h3 class="text-danger fw-bold mb-3"><?php echo formatPrice($order['total_amount']); ?></h3>

                            <div class="mt-3 mb-3">
                                <p class="mb-1 text-muted">Vui lòng thanh toán trong:</p>
                                <h4 id="countdown_timer" style="color: #dc3545; font-weight: bold; font-size: 24px;">03:00</h4>
                                <div id="payment_msg" class="small text-muted spinner-border-sm">
                                    <span class="spinner-grow spinner-grow-sm text-warning" role="status"></span>
                                    Đang chờ hệ thống xác nhận...
                                </div>
                            </div>
                            
                            <img src="<?php echo $qrSrc; ?>" class="img-fluid mb-3 border" style="max-width: 300px;">
                            
                            <div class="alert alert-info small">
                                Nội dung chuyển khoản: <strong><?php echo $content; ?></strong>
                            </div>
                            <input type="hidden" id="current_order_id" value="<?php echo $orderNumber; ?>">
                        </div>

                        <div id="timeout_message" style="display: none; padding: 20px;" class="text-center bg-white">
                            <h4 class="text-danger mb-3">Đơn hàng đã hết hạn!</h4>
                            <p class="text-muted">Giao dịch đã bị hủy tự động do quá thời gian thanh toán.</p>
                            <div class="d-grid gap-2 col-8 mx-auto">
                                <a href="cart.php" class="btn btn-warning">Đặt lại đơn hàng</a>
                                <a href="index.php" class="btn btn-outline-secondary">Về trang chủ</a>
                            </div>
                        </div>
                    </div>

                <?php else: ?>
                    <div class="card border-0 shadow-sm mb-4">
                        <div class="card-body p-5 text-center">
                            <?php if ($order['status'] == 'cancelled'): ?>
                                <i class="bi bi-x-circle-fill text-danger mb-3" style="font-size: 4rem;"></i>
                                <h2 class="fw-bold mb-2">Đơn hàng đã hủy</h2>
                                <p class="text-muted mb-4">Rất tiếc, đơn hàng này đã bị hủy.</p>
                            <?php else: ?>
                                <i class="bi bi-check-circle-fill text-success mb-3" style="font-size: 4rem;"></i>
                                <h2 class="fw-bold mb-2">Cảm ơn bạn đã đặt hàng!</h2>
                                <p class="text-muted mb-4">
                                    Đơn hàng <strong>#<?php echo htmlspecialchars($orderNumber); ?></strong>
                                    <?php echo ($order['payment_method'] == 'cod') ? 'đã được tiếp nhận.' : 'đã thanh toán thành công.'; ?>
                                </p>
                            <?php endif; ?>

                            <div class="d-flex justify-content-center gap-3">
                                <a href="index.php" class="btn btn-dark rounded-0 px-4">TIẾP TỤC MUA SẮM</a>
                                <a href="account-orders.php" class="btn btn-outline-dark rounded-0 px-4">
                                    LỊCH SỬ ĐƠN HÀNG
                                </a>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="card border-0 shadow-sm">
                    <div class="card-header bg-white py-3">
                        <h5 class="mb-0 fw-bold">Chi tiết đơn hàng</h5>
                    </div>

                    <div class="card-body p-4">
                        <div class="table-responsive">
                            <table class="table align-middle">
                                <thead>
                                    <tr>
                                        <th>Sản phẩm</th>
                                        <th class="text-center">Số lượng</th>
                                        <th class="text-end">Giá</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php foreach ($orderItems as $item): ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <img
                                                    src="<?php echo $item['image'] ?: 'assets/images/no-image.jpg'; ?>"
                                                    style="width:60px;height:60px;object-fit:cover"
                                                    class="me-3"
                                                >
                                                <strong class="small">
                                                    <?php echo htmlspecialchars($item['name']); ?>
                                                </strong>
                                            </div>
                                        </td>
                                        <td class="text-center">x<?php echo (int)$item['quantity']; ?></td>
                                        <td class="text-end">
                                            <?php echo formatPrice($item['price'] * $item['quantity']); ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>

                                <tfoot>
                                    <tr>
                                        <td colspan="2" class="text-end text-muted">Tạm tính:</td>
                                        <td class="text-end"><?php echo formatPrice($order['subtotal']); ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="text-end text-muted">Phí vận chuyển:</td>
                                        <td class="text-end"><?php echo formatPrice($order['shipping_fee']); ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="text-end fw-bold fs-5">Tổng cộng:</td>
                                        <td class="text-end fw-bold fs-5 text-danger">
                                            <?php echo formatPrice($order['total_amount']); ?>
                                        </td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                        <div class="row mt-4">
                            <div class="col-md-6">
                                <h6 class="fw-bold border-bottom pb-2">Địa chỉ giao hàng</h6>
                                <p class="small text-muted mb-1"><?php echo htmlspecialchars($order['shipping_name']); ?></p>
                                <p class="small text-muted mb-1"><?php echo htmlspecialchars($order['shipping_phone']); ?></p>
                                <p class="small text-muted mb-1"><?php echo htmlspecialchars($order['shipping_address']); ?></p>
                                <p class="small text-muted"><?php echo htmlspecialchars($order['shipping_city']); ?></p>
                            </div>

                            <div class="col-md-6">
                                <h6 class="fw-bold border-bottom pb-2">Thanh toán</h6>
                                <p class="small text-muted text-uppercase">
                                    <?php echo htmlspecialchars($order['payment_method']); ?>
                                </p>

                                <h6 class="fw-bold border-bottom pb-2 mt-3">Trạng thái</h6>
                                <?php 
                                    $statusColors = [
                                        'pending'    => 'bg-warning text-dark',
                                        'processing' => 'bg-info text-white',
                                        'shipped'    => 'bg-primary text-white',
                                        'completed'  => 'bg-success text-white',
                                        'cancelled'  => 'bg-danger text-white',
                                        'failed'     => 'bg-dark text-white'
                                    ];
                                    $currentStatus = strtolower($order['status']);
                                    $badgeClass = $statusColors[$currentStatus] ?? 'bg-secondary text-white';
                                ?>
                                <span class="badge <?php echo $badgeClass; ?> rounded-0">
                                    <?php echo strtoupper($order['status']); ?>
                                </span>
                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>

<?php if ($show_qr): ?>
<script>
document.addEventListener("DOMContentLoaded", function() {
    var timeLeft = 180; // 3 phút = 180 giây
    var timerDisplay = document.getElementById('countdown_timer');
    var qrContainer = document.getElementById('qr_container');
    var timeoutMsg = document.getElementById('timeout_message');
    var orderNumber = '<?php echo $orderNumber; ?>';
    
    // 1. Đồng hồ đếm ngược
    var countdown = setInterval(function() {
        var m = Math.floor(timeLeft / 60);
        var s = timeLeft % 60;
        timerDisplay.innerText = "0" + m + ":" + (s < 10 ? "0" + s : s);

        if (timeLeft <= 0) {
            clearInterval(countdown);
            // Hết giờ -> Gọi file hủy đơn (cần tạo file cancel_order.php)
            fetch('cancel_order.php?order_number=' + orderNumber); 
            
            // Ẩn QR, hiện thông báo hết hạn
            if(qrContainer) qrContainer.style.display = 'none';
            if(timeoutMsg) timeoutMsg.style.display = 'block';
        }
        timeLeft--;
    }, 1000);

    // 2. Polling kiểm tra trạng thái thanh toán (Mỗi 2 giây)
    var checkLoop = setInterval(function() {
        if (timeLeft > 0) {
            // Cần tạo file check_payment_status.php trả về JSON
            fetch('check_payment_status.php?order_number=' + orderNumber)
            .then(res => res.json())
            .then(data => {
                if (data.status === 'paid' || data.status === 'processing' || data.status === 'completed') {
                    clearInterval(checkLoop);
                    clearInterval(countdown);
                    window.location.reload(); // Load lại trang để hiện thông báo thành công
                }
            })
            .catch(err => console.log('Waiting for payment...'));
        }
    }, 2000);
});
</script>
<?php endif; ?>
