<?php
session_start();
include 'includes/header.php';

// Nếu chưa có SĐT trong session thì đá về trang đầu
if (!isset($_SESSION['reset_phone'])) {
    header("Location: forgot_password.php");
    exit();
}

$error = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_otp = $_POST['otp_code'];
    
    // Kiểm tra mã người dùng nhập có trùng mã hệ thống tạo không
    if ($user_otp == $_SESSION['otp']) {
        // Đúng mã -> Cho phép đổi mật khẩu
        $_SESSION['otp_verified'] = true;
        header("Location: reset_password.php");
        exit();
    } else {
        $error = "Mã OTP không đúng!";
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-5">
            <div class="card shadow">
                <div class="card-body p-4">
                    <h3 class="text-center mb-3">NHẬP MÃ XÁC NHẬN</h3>
                    <p class="text-center text-muted">Mã OTP đã gửi về <?php echo $_SESSION['reset_phone']; ?></p>
                    
                    <?php if($error) echo "<div class='alert alert-danger'>$error</div>"; ?>
                    
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Mã OTP (6 số)</label>
                            <input type="text" name="otp_code" class="form-control" required>
                        </div>
                        <button type="submit" class="btn btn-dark w-100">XÁC NHẬN</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
