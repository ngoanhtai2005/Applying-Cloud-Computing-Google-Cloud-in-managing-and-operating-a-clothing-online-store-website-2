<?php
session_start();

// 1. Dùng đường dẫn tuyệt đối để nhúng config
require_once(__DIR__ . '/../config/database.php');
$conn = getDBConnection();

// 2. Kiểm tra đăng nhập - Nếu sai chuyển về login.php cùng cấp
if(!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}
// Get dashboard statistics
$stats = [];

// Tổng doanh thu tháng này
$revenueQuery = "SELECT SUM(total_amount) as month_revenue FROM orders 
                 WHERE status = 'delivered' 
                 AND MONTH(created_at) = MONTH(CURRENT_DATE()) 
                 AND YEAR(created_at) = YEAR(CURRENT_DATE())";
$revenueResult = mysqli_query($conn, $revenueQuery);
$revenueRow = mysqli_fetch_assoc($revenueResult);
$stats['month_revenue'] = $revenueRow['month_revenue'] ?: 0;

// Tổng đơn hàng tháng này
$ordersQuery = "SELECT COUNT(*) as month_orders FROM orders 
                WHERE MONTH(created_at) = MONTH(CURRENT_DATE()) 
                AND YEAR(created_at) = YEAR(CURRENT_DATE())";
$ordersResult = mysqli_query($conn, $ordersQuery);
$ordersRow = mysqli_fetch_assoc($ordersResult);
$stats['month_orders'] = $ordersRow['month_orders'] ?: 0;

// Sản phẩm đang hoạt động (sản phẩm có stock > 0)
$productsQuery = "SELECT COUNT(*) as active_products FROM products WHERE stock > 0";
$productsResult = mysqli_query($conn, $productsQuery);
$productsRow = mysqli_fetch_assoc($productsResult);
$stats['active_products'] = $productsRow['active_products'] ?: 0;

// Tổng người dùng
$usersQuery = "SELECT COUNT(*) as total_users FROM users";
$usersResult = mysqli_query($conn, $usersQuery);
$usersRow = mysqli_fetch_assoc($usersResult);
$stats['total_users'] = $usersRow['total_users'] ?: 0;

// Get recent orders
$recentOrdersQuery = "SELECT o.*, u.name as customer_name 
                      FROM orders o 
                      LEFT JOIN users u ON o.user_id = u.id 
                      ORDER BY o.created_at DESC 
                      LIMIT 10";
$recentOrdersResult = mysqli_query($conn, $recentOrdersQuery);
$recentOrders = mysqli_fetch_all($recentOrdersResult, MYSQLI_ASSOC);
// Get top selling products (dựa trên order_item)
$topProductsQuery = "SELECT p.id, p.name,
                     (SELECT image_url FROM product_images WHERE product_id = p.id LIMIT 1) as image,
                     COALESCE(SUM(oi.quantity), 0) as total_sold
                     FROM products p
                     LEFT JOIN order_items oi ON p.id = oi.product_id
                     LEFT JOIN orders o ON oi.order_id = o.id AND o.status = 'delivered'
                     GROUP BY p.id, p.name
                     ORDER BY total_sold DESC 
                     LIMIT 5";
$topProductsResult = mysqli_query($conn, $topProductsQuery);
$topProducts = mysqli_fetch_all($topProductsResult, MYSQLI_ASSOC); 
// Get monthly revenue data for chart
$monthlyRevenueQuery = "SELECT 
                        DATE_FORMAT(created_at, '%Y-%m') as month,
                        SUM(total_amount) as revenue
                        FROM orders 
                        WHERE status = 'delivered' 
                        AND created_at >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
                        GROUP BY DATE_FORMAT(created_at, '%Y-%m')
                        ORDER BY month ASC";
$monthlyRevenueResult = mysqli_query($conn, $monthlyRevenueQuery);
$monthlyData = mysqli_fetch_all($monthlyRevenueResult, MYSQLI_ASSOC);

// Get order status distribution
$statusQuery = "SELECT 
                status,
                COUNT(*) as count
                FROM orders 
                GROUP BY status";
$statusResult = mysqli_query($conn, $statusQuery);
$statusData = mysqli_fetch_all($statusResult, MYSQLI_ASSOC);

// Get additional stats
$todayOrdersQuery = "SELECT COUNT(*) as today_orders FROM orders WHERE DATE(created_at) = CURDATE()";
$todayOrdersResult = mysqli_query($conn, $todayOrdersQuery);
$todayOrdersRow = mysqli_fetch_assoc($todayOrdersResult);
$stats['today_orders'] = $todayOrdersRow['today_orders'] ?: 0;

$pendingOrdersQuery = "SELECT COUNT(*) as pending_orders FROM orders WHERE status = 'pending'";
$pendingOrdersResult = mysqli_query($conn, $pendingOrdersQuery);
$pendingOrdersRow = mysqli_fetch_assoc($pendingOrdersResult);
$stats['pending_orders'] = $pendingOrdersRow['pending_orders'] ?: 0;

$outOfStockQuery = "SELECT COUNT(*) as out_of_stock FROM products WHERE stock <= 0";
$outOfStockResult = mysqli_query($conn, $outOfStockQuery);
$outOfStockRow = mysqli_fetch_assoc($outOfStockResult);
$stats['out_of_stock'] = $outOfStockRow['out_of_stock'] ?: 0;

$avgRatingQuery = "SELECT AVG(rating) as avg_rating FROM reviews";
$avgRatingResult = mysqli_query($conn, $avgRatingQuery);
$avgRatingRow = mysqli_fetch_assoc($avgRatingResult);
$stats['avg_rating'] = $avgRatingRow['avg_rating'] ?: 0;

// Prepare chart data
$months = [];
$revenues = [];
foreach ($monthlyData as $data) {
    $months[] = date('M Y', strtotime($data['month'] . '-01'));
    $revenues[] = floatval($data['revenue']);
}

// Prepare status chart data
$statusLabels = [];
$statusCounts = [];
foreach ($statusData as $status) {
    $statusLabels[] = ucfirst($status['status']);
    $statusCounts[] = $status['count'];
}

// Đóng kết nối
mysqli_close($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Fashion Store</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Custom Admin CSS -->
    <link href="assets/css/admin.css" rel="stylesheet">
</head>
<body>
<?php include 'includes/header.php'; ?>
<div class="container-fluid">
    <div class="row">
        <?php include 'includes/sidebar.php'; ?>
        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
            <!-- Page Header -->
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <h1 class="h2">Dashboard</h1>
                <div class="btn-toolbar mb-2 mb-md-0">
                    <div class="btn-group me-2">
                        <button type="button" class="btn btn-sm btn-outline-secondary">Export</button>
                        <button type="button" class="btn btn-sm btn-outline-secondary">Print</button>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-secondary dropdown-toggle">
                        <i class="bi bi-calendar"></i> This week
                    </button>
                </div>
            </div>
  <!-- Stats Cards -->
            <div class="row mb-4">
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-primary">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-uppercase mb-2">Total Revenue</h6>
                                    <h2 class="mb-0"><?php echo number_format($stats['month_revenue'] ?? 0, 0, ',', '.'); ?>đ</h2>
                                    <small class="opacity-75">This month</small>
                                </div>
                                <i class="bi bi-currency-dollar fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-success">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-uppercase mb-2">Orders</h6>
                                    <h2 class="mb-0"><?php echo $stats['month_orders'] ?? 0; ?></h2>
                                    <small class="opacity-75">This month</small>
                                </div>
                                <i class="bi bi-bag fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-info">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-uppercase mb-2">Products</h6>
                                    <h2 class="mb-0"><?php echo $stats['active_products'] ?? 0; ?></h2>
                                    <small class="opacity-75">Active</small>
                                </div>
                                <i class="bi bi-box fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-3 mb-3">
                    <div class="card text-white bg-warning">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="card-title text-uppercase mb-2">Customers</h6>
                                    <h2 class="mb-0"><?php echo $stats['total_users'] ?? 0; ?></h2>
                                    <small class="opacity-75">Total users</small>
                                </div>
                                <i class="bi bi-people fs-1 opacity-50"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Charts Row -->
            <div class="row mb-4">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Revenue Overview</h6>
                        </div>
                        <div class="card-body">
                            <canvas id="revenueChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Order Status</h6>
                        </div>
                        <div class="card-body">
                            <canvas id="statusChart" height="250"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Recent Orders & Top Products -->
            <div class="row">
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h6 class="mb-0">Recent Orders</h6>
                            <a href="orders.php" class="btn btn-sm btn-outline-primary">View All</a>
                        </div>
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover mb-0">
                                    <thead>
                                        <tr>
                                            <th>Order #</th>
                                            <th>Customer</th>
                                            <th>Date</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                         <?php foreach ($recentOrders as $order): ?>
                                        <tr>
                                            <td><?php echo $order['order_number']; ?></td>
                                            <td><?php echo htmlspecialchars($order['customer_name'] ?? 'Guest'); ?></td>
                                            <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
        
                                            <td><?php echo number_format($order['total_amount'] ?? 0, 0, ',', '.'); ?>đ</td>

                                            <td>
                                                <span class="badge <?php echo $order['status'] === 'delivered' ? 'bg-success' : ($order['status'] === 'processing' ? 'bg-primary' : ($order['status'] === 'shipped' ? 'bg-info' : 'bg-warning')); ?>">
                                                    <?php
                                                    $statusText = [
                                                        'pending' => 'Pending',
                                                        'processing' => 'Processing',
                                                        'shipped' => 'Shipped',
                                                        'delivered' => 'Delivered',
                                                        'cancelled' => 'Cancelled'
                                                    ];
                                                    echo $statusText[$order['status']] ?? $order['status'];
                                                    ?>
                                                </span>
                                            </td>
                                            <td>
                                                <a href="orders/view.php?id=<?php echo $order['id']; ?>" class="btn btn-sm btn-outline-primary">View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
<div class="col-md-4">
                    <div class="card">
                        <div class="card-header">
                            <h6 class="mb-0">Top Selling Products</h6>
                        </div>
                        <div class="card-body">
                            <?php foreach ($topProducts as $product): ?>
                            <div class="d-flex align-items-center mb-3">
                                <div class="flex-shrink-0">
                                    <?php
                                    if (!empty($product['image'])) {
                                        if (strpos($product['image'], 'http') === 0) {
                                            $imgSrc = $product['image']; // Ảnh online
                                        } else {
                                            $imgSrc = '../' . $product['image']; // Ảnh upload local
                                        }
                                    } else {
                                        $imgSrc = 'assets/images/default-product.jpg';
                                    }
                                    ?>

                                    <img src="<?php echo htmlspecialchars($imgSrc); ?>"
                                         alt="<?php echo htmlspecialchars($product['name']); ?>" 
                                         class="rounded" 
                                         style="width: 50px; height: 50px; object-fit: cover;">
                                </div>
                                <div class="flex-grow-1 ms-3">
                                    <h6 class="mb-0"><?php echo htmlspecialchars($product['name']); ?></h6>
                                    <small class="text-muted">Sold: <?php echo $product['total_sold'] ?? 0; ?> units</small>
                                </div>
                                <div class="flex-shrink-0">
                                    <a href="products/edit.php?id=<?php echo $product['id']; ?>" class="btn btn-sm btn-outline-secondary">Edit</a>
                                </div>
                            </div>
                            <?php endforeach; ?>
                            <?php if (empty($topProducts)): ?>
                                <p class="text-muted text-center mb-0">No sales data available</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
              <!-- Quick Stats -->
            <div class="row mt-4">
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h1 class="display-6 text-danger"><?php echo $stats['today_orders'] ?? 0; ?></h1>
                            <p class="text-muted mb-0">Today's Orders</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h1 class="display-6 text-warning"><?php echo $stats['pending_orders'] ?? 0; ?></h1>
                            <p class="text-muted mb-0">Pending Orders</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h1 class="display-6 text-info"><?php echo $stats['out_of_stock'] ?? 0; ?></h1>
                            <p class="text-muted mb-0">Out of Stock</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h1 class="display-6 text-success"><?php echo number_format($stats['avg_rating'] ?? 0, 1); ?></h1>
                            <p class="text-muted mb-0">Average Rating</p>
                        </div>
                    </div>
                </div>
            </div>
        </main>
          </div>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // Revenue Chart
    const revenueCtx = document.getElementById('revenueChart').getContext('2d');
    const revenueChart = new Chart(revenueCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode($months); ?>,
            datasets: [{
                label: 'Revenue (đ)',
                data: <?php echo json_encode($revenues); ?>,
                borderColor: '#4e73df',
                backgroundColor: 'rgba(78, 115, 223, 0.05)',
                borderWidth: 2,
                fill: true,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: { legend: { display: false } },
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) { return value.toLocaleString() + ' đ'; }
                    }
                }
            }
        }
    });
// Status Chart
    const statusCtx = document.getElementById('statusChart').getContext('2d');
    const statusChart = new Chart(statusCtx, {
        type: 'doughnut',
        data: {
            labels: <?php echo json_encode($statusLabels); ?>,
            datasets: [{
                data: <?php echo json_encode($statusCounts); ?>,
                backgroundColor: ['#ffc107','#17a2b8','#007bff','#28a745','#dc3545'],
                borderWidth: 1,
                borderColor: '#fff'
            }]
        },
        options: {
            responsive: true,
            cutout: '70%',
            plugins: { legend: { position: 'bottom' } }
        }
    });

    // Auto refresh stats every 60s
    setInterval(() => {
        fetch('ajax/refresh_stats.php')
        .then(res => res.json())
        .then(data => {
            document.querySelector('.card.bg-primary h2').textContent = (data.month_revenue ?? 0).toLocaleString('vi-VN') + ' đ';
            document.querySelector('.card.bg-success h2').textContent = data.month_orders ?? 0;
            document.querySelector('.card.bg-info h2').textContent = data.active_products ?? 0;
            document.querySelector('.card.bg-warning h2').textContent = data.total_users ?? 0;
        }).catch(err => console.error(err));
    }, 60000);
</script>
</body>
</html>
