<?php
session_start();

/* ================== AUTH ================== */
if (!isset($_SESSION['admin_id'], $_SESSION['admin_username'])) {
    header('Location: ../login.php');
    exit;
}

/* ================== DB ==================*/
require_once(__DIR__ . '/../config/database.php'); 
$conn = getDBConnection();
/* ================== GET ID ================== */
$id = (int)($_GET['id'] ?? 0);
if (!$id) {
    header('Location: list.php');
    exit;
}

/* ================== FETCH CATEGORY ================== */
$res = mysqli_query($conn, "SELECT * FROM categories WHERE id = $id");
$category = mysqli_fetch_assoc($res);
if (!$category) {
    header('Location: list.php');
    exit;
}

/* ================== POST HANDLE ================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = trim($_POST['name']);
    $name_safe = mysqli_real_escape_string($conn, $name);

    /* ---- SLUG ---- */
    if ($name !== $category['name']) {
        $base = strtolower($name);
        $base = iconv('UTF-8', 'ASCII//TRANSLIT', $base);
        $base = preg_replace('/[^a-z0-9\s-]/', '', $base);
        $base = preg_replace('/\s+/', '-', trim($base));

        $slug = $base;
        $i = 1;
        while (mysqli_num_rows(mysqli_query(
            $conn,
            "SELECT id FROM categories WHERE slug='$slug' AND id != $id"
        )) > 0) {
            $slug = $base . '-' . $i++;
        }
    } else {
        $slug = $category['slug'];
    }

    /* ---- PARENT ---- */
    $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

    /* ---- STATUS ---- */
    $status = $_POST['status'] ?? 'active';

    /* ---- UPDATE ---- */
    $sql = "
        UPDATE categories SET
            name = '$name_safe',
            slug = '$slug',
            parent_id = " . ($parent_id === null ? "NULL" : $parent_id) . ",
            status = '$status'
        WHERE id = $id
    ";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success_message'] = "Cập nhật danh mục thành công!";
        header('Location: list.php');
        exit;
    } else {
        $error = "Lỗi cập nhật: " . mysqli_error($conn);
    }
}

/* ================== PARENT CATEGORIES ================== */
$parent_categories = mysqli_query(
    $conn,
    "SELECT id, name FROM categories 
     WHERE parent_id IS NULL AND id != $id
     ORDER BY name ASC"
);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Sửa danh mục</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css" rel="stylesheet">
<link href="../assets/css/admin.css" rel="stylesheet">

<style>
:root{
    --ez-orange:#FF8A00;
    --ez-bg:#F9F7F5;
}
body{background:var(--ez-bg)}
.card{border:none;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.04)}
.form-control{border-radius:10px;padding:12px}
.form-control:focus{border-color:var(--ez-orange);box-shadow:0 0 0 .2rem rgba(255,138,0,.15)}
.btn-orange{background:var(--ez-orange);color:#fff;border-radius:10px}
.btn-orange:hover{background:#e67e00}
</style>
</head>

<body>
<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">
<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<nav class="breadcrumb mb-3">
    <a class="breadcrumb-item" href="../index.php">Dashboard</a>
    <a class="breadcrumb-item" href="list.php">Danh mục</a>
    <span class="breadcrumb-item active">Sửa</span>
</nav>

<h1 class="h4 mb-4">
    <i class="bi bi-pencil-square me-2"></i>Sửa danh mục #<?= $category['id']; ?>
</h1>

<div class="row">

<!-- FORM -->
<div class="col-md-8">
<div class="card">
<div class="card-body">

<?php if(isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="post">

<div class="mb-3">
    <label class="form-label">Tên danh mục *</label>
    <input type="text" name="name" class="form-control" required
           value="<?= htmlspecialchars($category['name']) ?>">
</div>

<div class="mb-3">
    <label class="form-label">Slug</label>
    <input type="text" class="form-control" disabled
           value="<?= $category['slug'] ?>">
    <div class="form-text">Slug tự cập nhật khi đổi tên</div>
</div>

<div class="mb-3">
    <label class="form-label">Danh mục cha</label>
    <select name="parent_id" class="form-control">
        <option value="">— Danh mục gốc —</option>
        <?php while($p = mysqli_fetch_assoc($parent_categories)): ?>
            <option value="<?= $p['id']; ?>"
                <?= ($p['id'] == $category['parent_id']) ? 'selected' : '' ?>>
                <?= htmlspecialchars($p['name']); ?>
            </option>
        <?php endwhile; ?>
    </select>
</div>

<div class="mb-4">
    <label class="form-label">Trạng thái</label>
    <div class="d-flex gap-4">
        <label>
            <input type="radio" name="status" value="active"
                <?= $category['status'] === 'inactive' ? '' : 'checked' ?>>
            Hoạt động
        </label>
        <label>
            <input type="radio" name="status" value="inactive"
                <?= $category['status'] === 'inactive' ? 'checked' : '' ?>>
            Không hoạt động
        </label>
    </div>
</div>

<div class="d-flex justify-content-end gap-2">
    <a href="list.php" class="btn btn-secondary">Hủy</a>
    <button class="btn btn-orange">
        <i class="bi bi-check-circle me-1"></i>Cập nhật
    </button>
</div>

</form>
</div>
</div>
</div>

<!-- INFO -->
<div class="col-md-4">
<div class="card">
<div class="card-body">

<h6 class="mb-3 d-flex align-items-center">
    <i class="bi bi-info-circle me-2 text-warning"></i>
    Thông tin danh mục
</h6>

<ul class="list-unstyled small mb-3">
    <li class="mb-2 d-flex justify-content-between">
        <span class="text-muted">ID</span>
        <strong>#<?= $category['id']; ?></strong>
    </li>
    <li class="mb-2 d-flex justify-content-between">
        <span class="text-muted">Slug</span>
        <span><?= $category['slug']; ?></span>
    </li>
    <li class="mb-2 d-flex justify-content-between">
        <span class="text-muted">Trạng thái</span>
        <?= $category['status'] === 'active'
            ? '<span class="badge bg-success">Hoạt động</span>'
            : '<span class="badge bg-secondary">Không hoạt động</span>' ?>
    </li>
</ul>

<hr>

<h6 class="mb-2 d-flex align-items-center">
    <i class="bi bi-exclamation-circle me-2 text-danger"></i>
    Lưu ý chỉnh sửa
</h6>

<ul class="small text-muted ps-3 mb-0">
    <li>Đổi <strong>tên</strong> sẽ tự cập nhật slug</li>
    <li>Slug phải <strong>duy nhất</strong> trong hệ thống</li>
    <li>Danh mục cha chỉ áp dụng cho danh mục cấp 1</li>
    <li>Danh mục <strong>không hoạt động</strong> sẽ ẩn ở frontend</li>
</ul>

</div>
</div>
</div>

</div>
</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
