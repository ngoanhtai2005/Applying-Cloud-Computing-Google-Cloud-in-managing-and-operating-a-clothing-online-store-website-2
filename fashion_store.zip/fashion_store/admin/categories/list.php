<?php
session_start();



// 1. Kết nối Database qua file config (Lùi 2 cấp để vào thư mục config)
require_once(__DIR__ . '/../../config/database.php');
$conn = getDBConnection();

// 2. Kiểm tra đăng nhập (Nếu sai, lùi 1 cấp để ra thư mục admin tìm login.php)
if(!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}
// Lấy danh sách danh mục
$categories = mysqli_query($conn, "
    SELECT c1.*, c2.name as parent_name 
    FROM categories c1 
    LEFT JOIN categories c2 ON c1.parent_id = c2.id 
    ORDER BY c1.id ASC
");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý Danh mục - Fashion Store Admin</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom Admin CSS -->
    <link href="../assets/css/admin.css" rel="stylesheet">
    <style>
        :root {
            --ez-orange: #FF8A00;
            --ez-bg: #F9F7F5;
            --ez-card-bg: #FFFFFF;
            --ez-text: #333;
        }

        body {
            background: var(--ez-bg);
            font-family: 'Inter', sans-serif;
        }

        /* đảm bảo nội dung không đè header */
        .admin-wrapper {
            padding-top: 90px;
        }

        /* ===== CARD ===== */
        .card {
            border: none;
            border-radius: 16px;
            background: var(--ez-card-bg);
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
        }

        .stat-value {
            font-size: 1.8rem;
            font-weight: 700;
            color: var(--ez-orange);
        }

        .stat-label {
            font-size: .75rem;
            text-transform: uppercase;
            color: #888;
            letter-spacing: 1px;
        }

        /* TABLE */
        .table th {
            font-size: .8rem;
            color: #888;
            font-weight: 600;
            border-top: none;
            padding: 12px 16px;
        }

        .table td {
            vertical-align: middle;
            padding: 16px;
            border-bottom: 1px solid #f0f0f0;
        }

        .table tr:last-child td {
            border-bottom: none;
        }

        /* BUTTON */
        .btn-orange {
            background: var(--ez-orange);
            border: none;
            border-radius: 10px;
            color: white;
            padding: 10px 20px;
            font-weight: 500;
        }

        .btn-orange:hover {
            background: #e67e00;
            color: white;
        }

        .btn-sm {
            padding: 5px 12px;
            font-size: 0.875rem;
        }

        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: #222;
        }

        .page-subtitle {
            font-size: 0.85rem;
            color: #999;
            margin-top: 4px;
        }

        /* Status badges */
        .badge-status {
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 500;
        }

        .badge-active {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
        }

        .badge-inactive {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>   
    <div class="container-fluid">
        <div class="row">
            <?php include __DIR__ . '/../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 20px;">
                <!-- Page Header -->
                <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center  pb-2 mb-3">
                    <div>
                         
                        <h1 class="h2 page-title">
                             <i class="bi bi-tags text-orange me-2"></i>Quản lý Danh mục</h1>
                        <p class="page-subtitle">Quản lý danh mục sản phẩm của cửa hàng</p>
                    </div>
                    <div class="btn-toolbar mb-2 mb-md-0">
                        <a href="add.php" class="btn btn-orange">
                            <i class="bi bi-plus-circle me-2"></i>Thêm danh mục
                        </a>
                    </div>
                </div>

              
                <!-- Table -->
                <div class="card shadow-sm">
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Tên danh mục</th>
                                        <th>Slug</th>
                                        <th>Danh mục cha</th>
                                        <th>Trạng thái</th>
                                        <th>Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                    if(mysqli_num_rows($categories) > 0):
                                        while($row = mysqli_fetch_assoc($categories)): 
                                    ?>
                                    <tr>
                                        <td><strong><?php echo $row['id']; ?></strong></td>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="me-2" style="width: 24px; height: 24px; border-radius: 4px; background: #FF8A00; display: flex; align-items: center; justify-content: center;">
                                                    <i class="bi bi-tag text-white" style="font-size: 12px;"></i>
                                                </div>
                                                <span class="fw-medium"><?php echo htmlspecialchars($row['name']); ?></span>
                                            </div>
                                        </td>
                                        <td>
                                            <span class="badge bg-light text-dark border">
                                                <?php echo $row['slug']; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <?php if($row['parent_name']): ?>
                                                <span class="badge bg-info bg-opacity-10 text-info border border-info">
                                                    <?php echo htmlspecialchars($row['parent_name']); ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="text-muted">—</span>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php 
                                                $status = $row['status'] ?? 'active';
                                                $statusClass = ($status == 'active') ? 'badge-active' : 'badge-inactive';
                                                $statusText = ($status == 'active') ? 'Hoạt động' : 'Không hoạt động';
                                            ?>
                                            <span class="badge-status <?php echo $statusClass; ?>">
                                                <?php echo $statusText; ?>
                                            </span>
                                        </td>
                                        <td>
                                            <div class="d-flex gap-2">
                                                <a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-warning" title="Sửa">
                                                    <i class="bi bi-pencil"></i>
                                                </a>
                                                <a href="delete.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-danger" 
                                                   onclick="return confirm('Bạn có chắc muốn xóa danh mục này? Hành động này không thể hoàn tác.')" title="Xóa">
                                                    <i class="bi bi-trash"></i>
                                                </a>
                                            
                                      
                                                
                                            </div>
                                        </td>
                                    </tr>
                                    <?php 
                                        endwhile;
                                    else: 
                                    ?>
                                    <tr>
                                        <td colspan="6" class="text-center py-4">
                                            <div class="text-muted">
                                                <i class="bi bi-tags" style="font-size: 48px; opacity: 0.3;"></i>
                                                <p class="mt-3">Chưa có danh mục nào. Hãy thêm danh mục đầu tiên!</p>
                                                <a href="add.php" class="btn btn-orange btn-sm mt-2">Thêm danh mục</a>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                                  <!-- Pagination (nếu cần) -->
                        <div class="d-flex justify-content-between align-items-center mt-4">
                            <div class="text-muted">
                                Hiển thị <strong><?php echo mysqli_num_rows($categories); ?></strong> danh mục
                            </div>
                            <nav aria-label="Page navigation">
                                <ul class="pagination pagination-sm mb-0">
                                    <li class="page-item disabled">
                                        <a class="page-link" href="#" tabindex="-1">Previous</a>
                                    </li>
                                    <li class="page-item active"><a class="page-link" href="#">1</a></li>
                                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                                    <li class="page-item">
                                        <a class="page-link" href="#">Next</a>
                                    </li>
                                </ul>
                            </nav>    
                      
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Active menu highlighting
        document.addEventListener('DOMContentLoaded', function() {
            // Set active for categories menu
            const categoriesLink = document.querySelector('a[href*="categories"]');
            if (categoriesLink) {
                categoriesLink.classList.add('active');
            }
            
            // Search functionality
            const searchInput = document.querySelector('.header-search-container input');
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    const searchTerm = e.target.value.toLowerCase();
                    const rows = document.querySelectorAll('.table tbody tr');
                    
                    rows.forEach(row => {
                        const text = row.textContent.toLowerCase();
                        if (text.includes(searchTerm)) {
                            row.style.display = '';
                        } else {
                            row.style.display = 'none';
                        }
                    });
                });
            }
        });
    </script>
</body>
</html>

<?php
// Đóng kết nối DB
mysqli_close($conn);
?>
