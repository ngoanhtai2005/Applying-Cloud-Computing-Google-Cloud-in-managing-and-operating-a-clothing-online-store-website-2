<?php
session_start();

// ===== KIỂM TRA ĐĂNG NHẬP =====
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
    header('Location: ../login.php');
    exit;
}

// ===== KẾT NỐI DB =====
require_once(__DIR__ . '/../config/database.php'); 
$conn = getDBConnection();
// ===== XỬ LÝ FORM =====
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = mysqli_real_escape_string($conn, trim($_POST['name']));

    // slug chuẩn SEO
    $slug = strtolower($name);
    $slug = iconv('UTF-8', 'ASCII//TRANSLIT', $slug);
    $slug = preg_replace('/[^a-z0-9\s-]/', '', $slug);
    $slug = preg_replace('/\s+/', '-', $slug);
    $slug = trim($slug, '-');

    $status = $_POST['status'] ?? 'active';
    $parent_id = !empty($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;

    $sql = "INSERT INTO categories (name, slug, parent_id, status)
            VALUES (
                '$name',
                '$slug',
                " . ($parent_id === null ? "NULL" : $parent_id) . ",
                '$status'
            )";

    if (mysqli_query($conn, $sql)) {
        $_SESSION['success_message'] = "Thêm danh mục thành công!";
        header('Location: list.php');
        exit;
    } else {
        $error = "Lỗi khi thêm danh mục: " . mysqli_error($conn);
    }
}

// ===== CHỈ LẤY DANH MỤC GỐC =====
$parent_categories = mysqli_query(
    $conn,
    "SELECT id, name 
     FROM categories 
     WHERE parent_id IS NULL 
     ORDER BY name ASC"
);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thêm Danh mục</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #FFFFFF;
}
body {
    background: var(--ez-bg);
}
.card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,.04);
}
.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}
.page-subtitle {
    font-size: .85rem;
    color: #888;
}
.form-control {
    border-radius: 10px;
    padding: 12px 16px;
}
.btn-orange {
    background: var(--ez-orange);
    color: #fff;
    border-radius: 10px;
}
.btn-orange:hover {
    background: #e67e00;
    color: #fff;
}
</style>
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">
            <i class="bi bi-plus-circle text-warning me-2"></i>
            Thêm danh mục mới
        </h1>
        <p class="page-subtitle">Tạo danh mục sản phẩm</p>
    </div>

    <a href="list.php" class="btn btn-outline-secondary">
        <i class="bi bi-list"></i> Danh sách
    </a>
</div>

<div class="row">
<div class="col-md-8">

<div class="card">
<div class="card-body">

<?php if (isset($error)): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST">

<!-- TÊN -->
<div class="mb-3">
    <label class="form-label">Tên danh mục *</label>
    <input type="text" name="name" class="form-control" required>
</div>

<!-- SLUG -->
<div class="mb-3">
    <label class="form-label">Slug</label>
    <input type="text" class="form-control" name="slug_preview" disabled>
    <div class="form-text">Tự động tạo từ tên</div>
</div>

<!-- DANH MỤC CHA (CHUẨN) -->
<div class="mb-4">
    <label class="form-label">Danh mục cha</label>
    <select name="parent_id" class="form-control">
        <option value="">— Danh mục gốc —</option>
        <?php while ($cat = mysqli_fetch_assoc($parent_categories)): ?>
            <option value="<?= $cat['id'] ?>">
                <?= htmlspecialchars($cat['name']) ?>
            </option>
        <?php endwhile; ?>
    </select>
    <div class="form-text">Chỉ chọn khi là danh mục con</div>
</div>

<!-- STATUS -->
<div class="mb-4">
    <label class="form-label">Trạng thái</label><br>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="status" value="active" checked>
        <label class="form-check-label">Hoạt động</label>
    </div>
    <div class="form-check form-check-inline">
        <input class="form-check-input" type="radio" name="status" value="inactive">
        <label class="form-check-label">Không hoạt động</label>
    </div>
</div>

<div class="text-end">
    <a href="list.php" class="btn btn-secondary">
        <i class="bi bi-x-circle"></i> Hủy
    </a>
    <button class="btn btn-orange">
        <i class="bi bi-check-circle"></i> Lưu
    </button>
</div>

</form>
</div>
</div>

</div>
</div>

</main>
</div>
</div>

<script>
const nameInput = document.querySelector('input[name="name"]');
const slugInput = document.querySelector('input[name="slug_preview"]');

nameInput.addEventListener('input', () => {
    slugInput.value = nameInput.value
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^\w\s]/g, '')
        .replace(/\s+/g, '-');
});
</script>

</body>
</html>

<?php mysqli_close($conn); ?>
