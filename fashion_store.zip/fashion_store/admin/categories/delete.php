<?php
session_start();

// Kiểm tra đăng nhập
if(!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
    header('Location: ../login.php');
    exit;
}

// Kết nối cơ sở dữ liệu
require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$confirmed = isset($_GET['confirm']) && $_GET['confirm'] === 'yes';

if(!$id) {
    header('Location:list.php');
    exit;
}

// Lấy thông tin danh mục
$category_query = mysqli_query($conn, "SELECT * FROM categories WHERE id=$id");
$category = mysqli_fetch_assoc($category_query);

if(!$category) {
    $_SESSION['error_message'] = "Danh mục không tồn tại!";
    header('Location: list.php');
    exit;
}

// Kiểm tra xem danh mục có sản phẩm không
$check_products = mysqli_query($conn, "SELECT COUNT(*) as count FROM products WHERE category_id=$id");
$products_result = mysqli_fetch_assoc($check_products);
$product_count = $products_result['count'];

// Kiểm tra xem danh mục có danh mục con không
$check_children = mysqli_query($conn, "SELECT COUNT(*) as count FROM categories WHERE parent_id=$id");
$children_result = mysqli_fetch_assoc($check_children);
$children_count = $children_result['count'];

// Xử lý xóa khi đã xác nhận
if($confirmed) {
    if($product_count == 0 && $children_count == 0) {
        $sql = "DELETE FROM categories WHERE id=$id";
        if(mysqli_query($conn, $sql)) {
            $_SESSION['success_message'] = "Xóa danh mục '{$category['name']}' thành công!";
        } else {
            $_SESSION['error_message'] = "Lỗi khi xóa danh mục: " . mysqli_error($conn);
        }
    } else {
        $_SESSION['error_message'] = "Không thể xóa danh mục '{$category['name']}'!<br>";
        if($product_count > 0) {
            $_SESSION['error_message'] .= "- Có $product_count sản phẩm thuộc danh mục này.<br>";
        }
        if($children_count > 0) {
            $_SESSION['error_message'] .= "- Có $children_count danh mục con thuộc danh mục này.";
        }
    }

    header('Location: list.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Xóa Danh mục - Fashion Store Admin</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom Admin CSS -->
    <link href="../assets/css/admin.css" rel="stylesheet">
    <style>
        :root {
            --ez-orange: #FF8A00;
            --ez-bg: #F9F7F5;
            --ez-card-bg: #FFFFFF;
            --ez-text: #333;
            --ez-danger: #dc3545;
        }

        body {
            background: var(--ez-bg);
            font-family: 'Inter', sans-serif;
        }

        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: #222;
        }

        .page-subtitle {
            font-size: 0.85rem;
            color: #999;
            margin-top: 4px;
        }

        /* CARD */
        .card {
            border: none;
            border-radius: 16px;
            background: var(--ez-card-bg);
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
        }

        /* BUTTON */
        .btn-danger {
            background: var(--ez-danger);
            border: none;
            border-radius: 10px;
            color: white;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-danger:hover {
            background: #c82333;
            color: white;
        }

        .btn-outline-secondary {
            border: 1px solid #6c757d;
            border-radius: 10px;
            color: #6c757d;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-outline-secondary:hover {
            background: #6c757d;
            color: white;
        }

        /* Breadcrumb */
        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 20px;
        }

        .breadcrumb-item a {
            text-decoration: none;
            color: #888;
        }

        .breadcrumb-item.active {
            color: var(--ez-orange);
            font-weight: 500;
        }

        /* Warning Alert */
        .alert-warning-custom {
            background: linear-gradient(135deg, #ffecb5 0%, #ffcdb5 100%);
            border: 1px solid #ffc107;
            border-radius: 12px;
        }

        /* Info Box */
        .info-box {
            background: #f8f9fa;
            border-radius: 10px;
            padding: 20px;
            border-left: 4px solid var(--ez-danger);
        }

        /* Danger Icon */
        .danger-icon {
            width: 80px;
            height: 80px;
            background: rgba(220, 53, 69, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
        }

        .danger-icon i {
            font-size: 40px;
            color: var(--ez-danger);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 70px;">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="list.php">Danh mục</a></li>
                        <li class="breadcrumb-item active">Xóa danh mục</li>
                    </ol>
                </nav>

                <!-- Page Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="page-title mb-0">
                            <i class="bi bi-exclamation-triangle text-danger me-2"></i>Xóa danh mục
                        </h1>
                        <p class="page-subtitle">Xác nhận xóa danh mục khỏi hệ thống</p>
                    </div>
                    <div class="btn-group" role="group">
                        <a href="list.php" class="btn btn-outline-secondary">
                            <i class="bi bi-arrow-left me-2"></i>Quay lại
                        </a>
                    </div>
                </div>

                <!-- Warning Alert -->
                <?php if($product_count > 0 || $children_count > 0): ?>
                <div class="alert alert-warning-custom mb-4">
                    <div class="d-flex">
                        <div class="me-3">
                            <i class="bi bi-exclamation-triangle-fill fs-3 text-warning"></i>
                        </div>
                        <div>
                            <h5 class="alert-heading">Không thể xóa danh mục!</h5>
                            <p class="mb-1">Danh mục "<strong><?php echo htmlspecialchars($category['name']); ?></strong>" không thể xóa vì:</p>
                            <ul class="mb-0">
                                <?php if($product_count > 0): ?>
                                <li>Có <span class="badge bg-danger"><?php echo $product_count; ?></span> sản phẩm thuộc danh mục này</li>
                                <?php endif; ?>
                                <?php if($children_count > 0): ?>
                                <li>Có <span class="badge bg-danger"><?php echo $children_count; ?></span> danh mục con thuộc danh mục này</li>
                                <?php endif; ?>
                            </ul>
                            <hr>
                            <p class="mb-0"><strong>Giải pháp:</strong> 
                                <?php if($product_count > 0): ?>
                                Di chuyển hoặc xóa tất cả sản phẩm trước.
                                <?php endif; ?>
                                <?php if($children_count > 0): ?>
                                Xóa hoặc chuyển tất cả danh mục con trước.
                                <?php endif; ?>
                            </p>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <!-- Delete Confirmation -->
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-body text-center">
                                <!-- Danger Icon -->
                                <div class="danger-icon">
                                    <i class="bi bi-trash"></i>
                                </div>
                                
                                <h3 class="text-danger mb-3">Bạn có chắc chắn muốn xóa?</h3>
                                
                                <div class="info-box mb-4">
                                    <h5 class="text-dark mb-2">Thông tin danh mục sẽ bị xóa:</h5>
                                    <div class="row text-start">
                                        <div class="col-md-6 mb-2">
                                            <span class="text-muted">ID:</span>
                                            <strong>#<?php echo $category['id']; ?></strong>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <span class="text-muted">Tên danh mục:</span>
                                            <strong><?php echo htmlspecialchars($category['name']); ?></strong>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <span class="text-muted">Slug:</span>
                                            <code><?php echo $category['slug']; ?></code>
                                        </div>
                                        <div class="col-md-6 mb-2">
                                            <span class="text-muted">Danh mục cha:</span>
                                            <span>
                                                <?php 
                                                if($category['parent_id']) {
                                                    $parentQuery = mysqli_query($conn, "SELECT name FROM categories WHERE id = {$category['parent_id']}");
                                                    $parentRow = mysqli_fetch_assoc($parentQuery);
                                                    echo htmlspecialchars($parentRow['name'] ?? 'Không xác định');
                                                } else {
                                                    echo 'Danh mục gốc';
                                                }
                                                ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="alert alert-warning border-warning">
                                    <h6 class="alert-heading">
                                        <i class="bi bi-exclamation-octagon-fill me-2"></i>Cảnh báo quan trọng
                                    </h6>
                                    <ul class="mb-0">
                                        <li>Hành động này <strong>không thể hoàn tác</strong></li>
                                        <li>Toàn bộ thông tin về danh mục sẽ bị xóa vĩnh viễn</li>
                                        <li>Đường dẫn (URL) liên quan đến danh mục sẽ không còn hoạt động</li>
                                    </ul>
                                </div>
                                
                                <!-- Action Buttons -->
                                <div class="d-flex justify-content-center gap-3 mt-4">
                                    <a href="list.php" class="btn btn-outline-secondary">
                                        <i class="bi bi-x-circle me-2"></i>Hủy bỏ
                                    </a>
                                    <a href="delete.php?id=<?php echo $id; ?>&confirm=yes" 
                                       class="btn btn-danger"
                                       onclick="showDeletingMessage()">
                                        <i class="bi bi-trash me-2"></i>Xác nhận xóa
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                
                <!-- Quick Actions -->
                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-body">
                                <h6 class="card-title mb-3">
                                    <i class="bi bi-lightning me-2"></i>Thao tác nhanh
                                </h6>
                                <div class="d-flex flex-wrap gap-2">
                                    <a href="edit.php?id=<?php echo $id; ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="bi bi-pencil me-1"></i>Sửa danh mục
                                    </a>
                                    <a href="list.php" class="btn btn-outline-secondary btn-sm">
                                        <i class="bi bi-list-ul me-1"></i>Xem danh sách
                                    </a>
                                    <a href="../products/?category=<?php echo $id; ?>" class="btn btn-outline-info btn-sm">
                                        <i class="bi bi-box me-1"></i>Xem sản phẩm
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set active menu
            const categoriesLink = document.querySelector('a[href*="categories"]');
            if (categoriesLink) {
                categoriesLink.classList.add('active');
            }
        });

        function showDeletingMessage() {
            // Tạo overlay loading
            const overlay = document.createElement('div');
            overlay.style.position = 'fixed';
            overlay.style.top = '0';
            overlay.style.left = '0';
            overlay.style.width = '100%';
            overlay.style.height = '100%';
            overlay.style.backgroundColor = 'rgba(0,0,0,0.5)';
            overlay.style.zIndex = '9999';
            overlay.style.display = 'flex';
            overlay.style.justifyContent = 'center';
            overlay.style.alignItems = 'center';
            
            // Tạo modal message
            const modal = document.createElement('div');
            modal.style.backgroundColor = 'white';
            modal.style.padding = '30px';
            modal.style.borderRadius = '12px';
            modal.style.boxShadow = '0 4px 20px rgba(0,0,0,0.2)';
            modal.style.textAlign = 'center';
            modal.style.maxWidth = '400px';
            modal.style.width = '90%';
            
            modal.innerHTML = `
                <div class="spinner-border text-danger mb-3" role="status">
                    <span class="visually-hidden">Loading...</span>
                </div>
                <h5 class="text-danger mb-2">Đang xóa danh mục...</h5>
                <p class="text-muted">Vui lòng đợi trong giây lát.</p>
            `;
            
            overlay.appendChild(modal);
            document.body.appendChild(overlay);
            
            // Tự động xóa sau 3 giây (trong trường hợp chuyển hướng bị lỗi)
            setTimeout(() => {
                if (document.body.contains(overlay)) {
                    document.body.removeChild(overlay);
                }
            }, 3000);
        }
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?> 
