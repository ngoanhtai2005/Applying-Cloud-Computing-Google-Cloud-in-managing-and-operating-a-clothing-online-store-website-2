<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

/* SEARCH */
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$where = "WHERE 1=1";

if ($search) {
    $where .= " AND (p.name LIKE '%$search%' OR u.name LIKE '%$search%')";
}

$sql = "
SELECT r.*, p.name AS product_name, u.name AS user_name
FROM reviews r
JOIN products p ON r.product_id = p.id
JOIN users u ON r.user_id = u.id
$where
ORDER BY r.created_at DESC
";

$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý đánh giá</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">
<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">
            <i class="bi bi-star-fill text-warning"></i> Quản lý đánh giá
        </h1>
        <p class="page-subtitle">Danh sách đánh giá sản phẩm</p>
    </div>
    <a href="add.php" class="btn btn-warning text-white">
        <i class="bi bi-plus-circle"></i> Thêm đánh giá
    </a>
</div>

<!-- SEARCH -->
<div class="card mb-4">
    <div class="card-body">
        <form class="row g-2">
            <div class="col-md-4">
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>"
                       class="form-control" placeholder="Tìm theo sản phẩm / người dùng">
            </div>
            <div class="col-md-auto">
                <button class="btn btn-outline-warning">
                    <i class="bi bi-search"></i>
                </button>
                <?php if($search): ?>
                    <a href="index.php" class="btn btn-outline-secondary ms-2">
                        <i class="bi bi-x-circle"></i>
                    </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<div class="card">
<div class="card-body table-responsive">
<table class="table table-hover align-middle">
<thead>
<tr>
    <th>ID</th>
    <th>Sản phẩm</th>
    <th>Người dùng</th>
    <th>Rating</th>
    <th>Bình luận</th>
    <th>Ngày</th>
    <th width="140">Hành động</th>
</tr>
</thead>
<tbody>
<?php if ($result->num_rows > 0): ?>
<?php while ($row = mysqli_fetch_assoc($result)): ?>
<tr>
    <td>#<?= $row['id'] ?></td>
    <td><?= htmlspecialchars($row['product_name']) ?></td>
    <td><?= htmlspecialchars($row['user_name']) ?></td>
    <td>
        <?php for($i=1;$i<=5;$i++): ?>
            <i class="bi bi-star<?= $i <= $row['rating'] ? '-fill text-warning' : '' ?>"></i>
        <?php endfor; ?>
    </td>
    <td><?= htmlspecialchars($row['comment']) ?></td>
    <td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>
    <td>
        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-warning">
            <i class="bi bi-pencil"></i>
        </a>
        <a href="delete.php?id=<?= $row['id'] ?>" 
           onclick="return confirm('Xóa đánh giá này?')"
           class="btn btn-sm btn-outline-danger">
            <i class="bi bi-trash"></i>
        </a>
    </td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
    <td colspan="7" class="text-center text-muted py-4">
        Không có đánh giá nào
    </td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
