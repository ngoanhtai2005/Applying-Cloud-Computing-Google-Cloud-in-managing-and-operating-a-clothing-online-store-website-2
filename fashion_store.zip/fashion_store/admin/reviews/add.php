<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
$products = mysqli_query($conn, "SELECT id, name FROM products");
$users = mysqli_query($conn, "SELECT id, name FROM users");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = $_POST['product_id'];
    $user_id = $_POST['user_id'];
    $rating = $_POST['rating'];
    $comment = $_POST['comment'];

    mysqli_query($conn, "
        INSERT INTO reviews (product_id, user_id, rating, comment)
        VALUES ($product_id, $user_id, $rating, '$comment')
    ");

    $_SESSION['success_message'] = "Thêm đánh giá thành công!";
    header("Location: list.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thêm đánh giá</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #fff;
}

body {
    background: var(--ez-bg);
}

.card {
    border: none;
    border-radius: 16px;
    background: var(--ez-card-bg);
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
}

.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}

.page-subtitle {
    font-size: .85rem;
    color: #888;
}
</style>
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="page-title">
                <i class="bi bi-star-fill text-warning me-1"></i> Thêm đánh giá
            </h1>
            <p class="page-subtitle">Tạo đánh giá mới cho sản phẩm</p>
        </div>
        <a href="index.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Quay lại
        </a>
    </div>

    <!-- FORM -->
    <div class="card">
        <div class="card-body">

            <form method="post" class="row g-3">

                <div class="col-md-6">
                    <label class="form-label">Sản phẩm</label>
                    <select name="product_id" class="form-select" required>
                        <option value="">-- Chọn sản phẩm --</option>
                        <?php while ($p = mysqli_fetch_assoc($products)): ?>
                            <option value="<?= $p['id'] ?>">
                                <?= htmlspecialchars($p['name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="col-md-6">
                    <label class="form-label">Người dùng</label>
                    <select name="user_id" class="form-select" required>
                        <option value="">-- Chọn người dùng --</option>
                        <?php while ($u = mysqli_fetch_assoc($users)): ?>
                            <option value="<?= $u['id'] ?>">
                                <?= htmlspecialchars($u['name']) ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <div class="col-md-4">
                    <label class="form-label">Số sao</label>
                    <select name="rating" class="form-select">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <option value="<?= $i ?>"><?= $i ?> sao</option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-12">
                    <label class="form-label">Nội dung đánh giá</label>
                    <textarea name="comment" rows="4" class="form-control" placeholder="Nhập nội dung đánh giá..."></textarea>
                </div>

                <div class="col-12 text-end mt-3">
                    <button class="btn btn-warning text-white px-4">
                        <i class="bi bi-save"></i> Lưu đánh giá
                    </button>
                    <a href="index.php" class="btn btn-secondary ms-2">
                        Hủy
                    </a>
                </div>

            </form>

        </div>
    </div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
