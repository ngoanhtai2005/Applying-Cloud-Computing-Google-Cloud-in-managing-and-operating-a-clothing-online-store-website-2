<?php
session_start();
if (!isset($_SESSION['admin_id'])) header("Location: ../login.php");

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
$id = intval($_GET['id']);
mysqli_query($conn, "DELETE FROM reviews WHERE id=$id");

header("Location: list.php");
exit;
