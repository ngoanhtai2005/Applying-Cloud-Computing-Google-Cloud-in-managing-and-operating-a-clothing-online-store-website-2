<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

$id = intval($_GET['id'] ?? 0);
if ($id <= 0) {
    header("Location: list.php");
    exit;
}

// Lấy dữ liệu review
$review = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT * FROM reviews WHERE id = $id")
);

if (!$review) {
    header("Location: list.php");
    exit;
}

// Xử lý submit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $rating  = $_POST['rating'];
    $comment = $_POST['comment'];

    mysqli_query($conn, "
        UPDATE reviews 
        SET rating = $rating,
            comment = '$comment'
        WHERE id = $id
    ");

    $_SESSION['success_message'] = "Cập nhật đánh giá thành công!";
    header("Location: list.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chỉnh sửa đánh giá</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #fff;
}

body {
    background: var(--ez-bg);
}

.card {
    border: none;
    border-radius: 16px;
    background: var(--ez-card-bg);
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
}

.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}

.page-subtitle {
    font-size: .85rem;
    color: #888;
}
</style>
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">

<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h1 class="page-title">
                <i class="bi bi-pencil-square text-warning me-1"></i> Chỉnh sửa đánh giá
            </h1>
            <p class="page-subtitle">Cập nhật nội dung đánh giá</p>
        </div>
        <a href="list.php" class="btn btn-outline-secondary">
            <i class="bi bi-arrow-left"></i> Quay lại
        </a>
    </div>

    <!-- FORM -->
    <div class="card">
        <div class="card-body">

            <form method="post" class="row g-3">

                <div class="col-md-4">
                    <label class="form-label">Số sao</label>
                    <select name="rating" class="form-select">
                        <?php for ($i = 1; $i <= 5; $i++): ?>
                            <option value="<?= $i ?>" <?= $review['rating'] == $i ? 'selected' : '' ?>>
                                <?= $i ?> sao
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>

                <div class="col-12">
                    <label class="form-label">Nội dung đánh giá</label>
                    <textarea name="comment" rows="4" class="form-control"><?= htmlspecialchars($review['comment']) ?></textarea>
                </div>

                <div class="col-12 text-end mt-3">
                    <button class="btn btn-warning text-white px-4">
                        <i class="bi bi-save"></i> Cập nhật
                    </button>
                    <a href="list.php" class="btn btn-secondary ms-2">
                        Hủy
                    </a>
                </div>

            </form>

        </div>
    </div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
