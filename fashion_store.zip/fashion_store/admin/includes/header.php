<?php
// KHỞI TẠO SESSION
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra login admin
if (empty($_SESSION['admin_id']) || empty($_SESSION['admin_username']) || empty($_SESSION['admin_role'])) {
    header('Location: login.php');
    exit;
}

// Lấy thông tin admin
$adminName = $_SESSION['admin_name'] ?? $_SESSION['admin_username'];
$adminRole = $_SESSION['admin_role'];
?>
<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #FFFFFF;
    --ez-text: #333;
}

body {
    background: var(--ez-bg);
    font-family: 'Inter', sans-serif;
}

/* đảm bảo nội dung không đè header */
.admin-wrapper {
    padding-top: 90px;
}

/* ===== SIDEBAR ===== */
.sidebar {
    position: fixed;
    top: 90px;
    left: 0;
    width: 240px;
    height: calc(100vh - 90px);
    background: #fff;
    border-right: 1px solid #eee;
}

.sidebar a {
    padding: 12px 20px;
    display: flex;
    align-items: center;
    color: #555;
    text-decoration: none;
    font-weight: 500;
}

.sidebar a i {
    margin-right: 10px;
}

.sidebar a.active,
.sidebar a:hover {
    background: rgba(255,138,0,0.1);
    color: var(--ez-orange);
}

/* ===== MAIN CONTENT ===== */
.main-content {
    margin-left: 240px;
    padding: 24px;
}

/* ===== CARD ===== */
.card {
    border: none;
    border-radius: 16px;
    background: var(--ez-card-bg);
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
    transition: .3s;
}

.card:hover {
    transform: translateY(-3px);
}

.stat-value {
    font-size: 1.8rem;
    font-weight: 700;
    color: var(--ez-orange);
}

.stat-label {
    font-size: .75rem;
    text-transform: uppercase;
    color: #888;
    letter-spacing: 1px;
}

/* TABLE */
.table th {
    font-size: .8rem;
    color: #888;
}

.table td {
    vertical-align: middle;
}

/* BUTTON */
.btn-primary {
    background: var(--ez-orange);
    border: none;
    border-radius: 10px;
}

.btn-primary:hover {
    background: #e67e00;
}

/* MOBILE */
@media(max-width: 991px) {
    .sidebar {
        display: none;
    }
    .main-content {
        margin-left: 0;
    }
}
/* ===== HEADER ===== */
.navbar {
    height: 90px;
    background: #fff;
    border-bottom: 1px solid #eee;
    z-index: 1030;
}

.navbar-brand {
    font-weight: 700;
    letter-spacing: .5px;
    color: #222;
}

.brand-dot {
    color: var(--ez-orange);
}

/* SEARCH */
.header-search-container {
    max-width: 520px;
    margin: 0 auto;
    position: relative;
}

.header-search-container input {
    border-radius: 12px;
    padding-left: 42px;
    height: 44px;
    border: 1px solid #eee;
}

.search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #aaa;
}

/* AVATAR */
.avatar-ez {
    width: 38px;
    height: 38px;
    border-radius: 50%;
    background: var(--ez-orange);
    font-size: .9rem;
}

/* DROPDOWN */
.dropdown-menu-ez {
    border-radius: 12px;
    min-width: 220px;
}

.dropdown-menu-ez .dropdown-item {
    font-size: .9rem;
    padding: 10px 16px;
}

/* MOBILE */
@media (max-width: 767px) {
    .header-search-container {
        display: none;
    }
}
/* ===== PAGE HEADER (Dashboard title) ===== */
.page-header {
    margin-bottom: 24px;
}

.page-title {
    font-size: 1.6rem;
    font-weight: 700;
    color: #222;
}

.page-subtitle {
    font-size: 0.85rem;
    color: #999;
    margin-top: 4px;
}

</style>
<div class="main-content admin-wrapper">

    <!-- PAGE HEADER -->
    <div class="page-header">
        <h1 class="page-title">Dashboard</h1>
        <div class="page-subtitle">
            Overview & statistics
        </div>
    </div>

    <!-- SUMMARY CARDS -->
    <div class="row g-4 mb-4">
        <!-- card here -->
    </div>

    <!-- charts, tables, etc -->
</div>
<nav class="navbar navbar-light fixed-top navbar-ezmart flex-md-nowrap p-0 shadow-sm">
    <a class="navbar-brand navbar-brand-ez col-md-3 col-lg-2 me-0 px-4" href="/fashion_store/admin/index.php">
        <i class="bi bi-grid-fill me-2" style="color: #FF8A00;"></i>
        FASHION ADMIN<span class="brand-dot">.</span>
    </a>
    
    <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" 
            data-bs-toggle="collapse" data-bs-target="#sidebarMenu">
        <span class="navbar-toggler-icon"></span>
    </button>
    
    <div class="w-100 d-none d-md-flex justify-content-start ps-4 search-container">
        <form class="w-100">
            <div class="position-relative">
                <i class="bi bi-search position-absolute top-50 start-0 translate-middle-y ms-3 text-muted"></i>
                <input type="text" class="form-control ps-5" 
                       placeholder="Search stock, orders, customers...">
            </div>
        </form>
    </div>
    
    <div class="dropdown px-4">
        <a href="#" class="d-flex align-items-center text-decoration-none dropdown-toggle admin-profile" 
           data-bs-toggle="dropdown">
            <div class="avatar-ez d-flex align-items-center justify-content-center me-2 text-white shadow-sm">
                <span class="fw-bold"><?php echo strtoupper(substr($adminName, 0, 1)); ?></span>
            </div>
            <div class="d-none d-lg-block">
                <div class="fw-bold mb-0" style="line-height: 1; font-size: 0.9rem;"><?php echo htmlspecialchars($adminName); ?></div>
                <small class="text-muted" style="font-size: 0.75rem;"><?php echo ucfirst(str_replace('_', ' ', $adminRole)); ?></small>
            </div>
        </a>
        
        <ul class="dropdown-menu dropdown-menu-end dropdown-menu-ez shadow">
            <li class="px-3 py-2 border-bottom mb-2 d-lg-none">
                <span class="fw-bold d-block"><?php echo htmlspecialchars($adminName); ?></span>
                <small class="text-muted"><?php echo $adminRole; ?></small>
            </li>
            <li>
                <a class="dropdown-item" href="/fashion_store/index.php" target="_blank">
                    <i class="bi bi-shop me-2"></i> View Store
                </a>
            </li>
            <li>
                <a class="dropdown-item" href="profile.php">
                    <i class="bi bi-person me-2"></i> My Profile
                </a>
            </li>
            <li><hr class="dropdown-divider"></li>
            <li>
                <a class="dropdown-item text-danger" href="logout.php">
                    <i class="bi bi-box-arrow-right me-2"></i> Sign out
                </a>
            </li>
        </ul>
    </div>
</nav>
