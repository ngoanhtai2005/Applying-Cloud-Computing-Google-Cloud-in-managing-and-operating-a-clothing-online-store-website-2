<?php
// sidebar.php
if (!function_exists('isActive')) {
    function isActive($name) {
        return strpos($_SERVER['REQUEST_URI'], $name) !== false ? 'active' : '';
    }
}
?>
<style>
/* Sidebar chính */
#sidebarMenu {
    width: 260px;
    height: 100vh;
    position: fixed;
    top: 0;
    left: 0;
    background-color: #ffffff;
    border-right: 1px solid #f0f2f5;
    z-index: 1000;
    padding-top: 75px;
    overflow-y: auto;
    transition: all 0.3s ease;
}

/* Header avatar */
.sidebar-header-ez {
    padding: 25px 20px;
    background: #F9F7F5;
    margin: 15px;
    border-radius: 15px;
}

/* Menu items */
.nav-link {
    color: #666;
    font-weight: 500;
    padding: 12px 20px;
    margin: 4px 15px;
    border-radius: 10px;
    transition: 0.3s;
    display: flex;
    align-items: center;
    text-decoration: none;
}

.nav-link i {
    font-size: 1.1rem;
    margin-right: 12px;
    color: #999;
    width: 20px;
    text-align: center;
}

.nav-link:hover {
    background-color: rgba(255, 138, 0, 0.05);
    color: #FF8A00;
}

.nav-link:hover i {
    color: #FF8A00;
}

.nav-link.active {
    background-color: #FF8A00;
    color: #ffffff;
    box-shadow: 0 4px 12px rgba(255, 138, 0, 0.3);
}

.nav-link.active i {
    color: #ffffff;
}

.sidebar-heading {
    font-size: 0.75rem;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: #bbb;
    padding: 10px 30px;
    font-weight: 700;
    margin-top: 10px;
}

.badge-ez {
    background-color: #FF8A00;
    color: white;
    font-size: 0.7rem;
    padding: 4px 8px;
    border-radius: 10px;
}

.nav .collapse .nav-link {
    padding: 8px 20px;
    margin: 2px 15px;
}

.system-status-card {
    background-color: #f8f9fa;
    border-radius: 10px;
    padding: 15px;
    margin: 15px;
}
</style>

<nav id="sidebarMenu" class="d-md-block sidebar">
    <div class="position-sticky pt-3 d-flex flex-column h-100">
        <!-- Header -->
        <div class="sidebar-header-ez">
            <div class="d-flex align-items-center">
                <div class="avatar shadow-sm rounded-3 d-flex align-items-center justify-content-center me-3"
                     style="width: 45px; height: 45px; background: #FF8A00; color: white;">
                    <i class="bi bi-person-fill fs-5"></i>
                </div>
                <div class="overflow-hidden">
                    <h6 class="mb-0 fw-bold text-dark text-truncate"><?php echo htmlspecialchars($_SESSION['admin_name'] ?? 'Admin'); ?></h6>
                    <small class="text-muted" style="font-size: 0.7rem;"></small>
                </div>
            </div>
        </div>

        <!-- Menu chính -->
        <ul class="nav flex-column mt-2">
            <li class="nav-item">
                <a class="nav-link <?php echo isActive('index.php'); ?>" href="/fashion_store/admin/index.php">
                    <i class="bi bi-grid"></i> Dashboard
                </a>
            </li>

            <div class="sidebar-heading">Management</div>

            <li class="nav-item">
                <a class="nav-link <?php echo isActive('categories'); ?>" href="/fashion_store/admin/categories/list.php">
                    <i class="bi bi-tags"></i> Categories
                </a>
            </li>

<li class="nav-item">
    <a class="nav-link <?php echo isActive('products'); ?>"
       href="/fashion_store/admin/products/list.php">
        <i class="bi bi-box-seam"></i>
        <span class="flex-grow-1">Products</span>
    </a>
</li>

            <li class="nav-item">
                <a class="nav-link <?php echo isActive('orders'); ?>" href="/fashion_store/admin/orders/list.php">
                    <i class="bi bi-cart3"></i> Orders              
                        <span class="badge rounded-pill badge-ez"></span>          
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo isActive('users') || isActive('customers'); ?>" href="/fashion_store/admin/users/list.php">
                    <i class="bi bi-people"></i> Users
                </a>
            </li>

            <li class="nav-item">
                <a class="nav-link <?php echo isActive('reviews'); ?>" href="/fashion_store/admin/reviews/list.php">
                    <i class="bi bi-star"></i> Reviews
                </a>
            </li>
<?php if (isset($_SESSION['admin_role']) && $_SESSION['admin_role'] === 'super_admin'): ?>
<li class="nav-item">
    <a class="nav-link <?php echo isActive('admins'); ?>" href="/fashion_store/admin/admin_users/list.php">
        <i class="bi bi-shield-lock"></i>
        Admin Users
    </a>
</li>
<?php endif; ?>

            <div class="sidebar-heading">System</div>

            <li class="nav-item">
                <a class="nav-link <?php echo isActive('settings'); ?>" href="/fashion_store/admin/settings/">
                    <i class="bi bi-sliders"></i> Settings
                </a>
            </li>

            
        </ul>

        <!-- System status -->
        <div class="mt-auto p-4">
            <div class="system-status-card">
                <div class="d-flex align-items-center mb-2">
                    <div class="spinner-grow spinner-grow-sm text-success me-2" role="status"></div>
                    <small class="fw-bold">System Online</small>
                </div>
                <div class="progress" style="height: 4px;">
                    <div class="progress-bar bg-warning" style="width: 40%"></div>
                </div>
                <small class="text-muted mt-2 d-block" style="font-size: 0.65rem;">CPU Usage: 40%</small>
                <small class="text-muted" style="font-size: 0.65rem;">Memory: 65%</small>
            </div>
        </div>
    </div>
</nav>





























