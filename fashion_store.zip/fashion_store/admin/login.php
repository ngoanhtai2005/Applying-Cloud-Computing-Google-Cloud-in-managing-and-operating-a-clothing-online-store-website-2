<?php
session_start();

// Nếu đã đăng nhập thì chuyển hướng
if(isset($_SESSION['admin_id']) && isset($_SESSION['admin_username'])) {
    header('Location: index.php');
    exit;
}

// Kết nối cơ sở dữ liệu qua config
require_once(__DIR__ . '/../config/database.php');
$conn = getDBConnection();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $error = [];
    $username = '';
    $password = '';

    if(empty($_POST['username'])) {
        $error[] = 'username';
    } else {
        $username = trim($_POST['username']);
    }

    if(empty($_POST['password'])) {
        $error[] = 'password';
    } else {
        $password = $_POST['password'];
    }

    if(empty($error)) {
        $sql = "SELECT * FROM admin_users WHERE username = ? OR email = ? LIMIT 1";
        $stmt = mysqli_prepare($conn, $sql);
        if($stmt) {
            mysqli_stmt_bind_param($stmt, "ss", $username, $username);
            mysqli_stmt_execute($stmt);

            if(function_exists('mysqli_stmt_get_result')) {
                $result = mysqli_stmt_get_result($stmt);
                $row = mysqli_fetch_assoc($result);
            } else {
                mysqli_stmt_bind_result($stmt, $id, $db_username, $db_password, $full_name, $role, $status, $last_login, $created_at);
                $row = null;
                if(mysqli_stmt_fetch($stmt)) {
                    $row = [
                        'id' => $id,
                        'username' => $db_username,
                        'password' => $db_password,
                        'full_name' => $full_name,
                        'role' => $role,
                        'status' => $status,
                        'last_login' => $last_login,
                        'created_at' => $created_at
                    ];
                }
            }
            mysqli_stmt_close($stmt);

            if($row) {
                if($row['status'] !== 'active') {
                    echo '<script>alert("Tài khoản đã bị vô hiệu hóa!");</script>';
                } else {
                    $passwordOk = false;
                    if(password_verify($password, $row['password'])) {
                        $passwordOk = true;
                    } else {
                        if($password === $row['password'] || md5($password) === $row['password']) {
                            $passwordOk = true;
                            if(password_needs_rehash($row['password'], PASSWORD_DEFAULT)) {
                                $newHash = password_hash($password, PASSWORD_DEFAULT);
                                $updateStmt = mysqli_prepare($conn, "UPDATE admin_users SET password = ? WHERE id = ?");
                                mysqli_stmt_bind_param($updateStmt, "si", $newHash, $row['id']);
                                mysqli_stmt_execute($updateStmt);
                                mysqli_stmt_close($updateStmt);
                            }
                        }
                    }

                    if($passwordOk) {
                        $_SESSION['admin_id'] = $row['id'];
                        $_SESSION['admin_username'] = $row['username'];
                        $_SESSION['admin_role'] = $row['role'];
                        header('Location: index.php');
                        exit;
                    } else {
                        echo '<script>alert("Tài khoản hoặc mật khẩu không đúng. Vui lòng đăng nhập lại!");</script>';
                    }
                }
            } else {
                echo '<script>alert("Tài khoản hoặc mật khẩu không đúng. Vui lòng đăng nhập lại!");</script>';
            }
        }
    }
}

// Đóng kết nối
mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Đăng nhập Admin - Fashion Store</title>
    
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 0;
        }
        .login-card {
            background: white;
            border-radius: 20px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            width: 100%;
            max-width: 450px;
            overflow: hidden;
        }
        .login-header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 40px 30px;
            text-align: center;
        }
        .login-body {
            padding: 40px;
        }
        .form-control {
            border-radius: 10px;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            transition: all 0.3s;
        }
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
        }
        .btn-login {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            color: white;
            padding: 12px;
            border-radius: 10px;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-login:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
        }
    </style>
</head>
<body>
    <div class="login-card">
        <div class="login-header">
            <h2>Đăng nhập Admin</h2>
            <p class="mb-0">Quản trị Fashion Store</p>
        </div>
        
        <div class="login-body">
            <form action="" method="post" id="loginForm">
                <div class="mb-4">
                    <label class="form-label fw-bold">Tên đăng nhập hoặc Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-end-0">
                            <i class="bi bi-person text-muted"></i>
                        </span>
                        <input type="text" class="form-control border-start-0" 
                               name="username" placeholder="Nhập tài khoản . . ." required autofocus>
                    </div>
                </div>
                
                <div class="mb-4">
                    <label class="form-label fw-bold">Mật khẩu</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-end-0">
                            <i class="bi bi-lock text-muted"></i>
                        </span>
                        <input type="password" class="form-control border-start-0" 
                               name="password" placeholder="Nhập mật khẩu . . ." required id="password">
                        <button type="button" class="btn btn-outline-secondary border-start-0" 
                                onclick="togglePassword()">
                            <i class="bi bi-eye" id="toggleIcon"></i>
                        </button>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-login w-100">
                    Đăng nhập
                </button>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const toggleIcon = document.getElementById('toggleIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.classList.remove('bi-eye');
                toggleIcon.classList.add('bi-eye-slash');
            } else {
                passwordInput.type = 'password';
                toggleIcon.classList.remove('bi-eye-slash');
                toggleIcon.classList.add('bi-eye');
            }
        }
    </script>
</body>
</html>

