<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

$conn = mysqli_connect("localhost", "root", "", "fashion_store");
if (!$conn) die("DB Error");

$id = (int)($_GET['id'] ?? 0);

// Lấy đơn hàng
$orderQuery = mysqli_query($conn, "
    SELECT o.*, u.name, u.email
    FROM orders o
    JOIN users u ON o.user_id = u.id
    WHERE o.id = $id
");

$order = mysqli_fetch_assoc($orderQuery);

if (!$order) {
    die("<h3 style='color:red;padding:20px'>❌ Đơn hàng không tồn tại</h3>");
}

// Lấy sản phẩm
$items = mysqli_query($conn, "
    SELECT oi.*, p.name
    FROM order_items oi
    JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = $id
");

// Chuẩn hóa status
$status = strtolower(trim($order['status']));

// Map màu
$statusClass = match ($status) {
    'pending'    => 'bg-warning text-dark',
    'processing' => 'bg-info',
    'shipped'    => 'bg-primary',
    'delivered'  => 'bg-success',
    'cancelled'  => 'bg-danger',
    default      => 'bg-secondary'
};
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chi tiết đơn hàng</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>
<?php include "../includes/header.php"; ?>

<div class="container-fluid">
<div class="row">
<?php include "../includes/sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- HEADER -->
<div class="d-flex justify-content-between mb-4">
    <div>
        <h4><i class="bi bi-receipt"></i> Đơn hàng #<?= $order['id'] ?></h4>
        <p class="text-muted">Chi tiết đơn hàng</p>
    </div>
    <a href="list.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Quay lại
    </a>
</div>

<!-- INFO -->
<div class="card mb-4">
    <div class="card-body row g-3">
        <div class="col-md-4">
            <strong>Khách hàng:</strong><br>
            <?= htmlspecialchars($order['name']) ?>
        </div>
        <div class="col-md-4">
            <strong>Email:</strong><br>
            <?= htmlspecialchars($order['email']) ?>
        </div>
        <div class="col-md-4">
            <strong>Trạng thái:</strong><br>
            <span class="badge <?= $statusClass ?>">
                <?= ucfirst($status) ?>
            </span>
        </div>
    </div>
</div>

<!-- UPDATE STATUS -->
<div class="card mb-4">
    <div class="card-body">
        <form method="post" action="update_status.php" class="row g-3">
            <input type="hidden" name="order_id" value="<?= $order['id'] ?>">

            <div class="col-md-4">
                <label class="form-label fw-bold">Cập nhật trạng thái</label>
                <select name="status" class="form-select">
                    <option value="pending" <?= $status=='pending'?'selected':'' ?>>Pending</option>
                    <option value="processing" <?= $status=='processing'?'selected':'' ?>>Processing</option>
                    <option value="shipped" <?= $status=='shipped'?'selected':'' ?>>Shipped</option>
                    <option value="delivered" <?= $status=='delivered'?'selected':'' ?>>Delivered</option>
                    <option value="cancelled" <?= $status=='cancelled'?'selected':'' ?>>Cancelled</option>
                </select>
            </div>

            <div class="col-md-3 d-flex align-items-end">
                <button class="btn btn-warning">
                    <i class="bi bi-arrow-repeat"></i> Cập nhật
                </button>
            </div>
        </form>
    </div>
</div>

<!-- PRODUCTS -->
<div class="card">
    <div class="card-body">
        <h6><i class="bi bi-box-seam"></i> Sản phẩm</h6>

        <table class="table table-hover">
            <thead>
                <tr>
                    <th>Tên</th>
                    <th>Size</th>
                    <th>Màu</th>
                    <th>SL</th>
                    <th>Giá</th>
                </tr>
            </thead>
            <tbody>
            <?php while ($row = mysqli_fetch_assoc($items)): ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= $row['size'] ?></td>
                    <td><?= $row['color'] ?></td>
                    <td><?= $row['quantity'] ?></td>
                    <td><?= number_format($row['price'], 0, ',', '.') ?> đ</td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</main>
</div>
</div>

</body>
</html>
