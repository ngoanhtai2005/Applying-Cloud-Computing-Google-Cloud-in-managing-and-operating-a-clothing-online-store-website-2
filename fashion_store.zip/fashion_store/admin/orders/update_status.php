<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

$conn = mysqli_connect("localhost", "root", "", "fashion_store");
if (!$conn) die("DB error");

$order_id = (int)$_POST['order_id'];
$status = $_POST['status'];

$allowed = ['pending','processing','shipped','delivered','cancelled'];
if (!in_array($status, $allowed)) {
    die("Trạng thái không hợp lệ");
}

mysqli_query($conn, "
    UPDATE orders 
    SET status = '$status'
    WHERE id = $order_id
");

header("Location: view.php?id=" . $order_id);
exit;
