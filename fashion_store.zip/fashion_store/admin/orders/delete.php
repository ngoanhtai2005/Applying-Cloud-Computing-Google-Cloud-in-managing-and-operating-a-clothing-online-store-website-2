<?php
session_start();
$conn = mysqli_connect("localhost", "root", "", "fashion_store");

$id = (int)($_GET['id'] ?? 0);

mysqli_query($conn, "DELETE FROM orders WHERE id = $id");

header("Location: list.php");
exit;
