
<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();



if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$configPath = realpath(__DIR__ . '/../../config/database.php');
if (!$configPath) {
    die("Không tìm thấy file database.php");
}
require_once $configPath;

$conn = getDBConnection();

// Cập nhật trạng thái
$msg = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $new_status = mysqli_real_escape_string($conn, $_POST['status']);

    if (mysqli_query($conn, "UPDATE orders SET status='$new_status' WHERE id=$order_id")) {
        $msg = "<div class='alert alert-success alert-dismissible fade show'>
                    Cập nhật trạng thái đơn #$order_id thành công
                    <button class='btn-close' data-bs-dismiss='alert'></button>
                </div>";
    }
}

$sql = "SELECT o.*, u.id as user_id, u.name as user_name, u.email as user_email
        FROM orders o
        LEFT JOIN users u ON o.user_id = u.id
        ORDER BY o.created_at DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý Đơn hàng</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange:#FF8A00;
    --ez-bg:#F9F7F5;
}
body {
    background: var(--ez-bg);
    font-family: Inter, sans-serif;
}
.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}
.page-subtitle {
    font-size: .85rem;
    color: #999;
}
.card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,.03);
}
.table th {
    font-size: .8rem;
    color: #888;
    background: #f9fafb;
    padding: 16px;
}
.table td {
    padding: 16px;
    vertical-align: middle;
}
.table-hover tbody tr:hover {
    background: rgba(255,138,0,.04);
}
.badge-soft {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: .75rem;
    border: 1px solid #ddd;
}
.select-status {
    border-radius: 10px;
    padding: 6px 10px;
}
</style>
</head>

<body>
<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">
<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- HEADER -->
<div class="mb-4">
    <h1 class="page-title mb-1">
        <i class="bi bi-cart-check-fill text-success me-2"></i>Quản lý Đơn hàng
    </h1>
    <p class="page-subtitle">Theo dõi và xử lý đơn hàng của khách</p>
</div>

<?= $msg ?>

<!-- TABLE -->
<div class="card">
<div class="card-body table-responsive">
<table class="table table-hover align-middle">
<thead>
<tr>
    <th>Mã đơn</th>
    <th>Khách hàng</th>
    <th>Tổng tiền</th>
    <th>Thanh toán</th>
    <th style="min-width:170px">Trạng thái</th>
    <th>Ngày đặt</th>
    <th class="text-end">Hành động</th>
</tr>
</thead>
<tbody>

<?php if(mysqli_num_rows($result)): ?>
<?php while($row = mysqli_fetch_assoc($result)): ?>

<?php
$txt = 'text-dark fw-normal';
if ($row['status']=='completed') $txt='text-success fw-bold';
elseif ($row['status']=='cancelled') $txt='text-danger fw-bold';
elseif ($row['status']=='shipped') $txt='text-primary fw-bold';
?>

<tr>
<td class="fw-bold">#<?= htmlspecialchars($row['order_number']) ?></td>

<td>
    <strong><?= htmlspecialchars($row['shipping_name'] ?: $row['user_name']) ?></strong><br>
    <small class="text-muted"><?= htmlspecialchars($row['shipping_phone'] ?: $row['user_email']) ?></small>
</td>

<td class="fw-bold text-danger">
    <?= number_format($row['total_amount'],0,',','.') ?> đ
</td>

<td>
    <span class="badge-soft text-dark">
        <?= strtoupper($row['payment_method']) ?>
    </span>
</td>

<td>
<form method="POST">
<input type="hidden" name="order_id" value="<?= $row['id'] ?>">
<input type="hidden" name="update_status" value="1">

<select name="status"
        class="form-select form-select-sm select-status <?= $txt ?>"
        onchange="this.form.submit()">

<option value="pending" <?= $row['status']=='pending'?'selected':'' ?>>Chờ xử lý</option>
<option value="shipped" <?= $row['status']=='shipped'?'selected':'' ?>>Đang giao</option>
<option value="completed" <?= $row['status']=='completed'?'selected':'' ?>>Hoàn thành</option>
<option value="cancelled" <?= $row['status']=='cancelled'?'selected':'' ?>>Đã hủy</option>
<option value="completed">Completed</option>
</select>
</form>
</td>

<td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>

<td class="text-end">
<a href="view.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-secondary">
<i class="bi bi-eye"></i>
</a>
</td>
</tr>

<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="7" class="text-center py-5 text-muted">
<i class="bi bi-cart-x" style="font-size:48px;opacity:.3"></i>
<p class="mt-3">Chưa có đơn hàng nào</p>
</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
