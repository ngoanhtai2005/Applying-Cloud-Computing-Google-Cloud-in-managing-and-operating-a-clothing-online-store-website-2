<?php
session_start();

/* ===== CHECK LOGIN ===== */
if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

/* ===== DB ===== */
require_once __DIR__ . '/../config/db.php';

if (!isset($conn)) {
    die('Database connection not found');
}

$adminId = (int)$_SESSION['admin_id'];
$message = '';
$error   = '';

/* ===== GET ADMIN ===== */
$stmt = $conn->prepare(
    "SELECT username, name, email
     FROM admins
     WHERE id = ?"
);

if (!$stmt) {
    die('SQL error: ' . $conn->error);
}

$stmt->bind_param("i", $adminId);
$stmt->execute();
$result = $stmt->get_result();
$admin  = $result->fetch_assoc();

if (!$admin) {
    die('Admin not found');
}

/* ===== UPDATE ===== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name  = trim($_POST['name']);
    $email = trim($_POST['email']);

    $stmt = $conn->prepare(
        "UPDATE admins SET name = ?, email = ? WHERE id = ?"
    );

    if (!$stmt) {
        die('SQL error: ' . $conn->error);
    }

    $stmt->bind_param("ssi", $name, $email, $adminId);
    $stmt->execute();

    $_SESSION['admin_name'] = $name;
    $message = 'Profile updated successfully';
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Profile</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include __DIR__ . '/includes/header.php'; ?>
<?php include __DIR__ . '/includes/sidebar.php'; ?>

<div class="container" style="margin-left:260px;max-width:600px;padding-top:40px">

<h3>My Profile</h3>

<?php if ($message): ?>
    <div class="alert alert-success"><?= htmlspecialchars($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
<?php endif; ?>

<form method="POST" class="card p-4">

<div class="mb-3">
    <label>Username</label>
    <input class="form-control" disabled
           value="<?= htmlspecialchars($admin['username']) ?>">
</div>

<div class="mb-3">
    <label>Full name</label>
    <input class="form-control" name="name" required
           value="<?= htmlspecialchars($admin['name']) ?>">
</div>

<div class="mb-3">
    <label>Email</label>
    <input class="form-control" name="email" type="email" required
           value="<?= htmlspecialchars($admin['email']) ?>">
</div>

<button class="btn btn-primary">Save</button>

</form>
</div>

</body>
</html>
