<?php
// Bật báo lỗi để debug
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Kết nối database
require_once(__DIR__ . '/../config/database.php');

// Session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Kiểm tra đăng nhập
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$conn = getDBConnection();

// Tìm kiếm
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$where = "";

if ($search) {
    $search = mysqli_real_escape_string($conn, $search);
    $where = "WHERE username LIKE '%$search%' OR email LIKE '%$search%'";
}

$sql = "SELECT * FROM admin_users $where ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
if (!$result) die(mysqli_error($conn));
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý Admin</title>
<meta name="viewport" content="width=device-width, initial-scale=1">

<!-- Bootstrap -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #FFFFFF;
}

body {
    background: var(--ez-bg);
    font-family: 'Inter', sans-serif;
}

.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}

.page-subtitle {
    font-size: .85rem;
    color: #999;
}

/* CARD */
.card {
    border: none;
    border-radius: 16px;
    background: var(--ez-card-bg);
    box-shadow: 0 4px 20px rgba(0,0,0,.03);
}

/* TABLE */
.table th {
    font-size: .8rem;
    color: #888;
    font-weight: 600;
    padding: 16px;
    background: #f9fafb;
}

.table td {
    padding: 16px;
    vertical-align: middle;
    border-bottom: 1px solid #f0f0f0;
}

.table-hover tbody tr:hover {
    background: rgba(255,138,0,.04);
}

/* BUTTON */
.btn-orange {
    background: var(--ez-orange);
    border: none;
    color: #fff;
    border-radius: 10px;
    padding: 10px 20px;
}

.btn-orange:hover {
    background: #e67e00;
    color: #fff;
}

/* SEARCH */
.search-form {
    max-width: 420px;
}

.search-form .form-control {
    border-radius: 10px 0 0 10px;
}

.search-form .btn {
    border-radius: 0 10px 10px 0;
}

/* BADGES */
.badge-custom {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: .75rem;
    font-weight: 500;
}

.badge-super {
    background: rgba(220,53,69,.1);
    color: #dc3545;
    border: 1px solid rgba(220,53,69,.3);
}

.badge-admin {
    background: rgba(13,110,253,.1);
    color: #0d6efd;
    border: 1px solid rgba(13,110,253,.3);
}

.badge-active {
    background: rgba(25,135,84,.1);
    color: #198754;
    border: 1px solid rgba(25,135,84,.3);
}

.badge-inactive {
    background: rgba(108,117,125,.1);
    color: #6c757d;
    border: 1px solid rgba(108,117,125,.3);
}
</style>
</head>

<body>
<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">
<?php include '../includes/sidebar.php'; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- PAGE HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title mb-0">
            <i class="bi bi-shield-lock text-warning me-2"></i>Quản lý Admin
        </h1>
        <p class="page-subtitle">Quản lý tất cả tài khoản quản trị hệ thống</p>
    </div>
    <a href="create.php" class="btn btn-orange">
        <i class="bi bi-plus-circle me-2"></i>Thêm Admin mới
    </a>
</div>

<!-- SEARCH -->
<div class="card mb-4">
<div class="card-body">
<form method="GET" class="search-form">
<div class="input-group">
    <input type="text" name="search" class="form-control"
           placeholder="Tìm kiếm theo tên đăng nhập hoặc email..."
           value="<?php echo htmlspecialchars($search); ?>">
    <button class="btn btn-outline-warning">
        <i class="bi bi-search"></i> Tìm kiếm
    </button>
    <?php if($search): ?>
    <a href="list.php" class="btn btn-outline-secondary ms-2">
        <i class="bi bi-x-circle"></i>
    </a>
    <?php endif; ?>
</div>
</form>
</div>
</div>

<!-- TABLE -->
<div class="card">
<div class="card-body">
<div class="table-responsive">
<table class="table table-hover">
<thead>
<tr>
    <th>ID</th>
    <th>Tên đăng nhập</th>
    <th>Email</th>
    <th>Vai trò</th>
    <th>Trạng thái</th>
    <th class="text-end">Thao tác</th>
</tr>
</thead>
<tbody>

<?php if(mysqli_num_rows($result) > 0): ?>
<?php while($row = mysqli_fetch_assoc($result)): ?>
<?php
$role_class = $row['role']=='super_admin'?'badge-super':'badge-admin';
$status_class = $row['status']=='active'?'badge-active':'badge-inactive';
?>
<tr>
<td>#<?php echo $row['id']; ?></td>
<td><strong><?php echo htmlspecialchars($row['username']); ?></strong></td>
<td><?php echo htmlspecialchars($row['email']); ?></td>
<td><span class="badge-custom <?php echo $role_class; ?>">
<?php echo $row['role']=='super_admin'?'Super Admin':'Admin'; ?>
</span></td>
<td><span class="badge-custom <?php echo $status_class; ?>">
<?php echo $row['status']=='active'?'Hoạt động':'Vô hiệu hóa'; ?>
</span></td>
<td class="text-end">
<div class="d-flex justify-content-end gap-2">
<a href="view.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-info">
<i class="bi bi-eye"></i>
</a>
<a href="edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm btn-outline-warning">
<i class="bi bi-pencil"></i>
</a>
<?php if($_SESSION['admin_id'] != $row['id']): ?>
<a href="delete.php?id=<?php echo $row['id']; ?>"
   class="btn btn-sm btn-outline-danger"
   onclick="return confirm('Bạn có chắc chắn muốn xóa admin này?')">
<i class="bi bi-trash"></i>
</a>
<?php endif; ?>
</div>
</td>
</tr>
<?php endwhile; ?>
<?php else: ?>
<tr>
<td colspan="6" class="text-center py-5 text-muted">
<i class="bi bi-people" style="font-size:48px;opacity:.3"></i>
<p class="mt-3">Không có dữ liệu</p>
</td>
</tr>
<?php endif; ?>

</tbody>
</table>
</div>

<div class="text-muted mt-3">
Hiển thị <strong><?php echo mysqli_num_rows($result); ?></strong> admin
</div>

</div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
