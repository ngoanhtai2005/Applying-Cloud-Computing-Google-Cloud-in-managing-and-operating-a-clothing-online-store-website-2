<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

$conn = mysqli_connect("localhost", "root", "", "fashion_store");

$id = (int)$_GET['id'];
$admin = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM admin_users WHERE id = $id"));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $role     = $_POST['role'];
    $status   = $_POST['status'];
    $password = trim($_POST['password']);

    if ($password !== '') {
        $hashed = password_hash($password, PASSWORD_DEFAULT);

        mysqli_query($conn, "
            UPDATE admin_users 
            SET role = '$role',
                status = '$status',
                password = '$hashed'
            WHERE id = $id
        ");
    } else {
        mysqli_query($conn, "
            UPDATE admin_users 
            SET role = '$role',
                status = '$status'
            WHERE id = $id
        ");
    }

    header("Location: list.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Cập nhật Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
}
body {
    background: var(--ez-bg);
}
.card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.04);
}
.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}
.page-subtitle {
    font-size: .85rem;
    color: #888;
}
</style>
</head>

<body>

<?php include "../includes/header.php"; ?>

<div class="container-fluid">
<div class="row">

<?php include "../includes/sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">
            <i class="bi bi-pencil-square text-warning me-2"></i>
            Cập nhật Admin
        </h1>
        <p class="page-subtitle">Chỉnh sửa quyền và trạng thái tài khoản</p>
    </div>

    <a href="list.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Quay lại
    </a>
</div>

<!-- FORM -->
<div class="card">
    <div class="card-body">
        <form method="post" class="row g-3">

            <div class="col-md-6">
                <label class="form-label">Username</label>
                <input class="form-control" value="<?= htmlspecialchars($admin['username']) ?>" disabled>
            </div>

            <div class="col-md-6">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="admin" <?= $admin['role']=='admin'?'selected':'' ?>>Admin</option>
                    <option value="editor" <?= $admin['role']=='editor'?'selected':'' ?>>Editor</option>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label">Status</label>
                <select name="status" class="form-select">
                    <option value="active" <?= $admin['status']=='active'?'selected':'' ?>>Active</option>
                    <option value="inactive" <?= $admin['status']=='inactive'?'selected':'' ?>>Inactive</option>
                </select>
            </div>
<div class="col-md-6">
    <label class="form-label">
        Mật khẩu mới
        <small class="text-muted">(bỏ trống nếu không đổi)</small>
    </label>
    <input type="password" name="password" class="form-control">
</div>
            <div class="col-12 text-end mt-3">
                <button class="btn btn-warning">
                    <i class="bi bi-save"></i> Cập nhật
                </button>
            </div>

        </form>
    </div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
