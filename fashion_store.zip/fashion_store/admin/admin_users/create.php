<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email    = trim($_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role     = $_POST['role'];

    mysqli_query($conn, "
        INSERT INTO admin_users (username, email, password, role)
        VALUES ('$username', '$email', '$password', '$role')
    ");

    header("Location: list.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Thêm Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
}
body {
    background: var(--ez-bg);
}
.card {
    border: none;
    border-radius: 16px;
    box-shadow: 0 4px 20px rgba(0,0,0,0.04);
}
.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}
.page-subtitle {
    font-size: .85rem;
    color: #888;
}
</style>
</head>

<body>

<?php include "../includes/header.php"; ?>

<div class="container-fluid">
<div class="row">

<?php include "../includes/sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<!-- HEADER -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <div>
        <h1 class="page-title">
            <i class="bi bi-person-plus-fill text-warning me-2"></i>Thêm Admin
        </h1>
        <p class="page-subtitle">Tạo tài khoản quản trị mới</p>
    </div>

    <a href="list.php" class="btn btn-outline-secondary">
        <i class="bi bi-arrow-left"></i> Quay lại
    </a>
</div>

<!-- FORM -->
<div class="card">
    <div class="card-body">
        <form method="post" class="row g-3">

            <div class="col-md-6">
                <label class="form-label">Username</label>
                <input type="text" name="username" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" required>
            </div>

            <div class="col-md-6">
                <label class="form-label">Role</label>
                <select name="role" class="form-select">
                    <option value="admin">Admin</option>
                    <option value="editor">Editor</option>
                </select>
            </div>

            <div class="col-12 text-end mt-3">
                <button class="btn btn-success">
                    <i class="bi bi-check-circle"></i> Tạo admin
                </button>
            </div>

        </form>
    </div>
</div>

</main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
