<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

$id = (int)$_GET['id'];
$admin = mysqli_fetch_assoc(mysqli_query(
    $conn,
    "SELECT id, username, email, role, status, created_at 
     FROM admin_users WHERE id = $id"
));

if (!$admin) {
    die("Admin không tồn tại!");
}
?>

<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chi tiết Admin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
</head>

<body>

<?php include "../includes/header.php"; ?>

<div class="container-fluid">
<div class="row">

<?php include "../includes/sidebar.php"; ?>

<main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

<div class="card">
<div class="card-body">

<h4 class="mb-4">
    <i class="bi bi-person-badge text-warning me-2"></i>
    Thông tin Admin
</h4>

<table class="table table-bordered">
<tr>
    <th width="200">ID</th>
    <td>#<?= $admin['id'] ?></td>
</tr>
<tr>
    <th>Username</th>
    <td><?= htmlspecialchars($admin['username']) ?></td>
</tr>
<tr>
    <th>Email</th>
    <td><?= htmlspecialchars($admin['email']) ?></td>
</tr>
<tr>
    <th>Role</th>
    <td><?= ucfirst($admin['role']) ?></td>
</tr>
<tr>
    <th>Status</th>
    <td><?= ucfirst($admin['status']) ?></td>
</tr>
<tr>
    <th>Ngày tạo</th>
    <td><?= $admin['created_at'] ?? '---' ?></td>
</tr>
</table>

<div class="text-end">
    <a href="list.php" class="btn btn-secondary">
        <i class="bi bi-arrow-left"></i> Quay lại
    </a>
</div>

</div>
</div>

</main>
</div>
</div>
</body>
</html>
