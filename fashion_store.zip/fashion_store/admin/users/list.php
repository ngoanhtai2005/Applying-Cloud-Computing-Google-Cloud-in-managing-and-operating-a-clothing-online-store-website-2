<?php
session_start();


if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

/* ===== SEARCH ===== */
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$where = "WHERE deleted_at IS NULL";
if ($search) {
    $where .= " AND (name LIKE '%$search%' OR email LIKE '%$search%')";
}

/* ===== GET USERS ===== */
$sql = "SELECT * FROM users $where ORDER BY created_at DESC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Quản lý người dùng</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

<style>
:root {
    --ez-orange: #FF8A00;
    --ez-bg: #F9F7F5;
    --ez-card-bg: #fff;
}

body {
    background: var(--ez-bg);
}

.card {
    border: none;
    border-radius: 16px;
    background: var(--ez-card-bg);
    box-shadow: 0 4px 20px rgba(0,0,0,0.03);
}

.page-title {
    font-size: 1.6rem;
    font-weight: 700;
}

.page-subtitle {
    font-size: .85rem;
    color: #888;
}

.table th {
    font-size: .8rem;
    color: #888;
    background: #f9fafb;
}

.table td {
    vertical-align: middle;
}

.badge-active {
    background: rgba(25,135,84,.1);
    color: #198754;
    border: 1px solid rgba(25,135,84,.3);
}

.badge-inactive {
    background: rgba(108,117,125,.1);
    color: #6c757d;
    border: 1px solid rgba(108,117,125,.3);
}
</style>
</head>

<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
<div class="row">

    <?php include '../includes/sidebar.php'; ?>

    <!-- MAIN -->
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

        <!-- PAGE HEADER -->
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h1 class="page-title mb-0">
                    <i class="bi bi-people me-2 text-warning"></i>Quản lý người dùng
                </h1>
                <p class="page-subtitle">Danh sách tài khoản hệ thống</p>
            </div>
            <a href="add.php" class="btn btn-warning text-white">
                <i class="bi bi-plus-circle me-1"></i> Thêm người dùng
            </a>
        </div>

        <!-- ALERT -->
        <?php if (!empty($_SESSION['success_message'])): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <?= $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!empty($_SESSION['error_message'])): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <?= $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
                <button class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- SEARCH -->
        <div class="card mb-4">
            <div class="card-body">
                <form method="GET" class="row g-2">
                    <div class="col-md-4">
                        <input type="text" name="search"
                               value="<?= htmlspecialchars($search) ?>"
                               class="form-control"
                               placeholder="Tìm theo tên hoặc email...">
                    </div>
                    <div class="col-md-auto">
                        <button class="btn btn-outline-warning">
                            <i class="bi bi-search"></i> Tìm kiếm
                        </button>
                        <?php if ($search): ?>
                            <a href="list.php" class="btn btn-outline-secondary ms-2">
                                <i class="bi bi-x-circle"></i>
                            </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>

        <!-- TABLE -->
        <div class="card">
            <div class="card-body table-responsive">
                <table class="table table-hover align-middle">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Tên</th>
                            <th>Email</th>
                            <th>Trạng thái</th>
                            <th>Ngày tạo</th>
                            <th width="200">Hành động</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                        <tr>
                            <td>#<?= $row['id'] ?></td>
                            <td class="fw-semibold"><?= htmlspecialchars($row['name']) ?></td>
                            <td><?= htmlspecialchars($row['email']) ?></td>
                            <td>
                                <span class="badge <?= $row['status']=='active' ? 'badge-active' : 'badge-inactive' ?>">
                                    <?= $row['status'] ?>
                                </span>
                            </td>
                            <td><?= date('d/m/Y', strtotime($row['created_at'])) ?></td>
                            <td>
                                <a href="view.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-info">
                                    <i class="bi bi-eye"></i>
                            </a>
                                <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-warning">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="delete.php?id=<?= $row['id'] ?>"
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('Xóa người dùng này?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted py-5">
                                <i class="bi bi-person-x fs-1"></i>
                                <p class="mt-2">Không có người dùng</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </main>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>
