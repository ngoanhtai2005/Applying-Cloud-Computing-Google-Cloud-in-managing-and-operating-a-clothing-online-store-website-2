<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
// BẮT EXCEPTION MYSQL
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$errors = [];
$name = $email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name    = trim($_POST['name']);
    $email   = trim($_POST['email']);
    $pass    = $_POST['password'];
    $confirm = $_POST['confirm_password'];

    // VALIDATE
    if ($name === '') $errors[] = 'Tên không được để trống';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Email không hợp lệ';
    if (strlen($pass) < 6) $errors[] = 'Mật khẩu phải ít nhất 6 ký tự';
    if ($pass !== $confirm) $errors[] = 'Mật khẩu xác nhận không khớp';

    if (empty($errors)) {
        try {
            $hashed = password_hash($pass, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare(
                $conn,
                "INSERT INTO users (name,email,password,status,created_at)
                 VALUES (?,?,?,'active',NOW())"
            );
            mysqli_stmt_bind_param($stmt, "sss", $name, $email, $hashed);
            mysqli_stmt_execute($stmt);

            $_SESSION['success_message'] = 'Thêm người dùng thành công';
            header('Location: list.php');
            exit;

        } catch (mysqli_sql_exception $e) {

            // EMAIL TRÙNG
            if ($e->getCode() == 1062) {

                // kiểm tra user bị xóa mềm chưa
                $check = mysqli_prepare(
                    $conn,
                    "SELECT id FROM users WHERE email = ? AND deleted_at IS NOT NULL"
                );
                mysqli_stmt_bind_param($check, "s", $email);
                mysqli_stmt_execute($check);
                $res = mysqli_stmt_get_result($check);

                if ($res->num_rows > 0) {
                    // KHÔI PHỤC USER
                    $restore = mysqli_prepare(
                        $conn,
                        "UPDATE users 
                         SET deleted_at = NULL,
                             status = 'active',
                             password = ?,
                             updated_at = NOW()
                         WHERE email = ?"
                    );
                    mysqli_stmt_bind_param($restore, "ss", $hashed, $email);
                    mysqli_stmt_execute($restore);

                    $_SESSION['success_message'] = 'Khôi phục người dùng đã tồn tại';
                    header('Location: list.php');
                    exit;
                } else {
                    $errors[] = 'Email đã tồn tại trong hệ thống';
                }

            } else {
                $errors[] = 'Lỗi hệ thống: ' . $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Thêm người dùng</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">

            <h3 class="mb-4">➕ Thêm người dùng</h3>

            <?php if (!empty($errors)): ?>
                <div class="alert alert-danger">
                    <ul class="mb-0">
                        <?php foreach ($errors as $err): ?>
                            <li><?= htmlspecialchars($err) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <form method="post">

                        <div class="mb-3">
                            <label class="form-label">Tên</label>
                            <input type="text" name="name" class="form-control"
                                   value="<?= htmlspecialchars($name) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Email</label>
                            <input type="email" name="email" class="form-control"
                                   value="<?= htmlspecialchars($email) ?>" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Mật khẩu</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Xác nhận mật khẩu</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>

                        <div class="d-flex gap-2">
                            <button type="submit" class="btn btn-primary">Lưu</button>
                            <a href="list.php" class="btn btn-secondary">Hủy</a>
                        </div>

                    </form>
                </div>
            </div>

        </main>
    </div>
</div>

</body>
</html>

<?php mysqli_close($conn); ?>
