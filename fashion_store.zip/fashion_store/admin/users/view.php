<?php
session_start();
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) header('Location: list.php');

$sql = "SELECT * FROM users WHERE id=? AND deleted_at IS NULL";
$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt,"i",$id);
mysqli_stmt_execute($stmt);
$user = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$user) {
    $_SESSION['error_message'] = 'User không tồn tại';
    header('Location: list.php');
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
<title>Chi tiết người dùng</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-4">

<h4>Chi tiết người dùng #<?= $user['id'] ?></h4>

<table class="table table-bordered">
<tr><th>Tên</th><td><?= htmlspecialchars($user['name']) ?></td></tr>
<tr><th>Email</th><td><?= htmlspecialchars($user['email']) ?></td></tr>
<tr><th>Phone</th><td><?= $user['phone'] ?: '-' ?></td></tr>
<tr><th>Status</th><td><?= $user['status'] ?></td></tr>
<tr><th>Created</th><td><?= $user['created_at'] ?></td></tr>
<tr><th>Last login</th><td><?= $user['last_login'] ?: '-' ?></td></tr>
<tr><th>Address</th><td><?= $user['address'] ?: '-' ?></td></tr>
</table>


<a href="list.php" class="btn btn-secondary">Quay lại</a>

</div>
</body>
</html>
