<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();


$user_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($user_id <= 0) {
    $_SESSION['error_message'] = "ID không hợp lệ";
    header("Location: list.php");
    exit;
}

// Kiểm tra tồn tại
$check = mysqli_query($conn, "SELECT id FROM users WHERE id = $user_id");
if (mysqli_num_rows($check) === 0) {
    $_SESSION['error_message'] = "Người dùng không tồn tại";
    header("Location: list.php");
    exit;
}


$sql = "DELETE FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);

if (mysqli_stmt_execute($stmt)) {
    $_SESSION['success_message'] = "Đã xóa người dùng vĩnh viễn!";
} else {
    $_SESSION['error_message'] = "Xóa thất bại!";
}

mysqli_stmt_close($stmt);
mysqli_close($conn);

header("Location: list.php");
exit;
?>
