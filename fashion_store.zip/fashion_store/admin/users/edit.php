<?php
session_start();

/* ===== CHECK LOGIN ===== */
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

/* ===== DB CONNECT ===== */
require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
/* ===== GET USER ID ===== */
$user_id = (int)($_GET['id'] ?? 0);
if ($user_id <= 0) {
    header('Location: list.php');
    exit;
}

/* ===== GET USER ===== */
$sql = "SELECT * FROM users WHERE id = ? AND deleted_at IS NULL";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result->num_rows === 0) {
    $_SESSION['error_message'] = 'Người dùng không tồn tại';
    header('Location: list.php');
    exit;
}

$user = mysqli_fetch_assoc($result);

/* ===== HANDLE POST ===== */
$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name   = trim($_POST['name']);
    $email  = trim($_POST['email']);
    $phone  = trim($_POST['phone']);
    $status = $_POST['status'];

    /* VALIDATE */
    if ($name === '') {
        $errors[] = 'Tên không được để trống';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email không hợp lệ';
    }

    /* CHECK EMAIL DUPLICATE */
    $check = mysqli_prepare(
        $conn,
        "SELECT id FROM users WHERE email = ? AND id != ? AND deleted_at IS NULL"
    );
    mysqli_stmt_bind_param($check, "si", $email, $user_id);
    mysqli_stmt_execute($check);

    if (mysqli_stmt_get_result($check)->num_rows > 0) {
        $errors[] = 'Email đã tồn tại';
    }

    /* PASSWORD */
    $password_sql = '';
    $password_param = '';

    if (!empty($_POST['password'])) {
        if (strlen($_POST['password']) < 6) {
            $errors[] = 'Mật khẩu phải ít nhất 6 ký tự';
        } elseif ($_POST['password'] !== $_POST['confirm_password']) {
            $errors[] = 'Xác nhận mật khẩu không khớp';
        } else {
            $password_sql = ", password=?";
            $password_param = password_hash($_POST['password'], PASSWORD_DEFAULT);
        }
    }

    /* UPDATE */
    if (empty($errors)) {

        $sql = "UPDATE users 
                SET name=?, email=?, phone=?, status=?, updated_at=NOW()
                $password_sql
                WHERE id=?";

        $stmt = mysqli_prepare($conn, $sql);

        if ($password_sql) {
            mysqli_stmt_bind_param(
                $stmt,
                "sssssi",
                $name, $email, $phone, $status, $password_param, $user_id
            );
        } else {
            mysqli_stmt_bind_param(
                $stmt,
                "ssssi",
                $name, $email, $phone, $status, $user_id
            );
        }

        if (mysqli_stmt_execute($stmt)) {
            $success = 'Cập nhật người dùng thành công';
            $user['name'] = $name;
            $user['email'] = $email;
            $user['phone'] = $phone;
            $user['status'] = $status;
        } else {
            $errors[] = 'Cập nhật thất bại';
        }
    }
}
?>

<!-- ===== HTML ===== -->
<!DOCTYPE html>
<html lang="vi">
<head>
<meta charset="UTF-8">
<title>Chỉnh sửa người dùng</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
<div class="container mt-4">

<h3>Chỉnh sửa người dùng #<?= $user['id'] ?></h3>

<?php if ($errors): ?>
<div class="alert alert-danger">
    <ul><?php foreach ($errors as $e) echo "<li>$e</li>"; ?></ul>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success"><?= $success ?></div>
<?php endif; ?>

<form method="post">
    <div class="mb-2">
        <label>Tên</label>
        <input class="form-control" name="name" value="<?= htmlspecialchars($user['name']) ?>" required>
    </div>

    <div class="mb-2">
        <label>Email</label>
        <input class="form-control" name="email" value="<?= htmlspecialchars($user['email']) ?>" required>
    </div>

    <div class="mb-2">
        <label>Điện thoại</label>
        <input class="form-control" name="phone" value="<?= $user['phone'] ?>">
    </div>

    <div class="mb-2">
        <label>Trạng thái</label>
        <select class="form-select" name="status">
            <option value="active" <?= $user['status']=='active'?'selected':'' ?>>Active</option>
            <option value="inactive">Inactive</option>
        </select>
    </div>

    <hr>

    <div class="mb-2">
        <label>Mật khẩu mới</label>
        <input type="password" class="form-control" name="password">
    </div>

    <div class="mb-3">
        <label>Xác nhận mật khẩu</label>
        <input type="password" class="form-control" name="confirm_password">
    </div>

    <button class="btn btn-primary">Lưu</button>
    <a href="list.php" class="btn btn-secondary">Hủy</a>
</form>

</div>
</body>
</html>
