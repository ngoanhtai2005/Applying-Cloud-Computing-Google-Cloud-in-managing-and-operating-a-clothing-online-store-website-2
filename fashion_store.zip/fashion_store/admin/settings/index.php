<?php
// --- 1. CẤU HÌNH ---
ini_set('display_errors', 1);
error_reporting(E_ALL);
session_start();


// Kiểm tra đăng nhập
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

// Kết nối Database (để sau này lưu cài đặt)
$paths = [
    __DIR__ . '/../../config/database.php',
    __DIR__ . '/../config/database.php'
];

foreach ($paths as $path) {
    if (file_exists($path)) {
        require_once($path);
        break;
    }
}
$conn = getDBConnection();
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Cài đặt Hệ thống</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .card { border: none; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
    </style>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        
        <?php 
        if (file_exists('../includes/sidebar.php')) {
            include '../includes/sidebar.php'; 
        }
        ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 pt-4">
            <h2 class="mb-4"><i class="bi bi-gear-fill text-secondary"></i> Cài đặt Hệ thống</h2>

            <div class="row">
                <div class="col-md-6">
                    <div class="card mb-4">
                        <div class="card-header bg-white fw-bold">Thông tin cửa hàng</div>
                        <div class="card-body">
                            <form>
                                <div class="mb-3">
                                    <label class="form-label">Tên cửa hàng</label>
                                    <input type="text" class="form-control" value="Fashion Store" disabled>
                                    <small class="text-muted">Chức năng đang cập nhật...</small>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Email liên hệ</label>
                                    <input type="email" class="form-control" value="admin@fashionstore.com" disabled>
                                </div>
                                <button type="button" class="btn btn-primary" disabled>Lưu thay đổi</button>
                            </form>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header bg-white fw-bold">Tài khoản Admin</div>
                        <div class="card-body">
                            <p>Xin chào, <strong>Admin</strong></p>
                            <a href="../logout.php" class="btn btn-danger w-100">
                                <i class="bi bi-box-arrow-right"></i> Đăng xuất
                            </a>
                        </div>
                    </div>
                </div>
            </div>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
