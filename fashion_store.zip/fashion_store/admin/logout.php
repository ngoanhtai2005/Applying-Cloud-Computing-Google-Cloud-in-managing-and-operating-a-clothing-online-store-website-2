<?php
session_start();

// Xóa tất cả dữ liệu session
$_SESSION = [];
session_destroy();

// Chuyển hướng về trang login
header('Location: login.php');
exit; // quan trọng
?>

