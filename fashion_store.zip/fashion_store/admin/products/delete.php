<?php
session_start();

require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

if (!$conn) {
    $_SESSION['error_message'] = 'Không thể kết nối database';
    header('Location: list.php');
    exit;
}

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($product_id <= 0) {
    $_SESSION['error_message'] = 'ID sản phẩm không hợp lệ!';
    header('Location: list.php');
    exit;
}

/* =============================
   XÓA FILE ẢNH TRƯỚC
============================= */
$images_sql = "SELECT image_url FROM product_images WHERE product_id = ?";
$stmt = mysqli_prepare($conn, $images_sql);
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while ($img = mysqli_fetch_assoc($result)) {
    if (!empty($img['image_url'])) {
        $file_path = '../../' . $img['image_url'];
        if (file_exists($file_path)) {
            unlink($file_path);
        }
    }
}
mysqli_stmt_close($stmt);

/* =============================
   XÓA SẢN PHẨM (CASCADE DB)
============================= */
$delete_sql = "DELETE FROM products WHERE id = ?";
$stmt_delete = mysqli_prepare($conn, $delete_sql);
mysqli_stmt_bind_param($stmt_delete, "i", $product_id);

if (mysqli_stmt_execute($stmt_delete)) {
    $_SESSION['success_message'] = 'Xóa sản phẩm thành công!';
} else {
    $_SESSION['error_message'] = 'Lỗi khi xóa sản phẩm!';
}

mysqli_stmt_close($stmt_delete);
mysqli_close($conn);

/* =============================
   REDIRECT
============================= */
header('Location: list.php');
exit;
