<?php
session_start();



// Kiểm tra đăng nhập
if(!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
    header('Location: ../login.php');
    exit;
}
require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();

$product_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Lấy thông tin sản phẩm
$product_result = mysqli_query($conn, "SELECT * FROM products WHERE id = $product_id");
$product = mysqli_fetch_assoc($product_result);

if (!$product) {
    $_SESSION['error_message'] = 'Sản phẩm không tồn tại!';
    header('Location: list.php');
    exit();
}

// Lấy danh sách hình ảnh
$images_result = mysqli_query($conn, "SELECT * FROM product_images WHERE product_id = $product_id ORDER BY is_main DESC, id ASC");
$images = [];
while ($img = mysqli_fetch_assoc($images_result)) {
    $images[] = $img;
}

// Lấy danh sách danh mục
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

// Xử lý form cập nhật
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = (float)$_POST['price'];
    $sale_price = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : 'NULL';
    $stock = (int)$_POST['stock'];
    $category_id = (int)$_POST['category_id'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    $best_seller = isset($_POST['best_seller']) ? 1 : 0;
    
    // Cập nhật thông tin sản phẩm
    $sql = "UPDATE products SET 
            name = '$name',
            description = '$description',
            price = $price,
            sale_price = $sale_price,
            stock = $stock,
            category_id = $category_id,
            featured = $featured,
            best_seller = $best_seller
            WHERE id = $product_id";
    
    if (mysqli_query($conn, $sql)) {
        // Xử lý xóa ảnh
        if (isset($_POST['delete_images'])) {
            foreach ($_POST['delete_images'] as $image_id) {
                $image_id = (int)$image_id;
                // Lấy đường dẫn ảnh để xóa file
                $img_query = mysqli_query($conn, "SELECT image_url FROM product_images WHERE id = $image_id");
                $img_data = mysqli_fetch_assoc($img_query);
                if ($img_data && file_exists('../../' . $img_data['image_url'])) {
                    unlink('../../' . $img_data['image_url']);
                }
                mysqli_query($conn, "DELETE FROM product_images WHERE id = $image_id");
            }
        }
        
        // Xử lý cập nhật ảnh chính
        if (isset($_POST['main_image']) && !empty($_POST['main_image'])) {
            $main_image_id = (int)$_POST['main_image'];
            mysqli_query($conn, "UPDATE product_images SET is_main = 0 WHERE product_id = $product_id");
            mysqli_query($conn, "UPDATE product_images SET is_main = 1 WHERE id = $main_image_id");
        }
        
        // Xử lý thêm ảnh mới
        if (!empty($_FILES['new_images']['name'][0])) {
            $upload_dir = '../../images/products/';
            if (!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }
            
            $new_images = $_FILES['new_images'];
            
            for ($i = 0; $i < count($new_images['name']); $i++) {
                if ($new_images['error'][$i] == 0) {
                    $check = getimagesize($new_images['tmp_name'][$i]);
                    if($check !== false) {
                        $file_ext = strtolower(pathinfo($new_images['name'][$i], PATHINFO_EXTENSION));
                        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp');
                        
                        if(in_array($file_ext, $allowed_ext)) {
                            $file_name = 'product_' . $product_id . '_' . time() . '_' . uniqid() . '.' . $file_ext;
                            $file_path = $upload_dir . $file_name;
                            $relative_path = 'images/products/' . $file_name;
                            
                            if (move_uploaded_file($new_images['tmp_name'][$i], $file_path)) {
                                $is_main = 0; // Không set ảnh mới làm ảnh chính mặc định
                                mysqli_query($conn, "INSERT INTO product_images (product_id, image_url, is_main) 
                                                    VALUES ('$product_id', '$relative_path', '$is_main')");
                            }
                        }
                    }
                }
            }
        }
        
        $_SESSION['success_message'] = 'Cập nhật sản phẩm thành công!';
        header('Location: list.php');
        exit();
    } else {
        $error = "Lỗi: " . mysqli_error($conn);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chỉnh sửa Sản phẩm - Fashion Store Admin</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom Admin CSS -->
    <link href="../assets/css/admin.css" rel="stylesheet">
<link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>

    <style>
        :root {
            --ez-orange: #FF8A00;
            --ez-bg: #F9F7F5;
            --ez-card-bg: #FFFFFF;
            --ez-text: #333;
        }

        body {
            background: var(--ez-bg);
            font-family: 'Inter', sans-serif;
        }

        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: #222;
        }

        .page-subtitle {
            font-size: 0.85rem;
            color: #999;
            margin-top: 4px;
        }

        /* CARD */
        .card {
            border: none;
            border-radius: 16px;
            background: var(--ez-card-bg);
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
        }

        .form-label {
            font-weight: 500;
            color: #555;
            margin-bottom: 8px;
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 1px solid #e0e0e0;
            padding: 12px 16px;
            transition: 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--ez-orange);
            box-shadow: 0 0 0 0.25rem rgba(255, 138, 0, 0.1);
        }

        /* BUTTON */
        .btn-orange {
            background: var(--ez-orange);
            border: none;
            border-radius: 10px;
            color: white;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-orange:hover {
            background: #e67e00;
            color: white;
        }

        .btn-outline-orange {
            border: 1px solid var(--ez-orange);
            border-radius: 10px;
            color: var(--ez-orange);
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-outline-orange:hover {
            background: var(--ez-orange);
            color: white;
        }

        .btn-outline-danger {
            border: 1px solid #dc3545;
            border-radius: 10px;
            color: #dc3545;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-outline-danger:hover {
            background: #dc3545;
            color: white;
        }

        .btn-secondary {
            background: #f0f0f0;
            border: none;
            border-radius: 10px;
            color: #666;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-secondary:hover {
            background: #e0e0e0;
            color: #333;
        }

        /* Breadcrumb */
        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 20px;
        }

        .breadcrumb-item a {
            text-decoration: none;
            color: #888;
        }

        .breadcrumb-item.active {
            color: var(--ez-orange);
            font-weight: 500;
        }

        /* Form text */
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            margin-top: 4px;
        }

        /* Image styles */
        .image-thumbnail {
            width: 100%;
            height: 150px;
            object-fit: cover;
            border-radius: 8px;
            border: 2px solid #dee2e6;
        }

        .image-thumbnail:hover {
            border-color: var(--ez-orange);
        }

        .image-checkbox-label {
            cursor: pointer;
            position: relative;
        }

        .image-checkbox-label input[type="radio"] {
            position: absolute;
            opacity: 0;
        }

        .image-checkbox-label .checkmark {
            position: absolute;
            top: 10px;
            left: 10px;
            background: var(--ez-orange);
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: 0.3s;
        }

        .image-checkbox-label input[type="radio"]:checked ~ .checkmark {
            opacity: 1;
        }

        .image-checkbox-label input[type="radio"]:checked + .image-thumbnail {
            border-color: var(--ez-orange);
            box-shadow: 0 0 0 3px rgba(255, 138, 0, 0.1);
        }

        .delete-checkbox {
            position: absolute;
            top: 10px;
            right: 10px;
        }

        /* Action buttons container */
        .action-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            margin-top: 20px;
        }

        /* Price input group */
        .input-group-text {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
        }

        /* Checkbox styling */
        .form-check-input:checked {
            background-color: var(--ez-orange);
            border-color: var(--ez-orange);
        }

        /* Required field asterisk */
        .required::after {
            content: " *";
            color: #dc3545;
        }

        /* Status badges */
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.85rem;
            font-weight: 500;
        }

        .status-in-stock {
            background: rgba(40, 167, 69, 0.1);
            color: #28a745;
            border: 1px solid rgba(40, 167, 69, 0.3);
        }

        .status-out-of-stock {
            background: rgba(220, 53, 69, 0.1);
            color: #dc3545;
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    
    <div class="container-fluid">
        <div class="row">
            <?php include '../includes/sidebar.php'; ?>
            
            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 70px;">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="list.php">Sản phẩm</a></li>
                        <li class="breadcrumb-item active">Chỉnh sửa sản phẩm</li>
                    </ol>
                </nav>

                <!-- Page Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="page-title mb-0">
                            <i class="bi bi-pencil-square text-orange me-2"></i>Chỉnh sửa sản phẩm
                        </h1>
                        <p class="page-subtitle">Chỉnh sửa thông tin sản phẩm #<?php echo $product['id']; ?></p>
                    </div>
                    <div class="btn-group" role="group">
                        <a href="index.php" class="btn btn-outline-orange">
                            <i class="bi bi-list-ul me-2"></i>Danh sách
                        </a>
                        <a href="../index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-grid me-2"></i>Dashboard
                        </a>
                    </div>
                </div>

                <!-- Success/Error Messages -->
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show mb-4" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Edit Product Form -->
                <div class="row">
                    <div class="col-md-8">
                        <form method="POST" enctype="multipart/form-data" id="productForm">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-info-circle me-2 text-primary"></i>Thông tin sản phẩm
                                    </h5>
                                    
                                    <div class="row">
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label required">Tên sản phẩm</label>
                                            <input type="text" name="name" class="form-control" 
                                                   value="<?php echo htmlspecialchars($product['name']); ?>" 
                                                   placeholder="Nhập tên sản phẩm" required>
                                            <div class="form-text">Tên sản phẩm sẽ hiển thị trên website.</div>
                                        </div>
                                        
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label">Mô tả sản phẩm</label>
                                            <textarea name="description" class="form-control" id="description" 
                                                      rows="8" placeholder="Nhập mô tả chi tiết sản phẩm"><?php echo htmlspecialchars($product['description']); ?></textarea>
                                            <div class="form-text">Mô tả chi tiết về sản phẩm.</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label required">Giá gốc (VNĐ)</label>
                                            <div class="input-group">
                                                <input type="number" name="price" class="form-control" 
                                                       value="<?php echo $product['price']; ?>" 
                                                       min="0" step="1000" placeholder="0" required>
                                                <span class="input-group-text">đ</span>
                                            </div>
                                            <div class="form-text">Giá bán gốc của sản phẩm.</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Giá khuyến mãi (VNĐ)</label>
                                            <div class="input-group">
                                                <input type="number" name="sale_price" class="form-control" 
                                                       value="<?php echo $product['sale_price']; ?>" 
                                                       min="0" step="1000" placeholder="0">
                                                <span class="input-group-text">đ</span>
                                            </div>
                                            <div class="form-text">Giá bán khuyến mãi (nếu có).</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label required">Danh mục</label>
                                            <select name="category_id" class="form-select" required>
                                                <option value="">Chọn danh mục</option>
                                                <?php 
                                                mysqli_data_seek($categories, 0);
                                                while($cat = mysqli_fetch_assoc($categories)): ?>
                                                    <option value="<?php echo $cat['id']; ?>" 
                                                        <?php echo $cat['id'] == $product['category_id'] ? 'selected' : ''; ?>>
                                                        <?php echo htmlspecialchars($cat['name']); ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                            <div class="form-text">Danh mục sản phẩm.</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label required">Số lượng tồn kho</label>
                                            <input type="number" name="stock" class="form-control" 
                                                   value="<?php echo $product['stock']; ?>" 
                                                   min="0" placeholder="0" required>
                                            <div class="form-text">Số lượng sản phẩm có sẵn trong kho.</div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Trạng thái tồn kho</label>
                                            <div>
                                                <?php if($product['stock'] > 0): ?>
                                                    <span class="status-badge status-in-stock">
                                                        <i class="bi bi-check-circle me-1"></i>Còn hàng
                                                    </span>
                                                <?php else: ?>
                                                    <span class="status-badge status-out-of-stock">
                                                        <i class="bi bi-x-circle me-1"></i>Hết hàng
                                                    </span>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Slug hiện tại</label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" 
                                                       value="<?php echo $product['slug']; ?>" disabled readonly>
                                                <span class="input-group-text bg-light">
                                                    <i class="bi bi-link-45deg"></i>
                                                </span>
                                            </div>
                                            <div class="form-text">Slug sẽ tự động cập nhật nếu bạn thay đổi tên sản phẩm.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Images Management -->
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-images me-2 text-primary"></i>Quản lý hình ảnh
                                    </h5>
                                    
                                    <?php if(!empty($images)): ?>
                                        <h6 class="mb-3">Hình ảnh hiện tại</h6>
                                        <div class="row mb-4">
                                            <?php foreach($images as $img): ?>
                                                <div class="col-md-4 col-sm-6 mb-3">
                                                    <div class="position-relative">
                                                        <label class="image-checkbox-label">
                                                            <input type="radio" name="main_image" 
                                                                   value="<?php echo $img['id']; ?>"
                                                                   <?php echo $img['is_main'] ? 'checked' : ''; ?>>
                                                            <img src="../../<?php echo htmlspecialchars($img['image_url']); ?>" 
                                                                 class="image-thumbnail" 
                                                                 alt="Hình ảnh sản phẩm">
                                                            <span class="checkmark">
                                                                <i class="bi bi-check"></i>
                                                            </span>
                                                        </label>
                                                        <div class="mt-2 text-center">
                                                            <div class="form-check form-check-inline">
                                                                <input class="form-check-input" type="checkbox" 
                                                                       name="delete_images[]" 
                                                                       id="delete_<?php echo $img['id']; ?>" 
                                                                       value="<?php echo $img['id']; ?>">
                                                                <label class="form-check-label text-danger small" for="delete_<?php echo $img['id']; ?>">
                                                                    <i class="bi bi-trash me-1"></i>Xóa
                                                                </label>
                                                            </div>
                                                            <?php if($img['is_main']): ?>
                                                                <span class="badge bg-orange bg-opacity-10 text-orange border border-orange small">
                                                                    <i class="bi bi-star-fill me-1"></i>Ảnh chính
                                                                </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endforeach; ?>
                                        </div>
                                        <div class="alert alert-info">
                                            <i class="bi bi-info-circle me-2"></i>
                                            Chọn ảnh chính bằng cách click vào hình ảnh. Đánh dấu checkbox để xóa ảnh không cần thiết.
                                        </div>
                                    <?php else: ?>
                                        <div class="alert alert-warning">
                                            <i class="bi bi-exclamation-triangle me-2"></i>
                                            Sản phẩm này chưa có hình ảnh. Vui lòng thêm ít nhất một hình ảnh.
                                        </div>
                                    <?php endif; ?>
                                    
                                    <hr>
                                    
                                    <!-- Add New Images -->
                                    <h6 class="mb-3">Thêm hình ảnh mới</h6>
                                    <div class="file-upload-area mb-3" id="fileUploadArea" 
                                         onclick="document.getElementById('new_images').click()">
                                        <i class="bi bi-cloud-arrow-up"></i>
                                        <h6>Kéo thả hình ảnh mới vào đây hoặc click để chọn</h6>
                                        <p class="text-muted mb-3">Hỗ trợ JPG, PNG, GIF, WEBP</p>
                                        <input type="file" name="new_images[]" id="new_images" 
                                               class="form-control d-none" multiple accept="image/*">
                                    </div>
                                    
                                    <div class="image-preview-container" id="imagePreviewContainer">
                                        <!-- Preview images will be added here -->
                                    </div>
                                    
                                    <div class="alert alert-warning mt-3">
                                        <i class="bi bi-exclamation-triangle me-2"></i>
                                        <strong>Lưu ý:</strong> Tối đa 10 hình ảnh, kích thước mỗi ảnh không quá 5MB.
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Additional Options -->
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-gear me-2 text-primary"></i>Tùy chọn bổ sung
                                    </h5>
                                    
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <h6 class="mb-3">Trạng thái sản phẩm</h6>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="featured" value="1" id="featured"
                                                           <?php echo $product['featured'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="featured">
                                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning px-3 py-1">
                                                            <i class="bi bi-star me-1"></i>Sản phẩm nổi bật
                                                        </span>
                                                    </label>
                                                    <div class="form-text">Sản phẩm nổi bật sẽ được hiển thị ở trang chủ.</div>
                                                </div>
                                                <div class="form-check mb-3">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="best_seller" value="1" id="best_seller"
                                                           <?php echo $product['best_seller'] ? 'checked' : ''; ?>>
                                                    <label class="form-check-label" for="best_seller">
                                                        <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-3 py-1">
                                                            <i class="bi bi-fire me-1"></i>Sản phẩm bán chạy
                                                        </span>
                                                    </label>
                                                    <div class="form-text">Sản phẩm bán chạy sẽ có badge đặc biệt.</div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <h6 class="mb-3">Thông tin sản phẩm</h6>
                                                <ul class="list-group list-group-flush">
                                                    <li class="list-group-item d-flex justify-content-between px-0">
                                                        <span class="text-muted">ID:</span>
                                                        <span class="fw-bold">#<?php echo $product['id']; ?></span>
                                                    </li>
                                                    <li class="list-group-item d-flex justify-content-between px-0">
                                                        <span class="text-muted">Ngày tạo:</span>
                                                        <span><?php echo date('d/m/Y H:i', strtotime($product['created_at'])); ?></span>
                                                    </li>
                                                    <li class="list-group-item d-flex justify-content-between px-0">
                                                        <span class="text-muted">Cập nhật:</span>
                                                        <span><?php echo date('d/m/Y H:i', strtotime($product['updated_at'] ?? $product['created_at'])); ?></span>
                                                    </li>
                                                    <li class="list-group-item d-flex justify-content-between px-0">
                                                        <span class="text-muted">Slug:</span>
                                                        <code><?php echo $product['slug']; ?></code>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Action Buttons -->
                            <div class="action-buttons mt-4">
                               
                                <a href="list.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle me-2"></i>Hủy
                                </a>
                                <button type="submit" class="btn btn-orange">
                                    <i class="bi bi-check-circle me-2"></i>Cập nhật
                                </button>
                            </div>
                        </form>
                    </div>
                    
                    <!-- Info Sidebar -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-info-circle me-2 text-primary"></i>Hướng dẫn chỉnh sửa
                                </h5>
                                <div class="alert alert-info border">
                                    <ul class="mb-0" style="font-size: 0.9rem;">
                                        <li>Cập nhật thông tin chính xác và đầy đủ</li>
                                        <li>Chọn ảnh chính chất lượng cao nhất</li>
                                        <li>Xóa ảnh cũ không cần thiết</li>
                                        <li>Kiểm tra kỹ thông tin trước khi cập nhật</li>
                                        <li>Slug sẽ tự động cập nhật khi thay đổi tên</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-lightbulb me-2 text-warning"></i>Mẹo tối ưu
                                </h5>
                                <div class="alert alert-light border">
                                    <ul class="mb-0" style="font-size: 0.9rem;">
                                        <li>Ảnh chính nên là ảnh đẹp nhất</li>
                                        <li>Đặt giá khuyến mãi hợp lý để thu hút</li>
                                        <li>Đánh dấu sản phẩm nổi bật nếu cần</li>
                                        <li>Cập nhật số lượng tồn kho thường xuyên</li>
                                        <li>Mô tả chi tiết giúp tăng tỷ lệ chuyển đổi</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-shield-check me-2 text-success"></i>Thông tin nhanh
                                </h5>
                                <ul class="list-group list-group-flush">
                                    <li class="list-group-item d-flex justify-content-between px-0">
                                        <span class="text-muted">Tổng ảnh:</span>
                                        <span class="badge bg-info"><?php echo count($images); ?> ảnh</span>
                                    </li>
                                    <li class="list-group-item d-flex justify-content-between px-0">
                                        <span class="text-muted">Giá hiện tại:</span>
<span class="fw-bold">
    <?php
        echo number_format(
            ($product['sale_price'] && $product['sale_price'] > 0)
                ? $product['sale_price']
                : $product['price'],
            0,
            ',',
            '.'
        );
    ?>đ
</span>

                                    </li>
                                    <li class="list-group-item d-flex justify-content-between px-0">
                                        <span class="text-muted">Danh mục:</span>
                                        <span>
                                            <?php 
                                            if($product['category_id']) {
                                                mysqli_data_seek($categories, 0);
                                                $found = false;
                                                while($cat = mysqli_fetch_assoc($categories)) {
                                                    if($cat['id'] == $product['category_id']) {
                                                        echo htmlspecialchars($cat['name']);
                                                        $found = true;
                                                        break;
                                                    }
                                                }
                                                if(!$found) echo '<span class="text-danger">Đã xóa</span>';
                                            } else {
                                                echo '<span class="text-muted">Chưa phân loại</span>';
                                            }
                                            ?>
                                        </span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set active menu
            const productsLink = document.querySelector('a[href*="products"]');
            if (productsLink) {
                productsLink.classList.add('active');
            }
            

            
            // File upload handling
            const fileUploadArea = document.getElementById('fileUploadArea');
            const imageInput = document.getElementById('new_images');
            const imagePreviewContainer = document.getElementById('imagePreviewContainer');
            const productForm = document.getElementById('productForm');
            
            let uploadedFiles = [];
            
            // Drag and drop functionality
            fileUploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                fileUploadArea.classList.add('dragover');
            });
            
            fileUploadArea.addEventListener('dragleave', () => {
                fileUploadArea.classList.remove('dragover');
            });
            
            fileUploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                fileUploadArea.classList.remove('dragover');
                if (e.dataTransfer.files.length) {
                    handleFiles(e.dataTransfer.files);
                }
            });
            
            // File input change
            imageInput.addEventListener('change', (e) => {
                if (e.target.files.length) {
                    handleFiles(e.target.files);
                }
            });
            
            function handleFiles(files) {
                const remainingSlots = 10 - uploadedFiles.length;
                const filesToAdd = Array.from(files).slice(0, remainingSlots);
                
                filesToAdd.forEach(file => {
                    if (!file.type.match('image.*')) {
                        alert('Chỉ chấp nhận file hình ảnh!');
                        return;
                    }
                    
                    if (file.size > 5 * 1024 * 1024) {
                        alert('File không được lớn hơn 5MB!');
                        return;
                    }
                    
                    uploadedFiles.push(file);
                    const reader = new FileReader();
                    
                    reader.onload = (e) => {
                        const preview = createImagePreview(e.target.result, uploadedFiles.length - 1);
                        imagePreviewContainer.appendChild(preview);
                    };
                    
                    reader.readAsDataURL(file);
                });
                
                // Update file input
                updateFileInput();
            }
            
            function createImagePreview(src, index) {
                const preview = document.createElement('div');
                preview.className = 'col-md-4 col-sm-6 mb-3';
                preview.innerHTML = `
                    <div class="position-relative">
                        <img src="${src}" class="image-thumbnail" alt="Preview">
                    </div>
                `;
                return preview;
            }
            
            function updateFileInput() {
                const dataTransfer = new DataTransfer();
                uploadedFiles.forEach(file => dataTransfer.items.add(file));
                imageInput.files = dataTransfer.files;
            }
            
            // Form validation
            productForm.addEventListener('submit', function(e) {
                // Show loading
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Đang xử lý...';
                submitBtn.disabled = true;
                
                // Check if any images will remain
                const totalCurrentImages = <?php echo count($images); ?>;
                const deleteCheckboxes = document.querySelectorAll('input[name="delete_images[]"]:checked');
                const imagesToDelete = deleteCheckboxes.length;
                const remainingImages = totalCurrentImages - imagesToDelete + uploadedFiles.length;
                
                if (remainingImages === 0) {
                    e.preventDefault();
                    alert('Sản phẩm phải có ít nhất một hình ảnh!\nVui lòng không xóa tất cả ảnh hoặc thêm ảnh mới.');
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    return false;
                }
            });
        });
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?>
