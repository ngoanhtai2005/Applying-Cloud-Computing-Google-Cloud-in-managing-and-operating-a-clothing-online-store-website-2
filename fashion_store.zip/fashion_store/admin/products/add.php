<?php
session_start();

// Kiểm tra đăng nhập
if(!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_username'])) {
    header('Location: ../login.php');
    exit;
}

// Kết nối cơ sở dữ liệu
require_once(__DIR__ . '/../config/database.php'); 

// 2. Sử dụng hàm kết nối từ file config
$conn = getDBConnection();
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $price = (float)$_POST['price'];
    $sale_price = !empty($_POST['sale_price']) ? (float)$_POST['sale_price'] : 'NULL';
    $category_id = (int)$_POST['category_id'];
    $stock = (int)$_POST['stock'];
    $featured = isset($_POST['featured']) ? 1 : 0;
    $best_seller = isset($_POST['best_seller']) ? 1 : 0;
    $slug = strtolower(str_replace(' ', '-', $name));
    
    $sql = "INSERT INTO products (name, slug, description, price, sale_price, category_id, stock, featured, best_seller) 
            VALUES ('$name', '$slug', '$description', $price, $sale_price, $category_id, $stock, $featured, $best_seller)";
    
    if(mysqli_query($conn, $sql)) {
        $product_id = mysqli_insert_id($conn);
// ==============================
// AUTO CREATE DEFAULT SIZES
// ==============================
$sizes = ['S', 'M', 'L', 'XL'];
$defaultStock = 10;

$attrSql = "INSERT INTO product_attributes (product_id, size, stock) VALUES (?, ?, ?)";
$attrStmt = $conn->prepare($attrSql);

foreach ($sizes as $size) {
    $attrStmt->bind_param("isi", $product_id, $size, $defaultStock);
    $attrStmt->execute();
}

$attrStmt->close();


        // Xử lý upload hình ảnh
        if(isset($_FILES['images']) && $_FILES['images']['error'][0] != 4) {
            $upload_dir = '../../images/products/';
            if(!is_dir($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

            for($i = 0; $i < count($_FILES['images']['name']); $i++) {
                if($_FILES['images']['error'][$i] == 0) {
                    // Kiểm tra file có phải là ảnh
                    $check = getimagesize($_FILES['images']['tmp_name'][$i]);
                    if($check !== false) {
                        $file_ext = strtolower(pathinfo($_FILES['images']['name'][$i], PATHINFO_EXTENSION));
                        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif', 'webp');

                        if(in_array($file_ext, $allowed_ext)) {
                            // Tạo tên file duy nhất
                            $file_name = 'product_' . $product_id . '_' . time() . '_' . uniqid() . '.' . $file_ext;
                            $target_file = $upload_dir . $file_name;

                            if(move_uploaded_file($_FILES['images']['tmp_name'][$i], $target_file)) {
                                $is_main = ($i == 0) ? 1 : 0; // Ảnh đầu tiên là ảnh chính
                                $image_url = 'images/products/' . $file_name;
                                mysqli_query($conn, "INSERT INTO product_images (product_id, image_url, is_main) 
                                                     VALUES ('$product_id', '$image_url', '$is_main')");
                            }
                        }
                    }
                }
            }
        }

        $_SESSION['success_message'] = "Thêm sản phẩm thành công!";
        header('Location: list.php');
        exit;
    } else {
        $error = "Lỗi khi thêm sản phẩm: " . mysqli_error($conn);
    }
}

// Lấy danh mục
$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm Sản phẩm - Fashion Store Admin</title>
    <!-- Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.0/font/bootstrap-icons.css">
    <!-- Custom Admin CSS -->
    <link href="../assets/css/admin.css" rel="stylesheet">
    <link href="https://cdn.quilljs.com/1.3.6/quill.snow.css" rel="stylesheet">
    <script src="https://cdn.quilljs.com/1.3.6/quill.min.js"></script>

    <style>
        :root {
            --ez-orange: #FF8A00;
            --ez-bg: #F9F7F5;
            --ez-card-bg: #FFFFFF;
            --ez-text: #333;
        }

        body {
            background: var(--ez-bg);
            font-family: 'Inter', sans-serif;
        }

        .page-title {
            font-size: 1.6rem;
            font-weight: 700;
            color: #222;
        }

        .page-subtitle {
            font-size: 0.85rem;
            color: #999;
            margin-top: 4px;
        }
   /* CARD */
        .card {
            border: none;
            border-radius: 16px;
            background: var(--ez-card-bg);
            box-shadow: 0 4px 20px rgba(0,0,0,0.03);
        }

        .form-label {
            font-weight: 500;
            color: #555;
            margin-bottom: 8px;
        }

        .form-control, .form-select {
            border-radius: 10px;
            border: 1px solid #e0e0e0;
            padding: 12px 16px;
            transition: 0.3s;
        }

        .form-control:focus, .form-select:focus {
            border-color: var(--ez-orange);
            box-shadow: 0 0 0 0.25rem rgba(255, 138, 0, 0.1);
        }
   /* BUTTON */
        .btn-orange {
            background: var(--ez-orange);
            border: none;
            border-radius: 10px;
            color: white;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-orange:hover {
            background: #e67e00;
            color: white;
        }

        .btn-outline-orange {
            border: 1px solid var(--ez-orange);
            border-radius: 10px;
            color: var(--ez-orange);
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-outline-orange:hover {
            background: var(--ez-orange);
            color: white;
        }

        .btn-secondary {
            background: #f0f0f0;
            border: none;
            border-radius: 10px;
            color: #666;
            padding: 10px 24px;
            font-weight: 500;
        }

        .btn-secondary:hover {
            background: #e0e0e0;
            color: #333;
        }
 /* Breadcrumb */
        .breadcrumb {
            background: transparent;
            padding: 0;
            margin-bottom: 20px;
        }

        .breadcrumb-item a {
            text-decoration: none;
            color: #888;
        }

        .breadcrumb-item.active {
            color: var(--ez-orange);
            font-weight: 500;
        }

        /* Form text */
        .form-text {
            font-size: 0.875rem;
            color: #6c757d;
            margin-top: 4px;
        }

        /* File upload */
        .file-upload-area {
            border: 2px dashed #dee2e6;
            border-radius: 10px;
            padding: 30px;
            text-align: center;
            background: #f8f9fa;
            cursor: pointer;
            transition: 0.3s;
        }

        .file-upload-area:hover {
            border-color: var(--ez-orange);
            background: rgba(255, 138, 0, 0.05);
        }

        .file-upload-area i {
            font-size: 48px;
            color: #adb5bd;
            margin-bottom: 15px;
        }

        .file-upload-area.dragover {
            border-color: var(--ez-orange);
            background: rgba(255, 138, 0, 0.1);
        }
/* Preview images */
        .image-preview-container {
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
            margin-top: 20px;
        }

        .image-preview {
            position: relative;
            width: 120px;
            height: 120px;
            border-radius: 8px;
            overflow: hidden;
            border: 2px solid #dee2e6;
        }

        .image-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .image-preview .remove-image {
            position: absolute;
            top: 5px;
            right: 5px;
            background: rgba(220, 53, 69, 0.9);
            color: white;
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            border: none;
        }

        .main-image-badge {
            position: absolute;
            bottom: 5px;
            left: 5px;
            background: var(--ez-orange);
            color: white;
            padding: 2px 8px;
            border-radius: 10px;
            font-size: 0.75rem;
        }
 /* Action buttons container */
        .action-buttons {
            display: flex;
            justify-content: flex-end;
            gap: 12px;
            padding-top: 20px;
            border-top: 1px solid #eee;
            margin-top: 20px;
        }

        /* Price input group */
        .input-group-text {
            background: #f8f9fa;
            border: 1px solid #e0e0e0;
        }

        /* Checkbox styling */
        .form-check-input:checked {
            background-color: var(--ez-orange);
            border-color: var(--ez-orange);
        }

        /* Required field asterisk */
        .required::after {
            content: " *";
            color: #dc3545;
        }
    </style>
</head>
<body>
    <?php include '../includes/header.php'; ?>
    <div class="container-fluid">
        <div class="row">
            <?php include '../includes/sidebar.php'; ?>

            <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4" style="padding-top: 70px;">
                <!-- Breadcrumb -->
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="../index.php">Dashboard</a></li>
                        <li class="breadcrumb-item"><a href="list.php">Sản phẩm</a></li>
                        <li class="breadcrumb-item active">Thêm sản phẩm mới</li>
                    </ol>
                </nav>

                <!-- Page Header -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="page-title mb-0">
                            <i class="bi bi-plus-circle text-orange me-2"></i>Thêm sản phẩm mới
                        </h1>
                        <p class="page-subtitle">Thêm sản phẩm mới vào cửa hàng thời trang</p>
                    </div>
                    <div class="btn-group" role="group">
                        <a href="index.php" class="btn btn-outline-orange">
                            <i class="bi bi-list-ul me-2"></i>Danh sách
                        </a>
                        <a href="../index.php" class="btn btn-outline-secondary">
                            <i class="bi bi-grid me-2"></i>Dashboard
                        </a>
                    </div>
                </div>

                <!-- Success/Error Messages -->
                <?php if(isset($error)): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="bi bi-exclamation-triangle me-2"></i>
                        <?php echo $error; ?>
                        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                    </div>
                <?php endif; ?>

                <!-- Add Product Form -->
                <div class="row">
                    <div class="col-md-8">
                        <form method="POST" enctype="multipart/form-data" id="productForm">
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-info-circle me-2 text-primary"></i>Thông tin sản phẩm
                                    </h5>
<div class="row">
                                        <div class="col-md-12 mb-3">
                                            <label class="form-label required">Tên sản phẩm</label>
                                            <input type="text" name="name" class="form-control" 
                                                   placeholder="Nhập tên sản phẩm" required>
                                            <div class="form-text">Tên sản phẩm sẽ hiển thị trên website.</div>
                                        </div>

                                        <div class="col-md-12 mb-3">
                                            <label class="form-label">Mô tả sản phẩm</label>
                                            <textarea name="description" class="form-control" id="description" 
                                                      rows="8" placeholder="Nhập mô tả chi tiết sản phẩm"></textarea>
                                            <div class="form-text">Mô tả chi tiết về sản phẩm.</div>
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label class="form-label required">Giá gốc (VNĐ)</label>
                                            <div class="input-group">
                                                <input type="number" name="price" class="form-control" 
                                                       min="0" step="1000" placeholder="0" required>
                                                <span class="input-group-text">đ</span>
                                            </div>
                                            <div class="form-text">Giá bán gốc của sản phẩm.</div>
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label class="form-label">Giá khuyến mãi (VNĐ)</label>
                                            <div class="input-group">
                                                <input type="number" name="sale_price" class="form-control" 
                                                       min="0" step="1000" placeholder="0">
                                                <span class="input-group-text">đ</span>
                                            </div>
                                            <div class="form-text">Giá bán khuyến mãi (nếu có).</div>
                                        </div>

                                        <div class="col-md-6 mb-3">
                                            <label class="form-label required">Danh mục</label>
                                            <select name="category_id" class="form-select" required>
                                                <option value="">Chọn danh mục</option>
                                                <?php while($cat = mysqli_fetch_assoc($categories)): ?>
                                                    <option value="<?php echo $cat['id']; ?>">
                                                        <?php echo htmlspecialchars($cat['name']); ?>
                                                    </option>
                                                <?php endwhile; ?>
                                            </select>
                                            <div class="form-text">Danh mục sản phẩm.</div>
                                        </div>
<div class="col-md-6 mb-3">
                                            <label class="form-label required">Số lượng tồn kho</label>
                                            <input type="number" name="stock" class="form-control" 
                                                   min="0" placeholder="0" required>
                                            <div class="form-text">Số lượng sản phẩm có sẵn trong kho.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Images Upload -->
                            <div class="card mb-4">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-images me-2 text-primary"></i>Hình ảnh sản phẩm
                                    </h5>

                                    <div class="file-upload-area" id="fileUploadArea">
                                        <i class="bi bi-cloud-arrow-up"></i>
                                        <h6>Kéo thả hình ảnh vào đây hoặc click để chọn</h6>
                                        <p class="text-muted mb-2">Hỗ trợ JPG, PNG, GIF, WEBP</p>
                                        <p class="text-muted mb-3">Ảnh đầu tiên sẽ là ảnh chính của sản phẩm</p>
                                        <input type="file" name="images[]" id="imageInput" 
                                               class="form-control d-none" multiple accept="image/*" required>
                                        <button type="button" class="btn btn-orange btn-sm" onclick="document.getElementById('imageInput').click()">
                                            <i class="bi bi-upload me-2"></i>Chọn hình ảnh
                                        </button>
                                    </div>

                                    <div class="image-preview-container" id="imagePreviewContainer">
                                        <!-- Preview images will be added here -->
                                    </div>

                                    <div class="alert alert-info mt-3">
                                        <i class="bi bi-info-circle me-2"></i>
                                        <strong>Lưu ý:</strong> Tối đa 10 hình ảnh, kích thước mỗi ảnh không quá 5MB.
                                    </div>
                                </div>
                            </div>

                            <!-- Additional Options -->
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title mb-4">
                                        <i class="bi bi-gear me-2 text-primary"></i>Tùy chọn bổ sung
                                    </h5>
<div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <h6 class="mb-3">Trạng thái sản phẩm</h6>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="featured" value="1" id="featured">
                                                    <label class="form-check-label" for="featured">
                                                        <span class="badge bg-warning bg-opacity-10 text-warning border border-warning px-3 py-1">
                                                            <i class="bi bi-star me-1"></i>Sản phẩm nổi bật
                                                        </span>
                                                    </label>
                                                </div>
                                                <div class="form-check mb-2">
                                                    <input class="form-check-input" type="checkbox" 
                                                           name="best_seller" value="1" id="best_seller">
                                                    <label class="form-check-label" for="best_seller">
                                                        <span class="badge bg-danger bg-opacity-10 text-danger border border-danger px-3 py-1">
                                                            <i class="bi bi-fire me-1"></i>Sản phẩm bán chạy
                                                        </span>
                                                    </label>
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-md-6">
                                            <div class="mb-4">
                                                <h6 class="mb-3">Thông tin SEO (tự động)</h6>
                                                <div class="form-text">
                                                    <strong>Slug:</strong> <span id="slugPreview" class="text-muted">Sẽ tự động tạo từ tên sản phẩm</span><br>
                                                    <strong>Meta Title:</strong> Tên sản phẩm<br>
                                                    <strong>Meta Description:</strong> Từ mô tả sản phẩm
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
<!-- Action Buttons -->
                            <div class="action-buttons mt-4">
                                <button type="reset" class="btn btn-outline-secondary">
                                    <i class="bi bi-arrow-clockwise me-2"></i>Làm mới
                                </button>
                                <a href="list.php" class="btn btn-secondary">
                                    <i class="bi bi-x-circle me-2"></i>Hủy
                                </a>
                                <button type="submit" class="btn btn-orange">
                                    <i class="bi bi-check-circle me-2"></i>Lưu sản phẩm
                                </button>
                            </div>
                        </form>
                    </div>

                    <!-- Info Sidebar -->
                    <div class="col-md-4">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-info-circle me-2 text-primary"></i>Hướng dẫn
                                </h5>
                                <div class="alert alert-info border">
                                    <h6 class="alert-heading mb-2">Thông tin sản phẩm</h6>
                                    <ul class="mb-0" style="font-size: 0.9rem;">
                                        <li>Tên sản phẩm nên ngắn gọn, dễ hiểu</li>
                                        <li>Mô tả chi tiết giúp tăng tỷ lệ chuyển đổi</li>
                                        <li>Giá cả nên cạnh tranh với thị trường</li>
                                        <li>Chọn đúng danh mục giúp khách dễ tìm</li>
                                    </ul>
                                </div>
                            </div>
                        </div>

                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-lightbulb me-2 text-warning"></i>Mẹo tối ưu
                                </h5>
                                <div class="alert alert-light border">
                                    <ul class="mb-0" style="font-size: 0.9rem;">
                                        <li>Sử dụng hình ảnh chất lượng cao</li>
                                        <li>Ảnh đầu tiên nên là ảnh đẹp nhất</li>
                                        <li>Đặt giá khuyến mãi hợp lý để thu hút</li>
                                        <li>Đánh dấu sản phẩm nổi bật nếu cần</li>
                                        <li>Kiểm tra kỹ thông tin trước khi lưu</li>
                                    </ul>
                                </div>
                            </div>
                        </div><div class="card">
                            <div class="card-body">
                                <h5 class="card-title mb-3">
                                    <i class="bi bi-shield-check me-2 text-success"></i>Chất lượng hình ảnh
                                </h5>
                                <div class="alert alert-success border">
                                    <h6 class="alert-heading mb-2">Tiêu chuẩn hình ảnh</h6>
                                    <ul class="mb-0" style="font-size: 0.9rem;">
                                        <li>Định dạng: JPG, PNG, WEBP</li>
                                        <li>Kích thước: Tối ưu 800x800px</li>
                                        <li>Dung lượng: Dưới 2MB/ảnh</li>
                                        <li>Nền trắng hoặc nền đẹp</li>
                                        <li>Không watermark, không logo khác</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Set active menu
            const productsLink = document.querySelector('a[href*="products"]');
            if (productsLink) {
                productsLink.classList.add('active');
            }

 // File upload handling
            const fileUploadArea = document.getElementById('fileUploadArea');
            const imageInput = document.getElementById('imageInput');
            const imagePreviewContainer = document.getElementById('imagePreviewContainer');
            const productForm = document.getElementById('productForm');

            let uploadedFiles = [];

            // Drag and drop functionality
            fileUploadArea.addEventListener('dragover', (e) => {
                e.preventDefault();
                fileUploadArea.classList.add('dragover');
            });

            fileUploadArea.addEventListener('dragleave', () => {
                fileUploadArea.classList.remove('dragover');
            });

            fileUploadArea.addEventListener('drop', (e) => {
                e.preventDefault();
                fileUploadArea.classList.remove('dragover');
                if (e.dataTransfer.files.length) {
                    handleFiles(e.dataTransfer.files);
                }
            });

            // File input change
            imageInput.addEventListener('change', (e) => {
                if (e.target.files.length) {
                    handleFiles(e.target.files);
                }
            });

            function handleFiles(files) {
                const remainingSlots = 10 - uploadedFiles.length;
                const filesToAdd = Array.from(files).slice(0, remainingSlots);

                filesToAdd.forEach(file => {
                    if (!file.type.match('image.*')) {
                        alert('Chỉ chấp nhận file hình ảnh!');
                        return;
                    }

                    if (file.size > 5 * 1024 * 1024) {
                        alert('File không được lớn hơn 5MB!');
                        return;
                    }

                    uploadedFiles.push(file);
                    const reader = new FileReader();

                    reader.onload = (e) => {
                        const preview = createImagePreview(e.target.result, uploadedFiles.length - 1);
                        imagePreviewContainer.appendChild(preview);
                    };

                    reader.readAsDataURL(file);
                });

                // Update file input
                updateFileInput();
            }

            function createImagePreview(src, index) {
                const preview = document.createElement('div');
                preview.className = 'image-preview';
                preview.dataset.index = index;

                preview.innerHTML = `
                    <img src="${src}" alt="Preview">
                    <button type="button" class="remove-image" onclick="removeImage(${index})">
                        <i class="bi bi-x"></i>
                    </button>
                    ${index === 0 ? '<span class="main-image-badge">Ảnh chính</span>' : ''}
                `;

                return preview;
            }

            window.removeImage = function(index) {
                uploadedFiles.splice(index, 1);
                updatePreviews();
                updateFileInput();
            };

            function updatePreviews() {
                imagePreviewContainer.innerHTML = '';
                uploadedFiles.forEach((file, index) => {
                    const reader = new FileReader();
                    reader.onload = (e) => {
                        const preview = createImagePreview(e.target.result, index);
                        imagePreviewContainer.appendChild(preview);
                    };
                    reader.readAsDataURL(file);
                });
            }

            function updateFileInput() {
                const dataTransfer = new DataTransfer();
                uploadedFiles.forEach(file => dataTransfer.items.add(file));
                imageInput.files = dataTransfer.files;

                // Update validation message
                if (uploadedFiles.length === 0) {
                    imageInput.setCustomValidity('Vui lòng chọn ít nhất một hình ảnh');
                } else {
                    imageInput.setCustomValidity('');
                }
            }

            // Auto generate slug from name
            const nameInput = document.querySelector('input[name="name"]');
            const slugPreview = document.getElementById('slugPreview');

            nameInput.addEventListener('input', function() {
                if (slugPreview) {
                    const slug = this.value
                        .toLowerCase()
                        .normalize('NFD')
                        .replace(/[\u0300-\u036f]/g, '')
                        .replace(/đ/g, 'd')
                        .replace(/Đ/g, 'd')
                        .replace(/[^\w\s-]/g, '')
                        .replace(/\s+/g, '-')
                        .replace(/-+/g, '-')
                        .trim();
                    slugPreview.textContent = slug || 'Sẽ tự động tạo từ tên sản phẩm';
                }
            });

            // Form validation
            productForm.addEventListener('submit', function(e) {
                if (uploadedFiles.length === 0) {
                    e.preventDefault();
                    alert('Vui lòng chọn ít nhất một hình ảnh sản phẩm!');
                    return false;
                }

                // Show loading
                const submitBtn = this.querySelector('button[type="submit"]');
                const originalText = submitBtn.innerHTML;
                submitBtn.innerHTML = '<i class="bi bi-hourglass-split me-2"></i>Đang xử lý...';
                submitBtn.disabled = true;
            });
// Reset form
            productForm.addEventListener('reset', function() {
                uploadedFiles = [];
                imagePreviewContainer.innerHTML = '';
                updateFileInput();



                slugPreview.textContent = 'Sẽ tự động tạo từ tên sản phẩm';
            });
        });
    </script>
</body>
</html>

<?php
mysqli_close($conn);
?>





