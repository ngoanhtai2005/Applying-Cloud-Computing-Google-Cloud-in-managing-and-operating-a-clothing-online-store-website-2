<?php
session_start();




/* ================== AUTH ================== */
if (!isset($_SESSION['admin_id'])) {
    header('Location: ../login.php');
    exit;
}

/* ================== DATABASE ================== */
require_once __DIR__ . '/../../config/database.php';
$conn = getDBConnection();

/* ================== SEARCH ================== */
$search = isset($_GET['search']) ? mysqli_real_escape_string($conn, $_GET['search']) : '';
$where = '';
if ($search) {
    $where = "WHERE p.name LIKE '%$search%' OR p.description LIKE '%$search%'";
}

/* ================== PRODUCTS ================== */
$products = mysqli_query($conn, "
    SELECT 
        p.*, 
        c.name AS category_name,
        (
            SELECT image_url 
            FROM product_images 
            WHERE product_id = p.id AND is_main = 1 
            LIMIT 1
        ) AS image
    FROM products p
    LEFT JOIN categories c ON p.category_id = c.id
    $where
    ORDER BY p.created_at DESC
");
?>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Quản lý Sản phẩm</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css" rel="stylesheet">

    <style>
        :root {
            --ez-orange: #FF8A00;
            --ez-bg: #F9F7F5;
        }

        body { background: var(--ez-bg); }

        .text-orange { color: var(--ez-orange); }

        .card {
            border: none;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,.04);
        }

        .product-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #eee;
        }

        .product-img-placeholder {
            width: 60px;
            height: 60px;
            border-radius: 10px;
            background: #f1f1f1;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #aaa;
            border: 1px dashed #ccc;
        }

        .badge-featured {
            background: rgba(255,193,7,.1);
            color: #ffc107;
            border: 1px solid rgba(255,193,7,.4);
        }

        .badge-bestseller {
            background: rgba(220,53,69,.1);
            color: #dc3545;
            border: 1px solid rgba(220,53,69,.4);
        }

        .btn-orange {
            background: var(--ez-orange);
            border: none;
            color: #fff;
            border-radius: 10px;
        }

        .btn-orange:hover {
            background: #e67800;
            color: #fff;
        }
    </style>
</head>
<body>

<?php include '../includes/header.php'; ?>

<div class="container-fluid">
    <div class="row">
        <?php include '../includes/sidebar.php'; ?>

        <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4 py-4">

            <!-- HEADER -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <div>
                    <h4 class="fw-bold mb-1">
                        <i class="bi bi-box-seam text-orange me-2"></i>Quản lý Sản phẩm
                    </h4>
                    <small class="text-muted">Danh sách toàn bộ sản phẩm</small>
                </div>
                <a href="add.php" class="btn btn-orange">
                    <i class="bi bi-plus-circle me-1"></i> Thêm sản phẩm
                </a>
            </div>

            <!-- SEARCH -->
            <div class="card mb-4">
                <div class="card-body">
                    <form method="GET" class="row g-2">
                        <div class="col-md-6">
                            <input type="text" name="search" class="form-control"
                                   placeholder="Tìm theo tên hoặc mô tả..."
                                   value="<?= htmlspecialchars($search) ?>">
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-outline-secondary w-100">
                                <i class="bi bi-search"></i> Tìm
                            </button>
                        </div>
                        <?php if ($search): ?>
                            <div class="col-md-2">
                                <a href="list.php" class="btn btn-outline-danger w-100">
                                    <i class="bi bi-x-circle"></i> Reset
                                </a>
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>

            <!-- TABLE -->
            <div class="card">
                <div class="card-body table-responsive">
                    <table class="table table-hover align-middle">
                        <thead class="table-light">
                            <tr>
                                <th>Ảnh</th>
                                <th>Tên</th>
                                <th>Danh mục</th>
                                <th>Giá</th>
                                <th>Tồn</th>
                                <th>Trạng thái</th>
                                <th>Thao tác</th>
                            </tr>
                        </thead>
                        <tbody>

                        <?php if (mysqli_num_rows($products) > 0): ?>
                            <?php while ($row = mysqli_fetch_assoc($products)): ?>
                                <tr>

                                    <!-- IMAGE -->
                                    <td>
                                        <?php if ($row['image']): ?>
                                            <?php
                                                $img = strpos($row['image'], 'http') === 0
                                                    ? $row['image']
                                                    : '../../' . $row['image'];
                                            ?>
                                            <img src="<?= $img ?>" class="product-img">
                                        <?php else: ?>
                                            <div class="product-img-placeholder">
                                                <i class="bi bi-image"></i>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    <!-- NAME -->
                                    <td>
                                        <strong><?= htmlspecialchars($row['name']) ?></strong>
                                        <div class="mt-1">
                                            <?php if ($row['featured']): ?>
                                                <span class="badge badge-featured me-1">Nổi bật</span>
                                            <?php endif; ?>
                                            <?php if ($row['best_seller']): ?>
                                                <span class="badge badge-bestseller">Bán chạy</span>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    <!-- CATEGORY -->
                                    <td>
                                        <span class="badge bg-light text-dark border">
                                            <?= $row['category_name'] ?: 'Chưa phân loại' ?>
                                        </span>
                                    </td>

                                    <!-- PRICE -->
                                    <td>
                                        <?php if ($row['sale_price'] > 0): ?>
                                            <div class="fw-bold text-danger">
                                                <?= number_format($row['sale_price'], 0, ',', '.') ?>đ
                                            </div>
                                            <small class="text-muted text-decoration-line-through">
                                                <?= number_format($row['price'], 0, ',', '.') ?>đ
                                            </small>
                                        <?php else: ?>
                                            <strong><?= number_format($row['price'], 0, ',', '.') ?>đ</strong>
                                        <?php endif; ?>
                                    </td>

                                    <!-- STOCK -->
                                    <td>
                                        <span class="badge <?= $row['stock'] > 0 ? 'bg-success' : 'bg-danger' ?>">
                                            <?= $row['stock'] ?> sp
                                        </span>
                                    </td>

                                    <!-- STATUS -->
                                    <td>
                                        <?php if ($row['stock'] > 0): ?>
                                            <span class="badge bg-success bg-opacity-10 text-success border">
                                                Còn hàng
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger bg-opacity-10 text-danger border">
                                                Hết hàng
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <!-- ACTION -->
                                    <td>
                                        <a href="edit.php?id=<?= $row['id'] ?>" class="btn btn-sm btn-outline-warning">
                                            <i class="bi bi-pencil"></i>
                                        </a>
                                        <a href="delete.php?id=<?= $row['id'] ?>"
                                           class="btn btn-sm btn-outline-danger"
                                           onclick="return confirm('Xóa sản phẩm này?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>

                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5 text-muted">
                                    <i class="bi bi-box fs-1"></i>
                                    <p class="mt-2">Không có sản phẩm</p>
                                </td>
                            </tr>
                        <?php endif; ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php mysqli_close($conn); ?>

