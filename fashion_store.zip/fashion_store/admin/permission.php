<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Chưa đăng nhập → đá về login
if (!isset($_SESSION['admin_id']) || !isset($_SESSION['admin_role'])) {
    header('Location: login.php');
    exit;
}

/**
 * Check quyền truy cập
 * @param array $allowedRoles
 */
function checkPermission(array $allowedRoles) {
    if (!in_array($_SESSION['admin_role'], $allowedRoles)) {
        die('Bạn không có quyền truy cập chức năng này');
    }
}
