<?php
require_once 'config/database.php';
require_once 'config/functions.php';

// Redirect if not logged in
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$userId = getCurrentUserId();
$conn = getDBConnection();


$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc(); 
$stmt->close();

// Kiểm tra nếu không tìm thấy user
if (!$user) {
    die("User not found.");
}

// Get recent orders
$stmt = $conn->prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 5");
$stmt->bind_param("i", $userId);
$stmt->execute();
$orders = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Get wishlist count
$stmt = $conn->prepare("SELECT COUNT(*) as count FROM wishlist WHERE user_id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$wishlistCount = $stmt->get_result()->fetch_assoc()['count'] ?? 0;
$stmt->close();

$conn->close();

$pageTitle = "My Account";
?>
<?php include 'includes/header.php'; ?>
<?php include 'includes/navbar.php'; ?>

<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 mb-5">
                <div class="account-sidebar">
                    <div class="user-info text-center mb-4 p-4 border">
                        <div class="user-avatar mb-3">
                            <div class="avatar-circle bg-dark text-white rounded-circle d-inline-flex align-items-center justify-content-center" 
                                 style="width: 80px; height: 80px;">
                                <span class="fs-4"><?php echo strtoupper(substr($user['name'] ?? 'U', 0, 1)); ?></span>
                            </div>
                        </div>
                        <h5 class="fw-bold mb-1"><?php echo htmlspecialchars($user['name']); ?></h5>
                        <p class="text-muted small mb-0"><?php echo htmlspecialchars($user['email']); ?></p>
                    </div>
                    
                    <div class="account-menu">
                        <ul class="list-unstyled">
                            <li class="mb-2">
                                <a href="account.php" class="d-block p-3 border bg-dark text-white text-decoration-none">
                                    <i class="bi bi-person me-2"></i> Account Overview
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="orders.php" class="d-block p-3 border text-dark text-decoration-none">
                                    <i class="bi bi-bag me-2"></i> My Orders
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="wishlist.php" class="d-block p-3 border text-dark text-decoration-none">
                                    <i class="bi bi-heart me-2"></i> My Wishlist
                                    <?php if ($wishlistCount > 0): ?>
                                        <span class="badge bg-dark rounded-pill float-end"><?php echo $wishlistCount; ?></span>
                                    <?php endif; ?>
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="account-addresses.php" class="d-block p-3 border text-dark text-decoration-none">
                                    <i class="bi bi-geo-alt me-2"></i> Address Book
                                </a>
                            </li>
                            <li class="mb-2">
                                <a href="account-settings.php" class="d-block p-3 border text-dark text-decoration-none">
                                    <i class="bi bi-gear me-2"></i> Account Settings
                                </a>
                            </li>
                            <li>
                                <a href="logout.php" class="d-block p-3 border text-dark text-decoration-none">
                                    <i class="bi bi-box-arrow-right me-2"></i> Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="col-lg-9">
                <div class="account-content">
                    <h1 class="fw-light mb-4">ACCOUNT OVERVIEW</h1>
                    
                    <div class="welcome-message bg-light p-4 mb-5">
                        <h4 class="fw-bold mb-3">Welcome back, <?php echo htmlspecialchars($user['name']); ?>!</h4>
                        <p class="text-muted mb-0">Here's a summary of your recent activity.</p>
                    </div>
                    
                    <div class="account-stats mb-5">
                        <div class="row">
                            <div class="col-md-4 mb-4">
                                <div class="stat-card text-center p-4 border">
                                    <i class="bi bi-bag fs-1 text-dark mb-3"></i>
                                    <h3 class="fw-bold mb-2"><?php echo count($orders); ?></h3>
                                    <p class="text-muted mb-0">Recent Orders</p>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="stat-card text-center p-4 border">
                                    <i class="bi bi-heart fs-1 text-dark mb-3"></i>
                                    <h3 class="fw-bold mb-2"><?php echo $wishlistCount; ?></h3>
                                    <p class="text-muted mb-0">Wishlist Items</p>
                                </div>
                            </div>
                            <div class="col-md-4 mb-4">
                                <div class="stat-card text-center p-4 border">
                                    <i class="bi bi-calendar-check fs-1 text-dark mb-3"></i>
                                    <h3 class="fw-bold mb-2"><?php echo date('M Y', strtotime($user['created_at'])); ?></h3>
                                    <p class="text-muted mb-0">Member Since</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <div class="recent-orders">
                        <div class="d-flex justify-content-between align-items-center mb-4">
                            <h4 class="fw-bold mb-0">RECENT ORDERS</h4>
                            <a href="orders.php" class="text-dark">View All Orders</a>
                        </div>
                        
                        <?php if (empty($orders)): ?>
                            <div class="text-center py-5 border">
                                <i class="bi bi-bag fs-1 text-muted mb-3"></i>
                                <h5 class="text-muted mb-3">No orders yet</h5>
                                <a href="category.php?category=all" class="btn btn-dark rounded-0">START SHOPPING</a>
                            </div>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>Order #</th>
                                            <th>Date</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $order): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars($order['order_number']); ?></td>
                                                <td><?php echo date('M d, Y', strtotime($order['created_at'])); ?></td>
                                                <td><?php echo formatPrice($order['total_amount']); ?></td>
                                                <td>
                                                    <span class="badge rounded-0 
                                                        <?php echo $order['status'] === 'delivered' ? 'bg-success' : 
                                                              ($order['status'] === 'processing' ? 'bg-primary' : 
                                                              ($order['status'] === 'shipped' ? 'bg-info' : 'bg-warning')); ?>">
                                                        <?php echo ucfirst($order['status']); ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <a href="order-details.php?order=<?php echo $order['order_number']; ?>" 
                                                       class="text-dark text-decoration-none border-bottom">
                                                        View Details
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>