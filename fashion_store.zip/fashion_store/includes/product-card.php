<?php
function renderProductCard(array $product) {

    // ================== TÍNH GIẢM GIÁ ==================
    $discount = (!empty($product['sale_price']) && $product['price'] > 0 && $product['sale_price'] < $product['price'])
        ? round(100 - ($product['sale_price'] / $product['price']) * 100)
        : 0;

    // ================== XỬ LÝ ẢNH ==================
    if (!empty($product['main_image'])) {
        // Ảnh online (unsplash, http...)
        if (strpos($product['main_image'], 'http') === 0) {
            $imageSource = $product['main_image'];

        // Path đã đầy đủ (images/...)
        } elseif (strpos($product['main_image'], 'images/') === 0) {
            $imageSource = $product['main_image'];

        // Chỉ tên file → nối thư mục
        } else {
            $imageSource = 'images/products/' . $product['main_image'];
        }
    } else {
        // Fallback default
        $imageSource = 'images/products/default.jpg';
    }
    ?>

    <div class="col">
        <div class="product-card h-100">
            <a href="product.php?slug=<?= htmlspecialchars($product['slug']) ?>" 
               class="text-decoration-none text-dark">

                <div class="card border-0 rounded-0 h-100">

                    <!-- IMAGE -->
                    <div class="product-image position-relative overflow-hidden">
                        <img 
                            src="<?= htmlspecialchars($imageSource) ?>"
                            class="card-img-top rounded-0"
                            style="height:400px; object-fit:cover;"
                            alt="<?= htmlspecialchars($product['name']) ?>"
                            loading="lazy"
                            onerror="this.src='images/products/default.jpg';"
                        >

                        <?php if ($discount > 0): ?>
                            <span class="badge bg-danger position-absolute top-0 end-0 m-2 rounded-0">
                                <?= $discount ?>% OFF
                            </span>
                        <?php endif; ?>
                    </div>

                    <!-- INFO -->
                    <div class="card-body px-0 pt-3">

                        <h6 class="card-title mb-1 fw-normal">
                            <?= htmlspecialchars($product['name']) ?>
                        </h6>

                        <?php if (!empty($product['category_name'])): ?>
                            <p class="text-muted small mb-2">
                                <?= htmlspecialchars($product['category_name']) ?>
                            </p>
                        <?php endif; ?>

                        <div class="d-flex align-items-center">
                            <?php if (!empty($product['sale_price']) && $product['sale_price'] < $product['price']): ?>
                                <span class="fw-bold text-dark me-2">
                                    <?= formatPrice($product['sale_price']) ?>
                                </span>
                                <span class="text-muted small text-decoration-line-through">
                                    <?= formatPrice($product['price']) ?>
                                </span>
                            <?php else: ?>
                                <span class="fw-bold text-dark">
                                    <?= formatPrice($product['price']) ?>
                                </span>
                            <?php endif; ?>
                        </div>

                    </div>
                </div>
            </a>
        </div>
    </div>

<?php } ?>
