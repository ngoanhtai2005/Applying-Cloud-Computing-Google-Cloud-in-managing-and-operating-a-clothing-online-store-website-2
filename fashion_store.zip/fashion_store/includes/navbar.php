<!-- Navigation -->
<nav class="navbar navbar-expand-lg navbar-light bg-white sticky-top border-bottom">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand fw-bold fs-3" href="index.php">
            <span class="text-dark">FORMAT</span><span class="text-muted">.STORE</span>
        </a>

        <!-- Mobile Toggle -->
        <button class="navbar-toggler border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarMain">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navigation Links -->
        <div class="collapse navbar-collapse" id="navbarMain">
            <ul class="navbar-nav mx-auto">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">HOME</a>
                </li>
                <?php
                $conn = getDBConnection();
                // Lấy các danh mục chính (không có parent_id) từ database
                $sql = "SELECT name, slug FROM categories WHERE parent_id IS NULL ORDER BY name ASC";
                $navResult = $conn->query($sql);

               if ($navResult && mysqli_num_rows($navResult) > 0) {
    while ($navCat = mysqli_fetch_assoc($navResult)) {
        echo '<li class="nav-item">';
        echo '<a class="nav-link" href="category.php?category=' . $navCat['slug'] . '">'
            . strtoupper($navCat['name']) .
            '</a>';
        echo '</li>';
    }
}
 
                ?>
                <li class="nav-item">
                    <a class="nav-link text-danger" href="category.php?category=sale">SALE</a>
                </li>
            </ul>

            <!-- Right Side Icons -->
            <div class="d-flex align-items-center">
                <!-- Search -->
                <div class="search-container me-3">
                    <button class="btn btn-link text-dark p-0" type="button" data-bs-toggle="collapse" data-bs-target="#searchBox">
                        <i class="bi bi-search fs-5"></i>
                    </button>
                    <div class="collapse" id="searchBox">
                        <form class="d-flex" action="search.php" method="GET">
                            <input class="form-control rounded-0 border-0 border-bottom" type="search" name="q" placeholder="Search..." style="min-width: 200px;">
                        </form>
                    </div>
                </div>

                <!-- User Account -->
                <?php if (isLoggedIn()): ?>
                    <div class="dropdown me-3">
                        <a href="#" class="text-dark" data-bs-toggle="dropdown">
                            <i class="bi bi-person fs-5"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="account.php">My Account</a></li>
                            <li><a class="dropdown-item" href="orders.php">My Orders</a></li>
                            <li><a class="dropdown-item" href="wishlist.php">Wishlist</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Logout</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <a href="login.php" class="text-dark me-3">
                        <i class="bi bi-person fs-5"></i>
                    </a>
                <?php endif; ?>

                <!-- Wishlist -->
                <a href="wishlist.php" class="text-dark me-3 position-relative">
                    <i class="bi bi-heart fs-5"></i>
                    <?php if (isset($_SESSION['wishlist_count']) && $_SESSION['wishlist_count'] > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size: 0.5rem;">
                            <?php echo $_SESSION['wishlist_count']; ?>
                        </span>
                    <?php endif; ?>
                </a>

                <!-- Cart -->
                <a href="cart.php" class="text-dark position-relative">
                    <i class="bi bi-bag fs-5"></i>
                    <?php if (getCartCount() > 0): ?>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-dark" style="font-size: 0.5rem;">
                            <?php echo getCartCount(); ?>
                        </span>
                    <?php endif; ?>
                </a>
            </div>
        </div>
    </div>
</nav>
