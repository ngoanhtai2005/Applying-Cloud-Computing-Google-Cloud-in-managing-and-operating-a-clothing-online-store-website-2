    <!-- Footer -->
    <footer class="bg-dark text-white pt-5 pb-4">
        <div class="container">
            <div class="row">
                <!-- Brand Info -->
                <div class="col-lg-4 mb-4">
                    <h4 class="fw-bold mb-3">FORMAT.STORE</h4>
                    <p class="text-light opacity-75">Premium fashion for the modern individual. Sustainable, timeless, and thoughtfully designed.</p>
                    <div class="social-icons mt-4">
                        <a href="#" class="text-white me-3"><i class="bi bi-instagram fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-facebook fs-5"></i></a>
                        <a href="#" class="text-white me-3"><i class="bi bi-twitter fs-5"></i></a>
                        <a href="#" class="text-white"><i class="bi bi-pinterest fs-5"></i></a>
                    </div>
                </div>
                
                <!-- Quick Links -->
                <div class="col-lg-2 col-md-4 mb-4">
                    <h5 class="mb-3">SHOP</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="category.php?category=women" class="text-light opacity-75 text-decoration-none">Women</a></li>
                        <li class="mb-2"><a href="category.php?category=men" class="text-light opacity-75 text-decoration-none">Men</a></li>
                        <li class="mb-2"><a href="category.php?category=new" class="text-light opacity-75 text-decoration-none">New Arrivals</a></li>
                        <li class="mb-2"><a href="category.php?category=sale" class="text-light opacity-75 text-decoration-none">Sale</a></li>
                    </ul>
                </div>
                
                <!-- Policies -->
                <div class="col-lg-3 col-md-4 mb-4">
                    <h5 class="mb-3">POLICIES</h5>
                    <ul class="list-unstyled">
                        <li class="mb-2"><a href="#" class="text-light opacity-75 text-decoration-none">Shipping Policy</a></li>
                        <li class="mb-2"><a href="#" class="text-light opacity-75 text-decoration-none">Return & Exchange</a></li>
                        <li class="mb-2"><a href="#" class="text-light opacity-75 text-decoration-none">Privacy Policy</a></li>
                        <li class="mb-2"><a href="#" class="text-light opacity-75 text-decoration-none">Terms of Service</a></li>
                    </ul>
                </div>
                
                <!-- Newsletter -->
                <div class="col-lg-3 col-md-4 mb-4">
                    <h5 class="mb-3">NEWSLETTER</h5>
                    <p class="text-light opacity-75 mb-3">Subscribe for exclusive updates and offers.</p>
                    <form class="newsletter-form">
                        <div class="input-group">
                            <input type="email" class="form-control rounded-0 bg-transparent text-white border-white" 
                                   placeholder="Your email" required>
                            <button class="btn btn-outline-light rounded-0" type="submit">
                                <i class="bi bi-arrow-right"></i>
                            </button>
                        </div>
                    </form>
                </div>
            </div>
            
            <hr class="bg-light opacity-25 my-4">
            
            <!-- Copyright -->
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0 text-light opacity-75">&copy; <?php echo date('Y'); ?> FORMAT.STORE. All rights reserved.</p>
                </div>
                <div class="col-md-6 text-end">
                    <p class="mb-0 text-light opacity-75">Designed with ❤️ for fashion lovers</p>
                </div>
            </div>
        </div>
    </footer>
    
    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- Custom JS -->
    <script src="assets/js/main.js"></script>
    
    <?php if (isset($pageScripts)): ?>
        <?php foreach ($pageScripts as $script): ?>
            <script src="<?php echo $script; ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>