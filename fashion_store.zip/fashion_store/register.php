<?php
session_start();
// Kết nối Database chuẩn
include 'config/database.php';
$conn = getDBConnection();

include 'includes/header.php';

$error = "";
$success = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name']; // Hoặc full_name tùy form của bạn
    $email = $_POST['email'];
    $password = $_POST['password'];
    $phone = $_POST['phone']; // <--- Lấy số điện thoại
    $confirm_password = $_POST['confirm_password']; // Nếu có ô nhập lại mk

    // 1. Kiểm tra mật khẩu nhập lại
    if ($password !== $confirm_password) {
        $error = "Mật khẩu nhập lại không khớp!";
    } else {
        // 2. Kiểm tra xem Email hoặc SĐT đã tồn tại chưa?
        $checkSQL = "SELECT id FROM users WHERE email = ? OR phone = ?";
        $stmt = $conn->prepare($checkSQL);
        $stmt->bind_param("ss", $email, $phone);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Email hoặc Số điện thoại này đã được sử dụng!";
        } else {
            // 3. Nếu chưa có thì tạo mới (Lưu cả Phone)
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            
            // Câu lệnh INSERT quan trọng: Phải có 4 dấu ?
           
$sql = "INSERT INTO users (name, email, password, phone) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if ($stmt) {
                // 'ssss' nghĩa là 4 biến đều là dạng chuỗi (string)
                $stmt->bind_param("ssss", $name, $email, $hashed_password, $phone);
                
                if ($stmt->execute()) {
                    $success = "Đăng ký thành công! Đang chuyển hướng...";
                    echo "<script>
                            setTimeout(function(){ window.location.href = 'login.php'; }, 2000);
                          </script>";
                } else {
                    $error = "Lỗi hệ thống: " . $conn->error;
                }
            } else {
                $error = "Lỗi SQL: " . $conn->error;
            }
        }
    }
}
?>

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card shadow">
                <div class="card-body p-5">
                    <h2 class="text-center mb-4">TẠO TÀI KHOẢN</h2>
                    
                    <?php 
                    if($error) echo "<div class='alert alert-danger'>$error</div>";
                    if($success) echo "<div class='alert alert-success'>$success</div>";
                    ?>

                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">Họ và tên đầy đủ</label>
                            <input type="text" name="name" class="form-control" required>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Địa chỉ email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Số điện thoại</label>
                            <input type="text" name="phone" class="form-control" required placeholder="09xxxxxxxx">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Mật khẩu</label>
                            <input type="password" name="password" class="form-control" required>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Xác nhận mật khẩu</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>

                        <button type="submit" class="btn btn-dark w-100 py-2">TẠO TÀI KHOẢN</button>
                    </form>
                    
                    <div class="text-center mt-3">
                        <p>Bạn đã có tài khoản chưa? <a href="login.php" class="text-decoration-none fw-bold">ĐĂNG NHẬP TẠI ĐÂY</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
